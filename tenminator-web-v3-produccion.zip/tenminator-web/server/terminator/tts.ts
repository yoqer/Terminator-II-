/**
 * Terminator II — TTS / STT Router
 *
 * TTS chain: Kokoro (local Docker) → Grok Aurora → OpenAI TTS → Piper (local CPU)
 * STT chain: Grok STT → OpenAI Whisper API
 *
 * Returns audio as a public S3 URL.
 *
 * Kokoro Docker: docker run -p 8880:8880 ghcr.io/remsky/kokoro-fastapi-cpu:v0.2.2
 * Compatible with all 11 language repos from github.com/yoqer/TerminatorTTS-Kokoro-*
 */

import { storagePut } from "../storage";
import { nanoid } from "nanoid";

export interface TTSConfig {
  xaiApiKey?: string;
  openaiApiKey?: string;
  kokoroUrl?: string;   // e.g. "http://localhost:8880" — Kokoro Docker
  coquiUrl?: string;    // e.g. "http://localhost:5002" — Coqui XTTS (17 idiomas)
  sileroUrl?: string;   // e.g. "http://localhost:5003" — Silero TTS (rápido)
  piperUrl?: string;    // e.g. "http://localhost:5000" — Piper TTS REST server
  preferredTts?: string; // "auto" | "kokoro" | "coqui" | "silero" | "grok" | "openai" | "piper"
}

export interface STTConfig {
  xaiApiKey?: string;
  openaiApiKey?: string;
}

// ─── Language → Kokoro voice prefix ──────────────────────────────────────────
// Kokoro language codes from the yoqer repos:
// a=en-US, b=en-GB, d=de, e=es, f=fr, h=hi, i=it, j=ja, k=ko, p=pt-BR, z=zh
const KOKORO_LANG_PREFIX: Record<string, string> = {
  en: "a",
  "en-gb": "b",
  de: "d",
  es: "e",
  fr: "f",
  hi: "h",
  it: "i",
  ja: "j",
  ko: "k",
  pt: "p",
  zh: "z",
};

// Kokoro voices per persona and gender (prefix + voice suffix)
// af_ = American female, am_ = American male, etc.
const KOKORO_PERSONA_VOICE: Record<string, Record<string, string>> = {
  // [langPrefix][personaId] → voice name
  a: { default: "am_adam", ani: "af_heart", valentin: "am_michael" },
  b: { default: "bm_george", ani: "bf_emma", valentin: "bm_lewis" },
  d: { default: "dm_thorsten", ani: "df_hedda", valentin: "dm_thorsten" },
  e: { default: "em_alex", ani: "ef_dora", valentin: "em_alex" },
  f: { default: "fm_pierre", ani: "ff_siwis", valentin: "fm_pierre" },
  h: { default: "hm_varoon", ani: "hf_alpha", valentin: "hm_varoon" },
  i: { default: "im_riccardo", ani: "if_sara", valentin: "im_riccardo" },
  j: { default: "jm_kumo", ani: "jf_alpha", valentin: "jm_kumo" },
  k: { default: "km_yunho", ani: "kf_alpha", valentin: "km_yunho" },
  p: { default: "pm_alex", ani: "pf_dora", valentin: "pm_alex" },
  z: { default: "zm_yunxi", ani: "zf_xiaobei", valentin: "zm_yunxi" },
};

// ─── Grok voices ──────────────────────────────────────────────────────────────
const GROK_VOICE_MAP: Record<string, string> = {
  default: "rex",
  ani: "ara",
  valentin: "sal",
};

// ─── OpenAI voices ────────────────────────────────────────────────────────────
const OPENAI_VOICE_MAP: Record<string, string> = {
  default: "onyx",
  ani: "nova",
  valentin: "echo",
};

// ─── Piper language → model ───────────────────────────────────────────────────
const PIPER_MODEL_MAP: Record<string, string> = {
  es: "es_ES-davefx-medium",
  en: "en_US-lessac-medium",
  de: "de_DE-thorsten-medium",
  fr: "fr_FR-siwis-medium",
  it: "it_IT-riccardo-x_low",
  pt: "pt_BR-faber-medium",
};

// ─── Coqui TTS (XTTS — local server con 17 idiomas incluyendo árabe y ruso) ────────

async function coquiTTS(
  text: string,
  personaId: string,
  language: string,
  coquiUrl: string
): Promise<Buffer | null> {
  try {
    const langCode = language.toLowerCase().split("-")[0];
    if (!["ar", "de", "en", "es", "fr", "hu", "it", "ja", "ko", "nl", "pl", "pt", "ru", "tr", "uk", "zh"].includes(langCode)) {
      console.log(`[Coqui] Idioma ${langCode} no soportado`);
      return null;
    }

    const response = await fetch(`${coquiUrl}/tts`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text,
        language: langCode,
        speaker_wav: null,
      }),
      signal: AbortSignal.timeout(30000),
    });

    if (!response.ok) {
      console.log(`[Coqui] Error ${response.status}`);
      return null;
    }

    const buffer = await response.arrayBuffer();
    return Buffer.from(buffer);
  } catch (err) {
    console.log(`[Coqui] Error: ${err instanceof Error ? err.message : String(err)}`);
    return null;
  }
}

// ─── Silero TTS (local server — rápido y ligero, soporta ruso) ────────────────────────

async function sileroTTS(
  text: string,
  personaId: string,
  language: string,
  sileroUrl: string
): Promise<Buffer | null> {
  try {
    const langCode = language.toLowerCase().split("-")[0];
    if (!["en", "de", "es", "fr", "ru", "uk", "hi"].includes(langCode)) {
      console.log(`[Silero] Idioma ${langCode} no soportado`);
      return null;
    }

    const response = await fetch(`${sileroUrl}/tts`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text,
        language: langCode,
        speaker: "xenia",
        sample_rate: 24000,
      }),
      signal: AbortSignal.timeout(30000),
    });

    if (!response.ok) {
      console.log(`[Silero] Error ${response.status}`);
      return null;
    }

    const buffer = await response.arrayBuffer();
    return Buffer.from(buffer);
  } catch (err) {
    console.log(`[Silero] Error: ${err instanceof Error ? err.message : String(err)}`);
    return null;
  }
}

// ─── Kokoro TTS (local Docker, OpenAI-compatible API) ────────────────────────

export interface KokoroTTSOptions {
  volumeMultiplier?: number; // 0.1 to 2.0, default 1.0
  useStreaming?: boolean;     // Use SSE streaming (stream_format: "sse")
}

async function kokoroTTS(
  text: string,
  personaId: string,
  language: string,
  kokoroUrl: string,
  options?: KokoroTTSOptions
): Promise<Buffer | null> {
  try {
    const langKey = language.toLowerCase().split("-")[0];
    const prefix = KOKORO_LANG_PREFIX[language.toLowerCase()] ?? KOKORO_LANG_PREFIX[langKey] ?? "e";
    const voiceMap = KOKORO_PERSONA_VOICE[prefix] ?? KOKORO_PERSONA_VOICE["e"];
    const voice = voiceMap[personaId] ?? voiceMap["default"];

    // Clamp volume_multiplier to valid range [0.1, 2.0]
    const volumeMultiplier = options?.volumeMultiplier
      ? Math.max(0.1, Math.min(2.0, options.volumeMultiplier))
      : 1.0;

    // Build request body with optional streaming
    const requestBody: Record<string, unknown> = {
      model: "kokoro",
      input: text,
      voice,
      response_format: "mp3",
      speed: 1.0,
      volume_multiplier: volumeMultiplier,
    };

    // Add streaming format if requested
    if (options?.useStreaming) {
      requestBody.stream_format = "sse";
    }

    const res = await fetch(`${kokoroUrl}/v1/audio/speech`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(requestBody),
      signal: AbortSignal.timeout(30000),
    });

    if (!res.ok) {
      console.warn(`[TTS] Kokoro HTTP ${res.status}: ${await res.text()}`);
      return null;
    }

    // Handle streaming SSE response
    if (options?.useStreaming && res.headers.get("content-type")?.includes("text/event-stream")) {
      return await handleKokoroSSEStream(res);
    }

    // Standard response
    const ab = await res.arrayBuffer();
    return Buffer.from(ab);
  } catch (err) {
    console.warn("[TTS] Kokoro unavailable:", (err as Error).message);
    return null;
  }
}

// ─── Handle Kokoro SSE streaming ──────────────────────────────────────────────

async function handleKokoroSSEStream(response: Response): Promise<Buffer | null> {
  try {
    const reader = response.body?.getReader();
    if (!reader) return null;

    const chunks: Uint8Array[] = [];
    const decoder = new TextDecoder();

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const text = decoder.decode(value, { stream: true });
      const lines = text.split("\n");

      for (const line of lines) {
        if (line.startsWith("data: ")) {
          try {
            const data = JSON.parse(line.slice(6));
            if (data.audio) {
              // audio is base64-encoded
              const audioBuffer = Buffer.from(data.audio, "base64");
              chunks.push(new Uint8Array(audioBuffer));
            }
          } catch (e) {
            console.warn("[TTS] Failed to parse SSE chunk:", e);
          }
        }
      }
    }

    // Concatenate all chunks
    if (chunks.length === 0) return null;

    const totalLength = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
    const result = new Uint8Array(totalLength);
    let offset = 0;

    for (const chunk of chunks) {
      result.set(chunk, offset);
      offset += chunk.length;
    }

    return Buffer.from(result);
  } catch (err) {
    console.warn("[TTS] SSE stream error:", (err as Error).message);
    return null;
  }
}

// ─── Check Kokoro availability ────────────────────────────────────────────────

export async function checkKokoro(kokoroUrl: string): Promise<boolean> {
  try {
    const res = await fetch(`${kokoroUrl}/v1/models`, {
      signal: AbortSignal.timeout(3000),
    });
    return res.ok;
  } catch {
    return false;
  }
}

// ─── Grok TTS ─────────────────────────────────────────────────────────────────

async function grokTTS(
  text: string,
  personaId: string,
  apiKey: string
): Promise<Buffer> {
  const voice = GROK_VOICE_MAP[personaId] ?? "rex";
  const res = await fetch("https://api.x.ai/v1/audio/speech", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "grok-tts-aurora",
      input: text,
      voice,
      response_format: "mp3",
    }),
    signal: AbortSignal.timeout(30000),
  });
  if (!res.ok) throw new Error(`Grok TTS HTTP ${res.status}`);
  const ab = await res.arrayBuffer();
  return Buffer.from(ab);
}

// ─── OpenAI TTS ───────────────────────────────────────────────────────────────

async function openaiTTS(
  text: string,
  personaId: string,
  apiKey: string
): Promise<Buffer> {
  const voice = OPENAI_VOICE_MAP[personaId] ?? "onyx";
  const res = await fetch("https://api.openai.com/v1/audio/speech", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "tts-1",
      input: text,
      voice,
      response_format: "mp3",
    }),
    signal: AbortSignal.timeout(30000),
  });
  if (!res.ok) throw new Error(`OpenAI TTS HTTP ${res.status}`);
  const ab = await res.arrayBuffer();
  return Buffer.from(ab);
}

// ─── Piper TTS (local, CPU) ───────────────────────────────────────────────────

async function piperTTS(text: string, language = "es"): Promise<Buffer | null> {
  try {
    const { execSync } = await import("child_process");
    const { writeFileSync, readFileSync, unlinkSync } = await import("fs");
    const { tmpdir } = await import("os");
    const { join } = await import("path");

    const model = PIPER_MODEL_MAP[language] ?? PIPER_MODEL_MAP.es;
    const outFile = join(tmpdir(), `piper_${nanoid()}.wav`);
    const inFile = join(tmpdir(), `piper_in_${nanoid()}.txt`);

    writeFileSync(inFile, text, "utf-8");
    execSync(`piper --model ${model} --output_file ${outFile} < ${inFile}`, {
      timeout: 20000,
    });
    const buf = readFileSync(outFile);
    unlinkSync(outFile);
    unlinkSync(inFile);
    return buf;
  } catch {
    return null;
  }
}

// ─── Language support matrix ────────────────────────────────────────────────────
// Kokoro: 11 idiomas (NO incluye árabe ni ruso)
const KOKORO_LANGS = ["en", "de", "es", "fr", "hi", "it", "ja", "ko", "pt", "zh"];
// Coqui: 17 idiomas (incluye árabe y ruso)
const COQUI_LANGS = ["ar", "de", "en", "es", "fr", "hu", "it", "ja", "ko", "nl", "pl", "pt", "ru", "tr", "uk", "zh"];
// Silero: 7 idiomas (incluye ruso)
const SILERO_LANGS = ["en", "de", "es", "fr", "ru", "uk", "hi"];

// ─── Main TTS call ────────────────────────────────────────────────────────────

export async function synthesizeSpeech(
  text: string,
  config: TTSConfig,
  personaId = "default",
  language = "es",
  options?: {
    volumeMultiplier?: number; // For Kokoro: 0.1 to 2.0
    useStreaming?: boolean;     // For Kokoro: use SSE streaming
  }
): Promise<{ url: string; backend: string } | null> {
  if (!text.trim()) return null;

  const preferred = config.preferredTts ?? "auto";
  let audioBuffer: Buffer | null = null;
  let backend = "none";
  let ext = "mp3";

  // Normalize language code (e.g., "en-US" → "en")
  const langKey = language.toLowerCase().split("-")[0];

  // 1. Kokoro local (highest priority — free, local, 11 languages)
  // Skip Kokoro if language is not supported (e.g., Arabic, Russian)
  const kokoroUrl = config.kokoroUrl ?? "http://localhost:8880";
  const kokoroSupported = KOKORO_LANGS.includes(langKey);
  
  if ((preferred === "auto" || preferred === "kokoro") && kokoroSupported) {
    const buf = await kokoroTTS(text, personaId, language, kokoroUrl, {
      volumeMultiplier: options?.volumeMultiplier,
      useStreaming: options?.useStreaming,
    });
    if (buf) {
      audioBuffer = buf;
      backend = "kokoro";
      ext = "wav";
    }
  }

  // 2. Coqui XTTS (17 idiomas incluyendo árabe)
  if (!audioBuffer && (preferred === "auto" || preferred === "coqui") && config.coquiUrl) {
    try {
      const buf = await coquiTTS(text, personaId, language, config.coquiUrl);
      if (buf) {
        audioBuffer = buf;
        backend = "coqui";
        ext = "wav";
      }
    } catch (err) {
      console.warn("[TTS] Coqui failed:", (err as Error).message);
    }
  }

  // 3. Silero TTS (rápido y ligero)
  if (!audioBuffer && (preferred === "auto" || preferred === "silero") && config.sileroUrl) {
    try {
      const buf = await sileroTTS(text, personaId, language, config.sileroUrl);
      if (buf) {
        audioBuffer = buf;
        backend = "silero";
        ext = "wav";
      }
    } catch (err) {
      console.warn("[TTS] Silero failed:", (err as Error).message);
    }
  }

  // 4. Grok Aurora TTS
  if (!audioBuffer && (preferred === "auto" || preferred === "grok") && config.xaiApiKey) {
    try {
      audioBuffer = await grokTTS(text, personaId, config.xaiApiKey);
      backend = "grok-tts";
      ext = "mp3";
    } catch (err) {
      console.warn("[TTS] Grok failed:", (err as Error).message);
    }
  }

  // 5. OpenAI TTS
  if (!audioBuffer && (preferred === "auto" || preferred === "openai") && config.openaiApiKey) {
    try {
      audioBuffer = await openaiTTS(text, personaId, config.openaiApiKey);
      backend = "openai-tts";
      ext = "mp3";
    } catch (err) {
      console.warn("[TTS] OpenAI failed:", (err as Error).message);
    }
  }

  // 6. Piper (CPU fallback, no external API needed)
  if (!audioBuffer && (preferred === "auto" || preferred === "piper")) {
    try {
      const piperBuf = await piperTTS(text, language);
      if (piperBuf) {
        audioBuffer = piperBuf;
        backend = "piper";
        ext = "wav";
      }
    } catch (err) {
      console.warn("[TTS] Piper failed:", (err as Error).message);
    }
  }

  if (!audioBuffer) return null;

  const key = `terminator/audio/${nanoid()}.${ext}`;
  const { url } = await storagePut(
    key,
    audioBuffer,
    `audio/${ext === "wav" ? "wav" : "mpeg"}`
  );
  return { url, backend };
}

// ─── STT ──────────────────────────────────────────────────────────────────────

export async function transcribeAudio(
  audioUrl: string,
  config: STTConfig,
  language?: string
): Promise<{ text: string; backend: string } | null> {
  // Download audio first
  let audioBuffer: Uint8Array;
  try {
    const res = await fetch(audioUrl, { signal: AbortSignal.timeout(30000) });
    if (!res.ok) throw new Error(`Download failed: HTTP ${res.status}`);
    const ab = await res.arrayBuffer();
    audioBuffer = new Uint8Array(ab.slice(0));
  } catch (err) {
    console.error("[STT] Failed to download audio:", (err as Error).message);
    return null;
  }

  // Try Grok STT first
  if (config.xaiApiKey) {
    try {
      const formData = new FormData();
      const ab1 = audioBuffer.buffer.slice(
        audioBuffer.byteOffset,
        audioBuffer.byteOffset + audioBuffer.byteLength
      ) as ArrayBuffer;
      formData.append("file", new Blob([ab1], { type: "audio/mpeg" }), "audio.mp3");
      formData.append("model", "whisper-large-v3");
      if (language) formData.append("language", language);

      const res = await fetch("https://api.x.ai/v1/audio/transcriptions", {
        method: "POST",
        headers: { Authorization: `Bearer ${config.xaiApiKey}` },
        body: formData,
        signal: AbortSignal.timeout(30000),
      });
      if (!res.ok) throw new Error(`Grok STT HTTP ${res.status}`);
      const json = (await res.json()) as { text?: string };
      if (json.text) return { text: json.text, backend: "grok-stt" };
    } catch (err) {
      console.warn("[STT] Grok failed:", (err as Error).message);
    }
  }

  // Fallback: OpenAI Whisper
  if (config.openaiApiKey) {
    try {
      const formData = new FormData();
      const ab2 = audioBuffer.buffer.slice(
        audioBuffer.byteOffset,
        audioBuffer.byteOffset + audioBuffer.byteLength
      ) as ArrayBuffer;
      formData.append("file", new Blob([ab2], { type: "audio/mpeg" }), "audio.mp3");
      formData.append("model", "whisper-1");
      if (language) formData.append("language", language);

      const res = await fetch("https://api.openai.com/v1/audio/transcriptions", {
        method: "POST",
        headers: { Authorization: `Bearer ${config.openaiApiKey}` },
        body: formData,
        signal: AbortSignal.timeout(30000),
      });
      if (!res.ok) throw new Error(`OpenAI STT HTTP ${res.status}`);
      const json = (await res.json()) as { text?: string };
      if (json.text) return { text: json.text, backend: "openai-whisper" };
    } catch (err) {
      console.warn("[STT] OpenAI Whisper failed:", (err as Error).message);
    }
  }

  return null;
}

// ─── Kokoro language list (for UI) ────────────────────────────────────────────

export const KOKORO_LANGUAGES = [
  { code: "es", label: "Español", prefix: "e" },
  { code: "en", label: "English (US)", prefix: "a" },
  { code: "en-gb", label: "English (UK)", prefix: "b" },
  { code: "de", label: "Deutsch", prefix: "d" },
  { code: "fr", label: "Français", prefix: "f" },
  { code: "hi", label: "हिन्दी", prefix: "h" },
  { code: "it", label: "Italiano", prefix: "i" },
  { code: "ja", label: "日本語", prefix: "j" },
  { code: "ko", label: "한국어", prefix: "k" },
  { code: "pt", label: "Português (BR)", prefix: "p" },
  { code: "zh", label: "中文", prefix: "z" },
] as const;
