/**
 * TTS Integration Tests — Kokoro, Coqui, Silero, SSE Streaming
 * 
 * Tests de integración para verificar que los backends TTS funcionan correctamente
 * sin perder funcionalidades existentes.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { synthesizeSpeech, KokoroTTSOptions } from "../server/terminator/tts";
import type { TTSConfig } from "../server/terminator/tts";

// ─── Mock de storage.ts ──────────────────────────────────────────────────────

vi.mock("../server/storage.ts", () => ({
  storagePut: vi.fn(async (key: string, data: Buffer, mimeType: string) => {
    // Simular S3 upload
    const base64 = data.toString("base64");
    return {
      key,
      url: `data:${mimeType};base64,${base64}`,
    };
  }),
}));

// ─── Tests ──────────────────────────────────────────────────────────────────

describe("TTS Integration Tests", () => {
  let originalFetch: typeof global.fetch;

  beforeEach(() => {
    originalFetch = global.fetch;
  });

  afterEach(() => {
    global.fetch = originalFetch;
    vi.clearAllMocks();
  });

  // ─── Kokoro Tests ───────────────────────────────────────────────────────────

  describe("Kokoro TTS", () => {
    it("should synthesize Spanish with Kokoro", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      const result = await synthesizeSpeech("Hola mundo", config, "default", "es");
      expect(result).toBeTruthy();
      // Spanish is supported by Kokoro, so it should use Kokoro
      expect(result?.backend).toBe("kokoro");
      expect(result?.url).toContain("data:");
    });

    it("should apply volume_multiplier (0.1 to 2.0)", async () => {
      let requestBody: any;
      global.fetch = vi.fn(async (url: any, options: any) => {
        if (typeof url === "string" && url.includes("8880")) {
          requestBody = JSON.parse(options.body as string);
        }
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      // Test volume 0.5
      await synthesizeSpeech("Test", config, "default", "es", {
        volumeMultiplier: 0.5,
      });

      expect(requestBody.volume_multiplier).toBe(0.5);

      // Test clamping: 3.0 → 2.0
      await synthesizeSpeech("Test", config, "default", "es", {
        volumeMultiplier: 3.0,
      });

      expect(requestBody.volume_multiplier).toBe(2.0);

      // Test clamping: 0.05 → 0.1
      await synthesizeSpeech("Test", config, "default", "es", {
        volumeMultiplier: 0.05,
      });

      expect(requestBody.volume_multiplier).toBe(0.1);
    });

    it("should support SSE streaming format", async () => {
      let requestBody: any;
      global.fetch = vi.fn(async (url: any, options: any) => {
        if (typeof url === "string" && url.includes("8880")) {
          requestBody = JSON.parse(options.body as string);
        }
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      await synthesizeSpeech("Test", config, "default", "es", {
        useStreaming: true,
      });

      expect(requestBody.stream_format).toBe("sse");
    });

    it("should support 11 Kokoro languages", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      const languages = ["en", "de", "es", "fr", "hi", "it", "ja", "ko", "pt", "zh"];

      for (const lang of languages) {
        const result = await synthesizeSpeech("Test", config, "default", lang);
        expect(result?.backend).toBe("kokoro");
      }
    });
  });

  // ─── Coqui Tests ────────────────────────────────────────────────────────────

  describe("Coqui XTTS", () => {
    it("should synthesize Arabic with Coqui", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "coqui",
        coquiUrl: "http://localhost:5002",
      };

      const result = await synthesizeSpeech("مرحبا", config, "default", "ar");
      expect(result).toBeTruthy();
      expect(result?.backend).toBe("coqui");
      expect(result?.backend).toBe("coqui");
    });

    it("should support 17 Coqui languages including Arabic and Russian", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "coqui",
        coquiUrl: "http://localhost:5002",
      };

      const languages = [
        "ar", // Arabic
        "de",
        "en",
        "es",
        "fr",
        "hu",
        "it",
        "ja",
        "ko",
        "nl",
        "pl",
        "pt",
        "ru", // Russian
        "tr",
        "uk",
        "zh",
      ];

      for (const lang of languages) {
        const result = await synthesizeSpeech("Test", config, "default", lang);
        expect(result?.backend).toBe("coqui");
      }
    });
  });

  // ─── Silero Tests ───────────────────────────────────────────────────────────

  describe("Silero TTS", () => {
    it("should synthesize Russian with Silero", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "silero",
        sileroUrl: "http://localhost:5003",
      };

      const result = await synthesizeSpeech("Привет", config, "default", "ru");
      expect(result).toBeTruthy();
      expect(result?.backend).toBe("silero");
    });

    it("should support 7 Silero languages", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "silero",
        sileroUrl: "http://localhost:5003",
      };

      const languages = ["en", "de", "es", "fr", "ru", "uk", "hi"];

      for (const lang of languages) {
        const result = await synthesizeSpeech("Test", config, "default", lang);
        expect(result?.backend).toBe("silero");
      }
    });
  });

  // ─── Fallback Chain Tests ────────────────────────────────────────────────────

  describe("Fallback Chain", () => {
    it("should fallback from Kokoro → Coqui when Kokoro unavailable", async () => {
      let callCount = 0;

      global.fetch = vi.fn(async (url: any) => {
        callCount++;

        // Kokoro fails
        if (typeof url === "string" && url.includes("8880")) {
          return {
            ok: false,
            status: 503,
            text: async () => "Service unavailable",
            headers: { get: () => null },
          } as any;
        }

        // Coqui succeeds
        if (typeof url === "string" && url.includes("5002")) {
          const audioBuffer = Buffer.from("fake-audio-data");
          return {
            ok: true,
            status: 200,
            arrayBuffer: async () => audioBuffer.buffer,
            headers: { get: () => null },
          } as any;
        }

        throw new Error("Unexpected URL");
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
        coquiUrl: "http://localhost:5002",
      };

      const result = await synthesizeSpeech("Test", config, "default", "ar");
      expect(result?.backend).toBe("coqui");
      expect(callCount).toBeGreaterThan(0);
    });

    it("should skip backends that are not configured", async () => {
      global.fetch = vi.fn(async (url: any) => {
        // Only Coqui is configured
        if (typeof url === "string" && url.includes("5002")) {
          const audioBuffer = Buffer.from("fake-audio-data");
          return {
            ok: true,
            status: 200,
            arrayBuffer: async () => audioBuffer.buffer,
            headers: { get: () => null },
          } as any;
        }
        throw new Error("Unexpected URL");
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        coquiUrl: "http://localhost:5002",
        // kokoroUrl and sileroUrl are not set
      };

      const result = await synthesizeSpeech("Test", config, "default", "ar");
      expect(result?.backend).toBe("coqui");
    });
  });

  // ─── Edge Cases ─────────────────────────────────────────────────────────────

  describe("Edge Cases", () => {
    it("should handle empty text", async () => {
      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      const result = await synthesizeSpeech("", config, "default", "es");
      expect(result).toBeNull();
    });

    it("should handle whitespace-only text", async () => {
      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      // Whitespace-only text should return null
      const result = await synthesizeSpeech("   ", config, "default", "es");
      expect(result).toBeNull();
    });

    it("should handle network timeout", async () => {
      global.fetch = vi.fn(async () => {
        throw new Error("Network timeout");
      });

      const config: TTSConfig = {
        preferredTts: "kokoro",
        kokoroUrl: "http://localhost:8880",
      };

      const result = await synthesizeSpeech("Test", config, "default", "es");
      expect(result).toBeNull();
    });
  });

  // ─── Configuration Tests ────────────────────────────────────────────────────

  describe("Configuration", () => {
    it("should use default URLs when not provided", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        // kokoroUrl not provided, should use default
      };

      // Spanish is supported by Kokoro, so it should use Kokoro with default URL
      const result = await synthesizeSpeech("Test", config, "default", "es");
      expect(result).toBeTruthy();
      expect(result?.backend).toBe("kokoro");
    });

    it("should respect preferred TTS backend", async () => {
      global.fetch = vi.fn(async (url: any) => {
        // Only respond to Coqui
        if (typeof url === "string" && url.includes("5002")) {
          const audioBuffer = Buffer.from("fake-audio-data");
          return {
            ok: true,
            status: 200,
            arrayBuffer: async () => audioBuffer.buffer,
            headers: { get: () => null },
          } as any;
        }
        return {
          ok: false,
          status: 503,
          text: async () => "Not available",
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "coqui",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
        coquiUrl: "http://localhost:5002",
      };

      const result = await synthesizeSpeech("Test", config, "default", "es");
      expect(result?.backend).toBe("coqui");
    });
  });

  // ─── Language Support Tests ─────────────────────────────────────────────────

  describe("Language Support", () => {
    it("should handle all supported languages", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "coqui",
        coquiUrl: "http://localhost:5002",
      };

      const supportedLanguages = [
        "ar", "de", "en", "es", "fr", "hu", "it", "ja", "ko", "nl", "pl", "pt", "ru", "tr", "uk", "zh",
      ];

      for (const lang of supportedLanguages) {
        const result = await synthesizeSpeech("Test", config, "default", lang);
        expect(result).toBeTruthy();
      expect(result?.backend).toBe("coqui");
      }
    });

    it("should fallback gracefully for unsupported language", async () => {
      global.fetch = vi.fn(async () => {
        const audioBuffer = Buffer.from("fake-audio-data");
        return {
          ok: true,
          status: 200,
          arrayBuffer: async () => audioBuffer.buffer,
          headers: { get: () => null },
        } as any;
      });

      const config: TTSConfig = {
        preferredTts: "auto",
        kokoroUrl: "http://localhost:8880",
        coquiUrl: "http://localhost:5002",
      };

      // Russian is not supported by Kokoro, should fallback to Coqui
      const result = await synthesizeSpeech("Test", config, "default", "ru");
      expect(result).toBeTruthy();
      expect(result?.backend).toBe("coqui");
    });
  });
});
