ALTER TABLE `terminator_config` ADD `coquiUrl` varchar(255) DEFAULT 'http://localhost:5002';--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `sileroUrl` varchar(255) DEFAULT 'http://localhost:5003';--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `coquiUrlConfig` varchar(255);--> statement-breakpoint
ALTER TABLE `terminator_config` ADD `sileroUrlConfig` varchar(255);