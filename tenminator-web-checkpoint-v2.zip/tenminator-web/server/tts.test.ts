/**
 * Terminator II — TTS Unit Tests
 * Tests for Coqui XTTS, Silero TTS, and language support (Arabic, Russian)
 */

import { describe, it, expect } from "vitest";
import { TTSConfig } from "./terminator/tts";

describe("Terminator II — TTS Configuration (Coqui, Silero, Arabic, Russian)", () => {
  // ─── TTS Config Tests ─────────────────────────────────────────────────────

  it("TTSConfig: supports Coqui URL", () => {
    const config: TTSConfig = {
      coquiUrl: "http://localhost:5002",
      preferredTts: "coqui",
    };

    expect(config.coquiUrl).toBe("http://localhost:5002");
    expect(config.preferredTts).toBe("coqui");
  });

  it("TTSConfig: supports Silero URL", () => {
    const config: TTSConfig = {
      sileroUrl: "http://localhost:5003",
      preferredTts: "silero",
    };

    expect(config.sileroUrl).toBe("http://localhost:5003");
    expect(config.preferredTts).toBe("silero");
  });

  it("TTSConfig: supports multiple TTS backends in fallback chain", () => {
    const config: TTSConfig = {
      kokoroUrl: "http://localhost:8880",
      coquiUrl: "http://localhost:5002",
      sileroUrl: "http://localhost:5003",
      piperUrl: "http://localhost:5000",
      preferredTts: "auto",
    };

    expect(config.kokoroUrl).toBe("http://localhost:8880");
    expect(config.coquiUrl).toBe("http://localhost:5002");
    expect(config.sileroUrl).toBe("http://localhost:5003");
    expect(config.piperUrl).toBe("http://localhost:5000");
    expect(config.preferredTts).toBe("auto");
  });

  it("TTSConfig: supports API keys for cloud TTS", () => {
    const config: TTSConfig = {
      xaiApiKey: "xai-key-123",
      openaiApiKey: "sk-key-456",
      coquiUrl: "http://localhost:5002",
      preferredTts: "coqui",
    };

    expect(config.xaiApiKey).toBe("xai-key-123");
    expect(config.openaiApiKey).toBe("sk-key-456");
    expect(config.coquiUrl).toBe("http://localhost:5002");
  });

  // ─── Language Support Tests ───────────────────────────────────────────────

  it("TTSConfig: Coqui supports Arabic (ar)", () => {
    const config: TTSConfig = {
      coquiUrl: "http://localhost:5002",
      preferredTts: "coqui",
    };

    // Coqui XTTS supports: ar, de, en, es, fr, hu, it, ja, ko, nl, pl, pt, ru, tr, uk, zh
    const supportedLanguages = [
      "ar",
      "de",
      "en",
      "es",
      "fr",
      "hu",
      "it",
      "ja",
      "ko",
      "nl",
      "pl",
      "pt",
      "ru",
      "tr",
      "uk",
      "zh",
    ];

    expect(supportedLanguages).toContain("ar");
    expect(config.preferredTts).toBe("coqui");
  });

  it("TTSConfig: Silero supports Russian (ru)", () => {
    const config: TTSConfig = {
      sileroUrl: "http://localhost:5003",
      preferredTts: "silero",
    };

    // Silero TTS supports: en, de, es, fr, ru, uk, hi
    const supportedLanguages = ["en", "de", "es", "fr", "ru", "uk", "hi"];

    expect(supportedLanguages).toContain("ru");
    expect(config.preferredTts).toBe("silero");
  });

  it("TTSConfig: Coqui supports Russian (ru)", () => {
    const config: TTSConfig = {
      coquiUrl: "http://localhost:5002",
      preferredTts: "coqui",
    };

    // Coqui XTTS also supports Russian
    const supportedLanguages = [
      "ar",
      "de",
      "en",
      "es",
      "fr",
      "hu",
      "it",
      "ja",
      "ko",
      "nl",
      "pl",
      "pt",
      "ru",
      "tr",
      "uk",
      "zh",
    ];

    expect(supportedLanguages).toContain("ru");
  });

  // ─── Persona Support Tests ────────────────────────────────────────────────

  it("TTSConfig: supports persona selection (default, ani, valentin)", () => {
    const personas = ["default", "ani", "valentin"];

    expect(personas).toContain("default");
    expect(personas).toContain("ani");
    expect(personas).toContain("valentin");
  });

  // ─── Fallback Chain Tests ─────────────────────────────────────────────────

  it("TTSConfig: auto mode tries backends in order", () => {
    const config: TTSConfig = {
      kokoroUrl: "http://localhost:8880",
      coquiUrl: "http://localhost:5002",
      sileroUrl: "http://localhost:5003",
      piperUrl: "http://localhost:5000",
      preferredTts: "auto",
    };

    // In auto mode, the chain is:
    // 1. Kokoro (local, 11 languages)
    // 2. Coqui (local, 17 languages + Arabic)
    // 3. Silero (local, fast)
    // 4. Grok (cloud)
    // 5. OpenAI (cloud)
    // 6. Piper (CPU fallback)

    expect(config.kokoroUrl).toBeDefined();
    expect(config.coquiUrl).toBeDefined();
    expect(config.sileroUrl).toBeDefined();
    expect(config.piperUrl).toBeDefined();
    expect(config.preferredTts).toBe("auto");
  });

  // ─── Environment Variable Fallback Tests ──────────────────────────────────

  it("TTSConfig: can use environment variables as fallback", () => {
    // Simulating env vars
    const kokoroUrl = process.env.KOKORO_URL ?? "http://localhost:8880";
    const coquiUrl = process.env.COQUI_URL ?? "http://localhost:5002";
    const sileroUrl = process.env.SILERO_URL ?? "http://localhost:5003";

    expect(kokoroUrl).toBeDefined();
    expect(coquiUrl).toBeDefined();
    expect(sileroUrl).toBeDefined();
  });

  // ─── Explicit Backend Selection Tests ──────────────────────────────────────

  it("TTSConfig: can explicitly select Coqui backend", () => {
    const config: TTSConfig = {
      coquiUrl: "http://localhost:5002",
      preferredTts: "coqui",
    };

    expect(config.preferredTts).toBe("coqui");
    expect(config.coquiUrl).toBe("http://localhost:5002");
  });

  it("TTSConfig: can explicitly select Silero backend", () => {
    const config: TTSConfig = {
      sileroUrl: "http://localhost:5003",
      preferredTts: "silero",
    };

    expect(config.preferredTts).toBe("silero");
    expect(config.sileroUrl).toBe("http://localhost:5003");
  });

  it("TTSConfig: can explicitly select Kokoro backend", () => {
    const config: TTSConfig = {
      kokoroUrl: "http://localhost:8880",
      preferredTts: "kokoro",
    };

    expect(config.preferredTts).toBe("kokoro");
    expect(config.kokoroUrl).toBe("http://localhost:8880");
  });

  // ─── Cloud Backend Tests ──────────────────────────────────────────────────

  it("TTSConfig: supports Grok Aurora TTS", () => {
    const config: TTSConfig = {
      xaiApiKey: "xai-key-123",
      preferredTts: "grok",
    };

    expect(config.xaiApiKey).toBe("xai-key-123");
    expect(config.preferredTts).toBe("grok");
  });

  it("TTSConfig: supports OpenAI TTS", () => {
    const config: TTSConfig = {
      openaiApiKey: "sk-key-456",
      preferredTts: "openai",
    };

    expect(config.openaiApiKey).toBe("sk-key-456");
    expect(config.preferredTts).toBe("openai");
  });

  // ─── Default Values Tests ─────────────────────────────────────────────────

  it("TTSConfig: provides sensible defaults", () => {
    const config: TTSConfig = {};

    // Defaults should be applied in buildTTSConfig (orchestrator.ts)
    // but the TTSConfig interface itself allows optional fields
    expect(config).toBeDefined();
  });
});
