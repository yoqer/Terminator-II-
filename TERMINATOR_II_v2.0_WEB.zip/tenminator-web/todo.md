# TenMiNaTor Web - Lista de Tareas

## Funcionalidades de la Landing Page
- [x] Diseño de landing page con estilo moderno y atractivo
- [x] Panel lateral para visualizar código y datos cargados
- [x] Sistema de subida de archivos (CSV, JSON, TXT)
- [x] Botones de iniciar/pausar entrenamiento
- [x] Visualización en tiempo real del progreso de entrenamiento
- [x] Área de resultados y métricas
- [x] Configuración básica de hiperparámetros

## Backend y API
- [x] Endpoint para subir archivos
- [x] Endpoint para iniciar entrenamiento
- [x] Endpoint para pausar/reanudar entrenamiento
- [x] Endpoint para obtener estado del entrenamiento
- [x] Integración con TenMiNaTor framework
- [x] Manejo de sesiones de entrenamiento

## Preparación para PyPI
- [x] Copiar framework TenMiNaTor al proyecto
- [x] Crear estructura correcta para paquete PyPI
- [x] Configurar setup.py con dependencias
- [x] Crear README_PYPI.md con instrucciones de instalación pip
- [x] Crear MANIFEST.in para incluir archivos necesarios
- [x] Documentar comandos de instalación y uso

## Testing y Validación
- [x] Probar subida de archivos
- [x] Probar inicio/pausa de entrenamiento
- [x] Validar visualización de datos
- [x] Verificar funcionamiento del panel lateral

## Entrega Final
- [ ] Crear checkpoint del proyecto web
- [ ] Generar paquete para PyPI
- [ ] Documentación completa

## Revisión Completa de Código v2 (Corrección de Fallos + Idiomas)
- [x] Corregir todos los `<Link><a>` anidados en Home.tsx
- [x] Añadir sistema i18n completo con 20 idiomas
- [x] Añadir selector de idioma en la barra de navegación
- [x] Añadir persistencia de idioma en localStorage
- [x] Mejorar Training.tsx con gráfico de pérdida en tiempo real
- [x] Añadir manejo de errores robusto en routers.ts
- [x] Corregir trainingManager: manejo de errores, shutdown graceful
- [x] Añadir validación de archivo en upload
- [x] Mejorar UX: estados de carga, mensajes vacíos, feedback visual

## TerminaTodo v2 + Endpoint de Entrenamiento Completo
- [x] Auditoría completa de TerminaTodo
- [x] Completar TerminaTodo v2: auth JWT real, SQLite persistencia, 33 tests pasando
- [x] Módulos completos: cloud_manager, remote_manager, sync_manager, training_bridge, CLI
- [x] ZIP para GitHub (yoqer/TerminaTodo) listo
- [x] Paquete PyPI construido
- [x] Endpoint training avanzado: presets, hardware info, cuantización, métricas
- [x] Training.tsx mejorado: presets selector, config avanzada, barra de progreso
- [x] routers.ts: modelConfigSchema completo

## tenIII v3.0.0 - Página de Descargas y Documentación
- [x] Crear página Downloads.tsx
- [x] Subir ZIP de tenIII a CDN
- [x] Subir 8 informes PDF de documentación técnica
- [x] Añadir sección de instalación con múltiples opciones
- [x] Registrar ruta /downloads en App.tsx
- [x] Añadir botón de descarga en Home.tsx

## Sidebar Lateral con Recursos (PENDIENTE)
- [ ] Crear página Resources.tsx con sidebar lateral replegable
- [ ] Sección Notebooks: Unsloth, Colab, Jupyter, Conda, NVIDIA, AMD ROCm, IBM
- [ ] Sección Datasets: HuggingFace, Kaggle, Google, Académicos, Local
- [ ] Sección Probar Modelo: LM Studio, Ollama, llama.cpp, vLLM, Chat Directo
- [ ] Registrar ruta /resources en App.tsx

## Terminator II — Sistema Multicanal Multimodal

### Infraestructura base
- [x] Esquema de base de datos (conversations, messages, terminator_config)
- [x] Migración de base de datos (pnpm db:push) — 3 tablas nuevas
- [x] Módulo LLM unificado (Ollama, LM Studio, Grok, OpenAI, Kimi, DeepSeek)
- [x] Módulo TTS/STT (Grok Aurora, OpenAI TTS, Piper local)
- [x] Módulo de video (Grok Video, Wan2.1, LTX-Video)
- [x] Orquestador multimodal (LLM + TTS + Video en paralelo)

### Canales
- [x] Canal WhatsApp Business API (webhook POST/GET con verificación)
- [x] Canal Telegram Bot (webhook POST, texto + voz + video)
- [x] Canal SMS/MMS Twilio (webhook POST, respuesta texto/enlace)
- [x] Canal voz Twilio ConversationRelay (TwiML + WebSocket /ws/voice)
- [x] Canal videollamada Twilio Video (token REST /webhook/video/token)

### Router y UI
- [x] Router tRPC (chat, getHistory, getConfig, saveConfig, checkBackends, testWebhook)
- [x] Página de chat responsive TerminatorChat.tsx (sidebar modelos, burbujas multimedia)
- [x] Página de configuración TerminatorConfig.tsx (todas las claves API + guía webhooks)
- [x] Rutas en App.tsx (/terminator, /terminator/config)
- [x] Botón Terminator II en Home.tsx

### Tests
- [x] Tests Vitest: parsers de canales, orquestador, backends — 10/10 pasados (15 total en suite)

### Pendiente (configuración externa)
- [ ] Configurar secrets en producción: TWILIO_*, WHATSAPP_*, TELEGRAM_BOT_TOKEN, XAI_API_KEY, etc.
- [ ] Configurar webhooks en Meta Developers (WhatsApp), BotFather (Telegram), Twilio Console
- [ ] Integrar Kokoro TTS local (11 idiomas) desde repositorios yoqer
- [ ] Integrar modelos de video locales (Wan2.1, LTX-Video) cuando GPU disponible
- [ ] Fine-tuning de voz con tenIII (KokoroVoiceTrainer)

## Mejoras v2 — Terminator II

### Mejora 1: Kokoro TTS local (11 idiomas)
- [x] Añadir kokoroTTS() en tts.ts con llamada HTTP al contenedor Docker de Kokoro (puerto 8880)
- [x] Mapa de idiomas Kokoro: es, en, de, fr, it, pt, hi, ja, ko, zh, ar
- [x] Mapa de voces Kokoro por personaje (af_heart, af_sky, am_adam, etc.)
- [x] Insertar Kokoro como primer backend en la cadena TTS (antes de Grok)
- [x] Actualizar TTSConfig con kokoroUrl y piperUrl opcionales
- [x] Actualizar TerminatorConfig.tsx con campo URL de Kokoro (vía ApiKeyManager)
- [x] Actualizar checkBackends para detectar Kokoro activo

### Mejora 2: Página videollamada WebRTC (/terminator/video-call)
- [x] Crear TerminatorVideoCall.tsx con sala Twilio Video
- [x] Instalar twilio-video (cliente JS) en el frontend
- [x] Conectar al endpoint getVideoToken para obtener token de sala
- [x] Mostrar video local + track de respuesta del Terminator
- [x] Reproducir video generado por IA en el track remoto
- [x] Registrar ruta /terminator/video-call en App.tsx
- [x] Añadir botón de videollamada en TerminatorChat.tsx

### Mejora 3: Secrets de producción + Auditoría
- [x] Añadir TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER
- [x] Añadir TWILIO_API_KEY_SID, TWILIO_API_KEY_SECRET (AccessToken JWT correcto)
- [x] Añadir WHATSAPP_TOKEN, WHATSAPP_PHONE_NUMBER_ID, WHATSAPP_VERIFY_TOKEN
- [x] Añadir TELEGRAM_BOT_TOKEN
- [x] Añadir XAI_API_KEY (Grok), OPENAI_API_KEY, MOONSHOT_API_KEY, DEEPSEEK_API_KEY
- [x] Env fallback en orchestrator.ts, llm.ts, tts.ts, video.ts
- [x] Hook useApiKeys: localStorage + BD + presencia de claves
- [x] Componente ApiKeyManager: grupos colapsables, show/hide, estado servidor
- [x] TerminatorConfig.tsx reescrito con tabs (Claves API / Preferencias / Webhooks)
- [x] Corregir AccessToken Twilio: apiKeySid/apiKeySecret en lugar de authToken
- [x] Añadir kokoroUrl y piperUrl al schema BD + migración aplicada
- [x] Renombrar Terminator 1 → Terminator II en toda la UI y código
- [x] 15 tests pasando (3 suites)


## Mejoras v3 — Terminator II Completo (Coqui/Silero, Docker Kokoro, Modelos Genéricos, OpenAI Realtime)

### Mejora 4: TTS con Árabe (Coqui XTTS + Silero)
- [ ] Investigar Kokoro árabe en todos los repos de GitHub
- [ ] Implementar Coqui TTS (XTTS) con 17 idiomas incluyendo árabe
- [ ] Implementar Silero TTS con soporte de idiomas
- [ ] Añadir selector de motor TTS: Kokoro / Coqui / Silero / Grok / OpenAI
- [ ] Mapa de idiomas árabe: código 'ar', voces Coqui/Silero
- [ ] Tests de TTS con árabe en tts.test.ts

### Mejora 5: Funciones Docker de Kokoro-TTS-Docker-9
- [ ] Implementar streaming SSE en kokoroTTS() (stream_format: "sse")
- [ ] Añadir volume_multiplier (0.1-2.0) en kokoroTTS()
- [ ] Endpoint GET /v1/voices (lista de voces Kokoro)
- [ ] Endpoint GET /v1/models (modelos activos)
- [ ] Endpoint GET /docs (Swagger UI)
- [ ] Soporte KOKORO_API_KEY (Bearer token)
- [ ] Modo offline KOKORO_LOCAL_ONLY (sin descargas HuggingFace)
- [ ] Soporte CUDA en Dockerfile (opcional)

### Mejora 6: Sistema de Modelos Locales Genéricos
- [ ] Crear tabla `custom_models` en schema BD (type, name, url/path, enabled, config)
- [ ] Interfaz `CustomModel` (LLM, video, avatar, voice, STT)
- [ ] Componente `CustomModelManager` en TerminatorConfig (CRUD)
- [ ] Soporte para URLs HTTP (FastAPI local) y rutas locales (CLI)
- [ ] Validación de conectividad al agregar modelo
- [ ] Fallback en cadena: modelo custom → backend estándar

### Mejora 7: OpenAI Realtime API
- [ ] Integrar OpenAI Realtime API (voz bidireccional en tiempo real)
- [ ] Crear módulo `realtime.ts` con WebSocket client
- [ ] Endpoint `/ws/realtime` en servidor
- [ ] Página `/terminator/realtime` con interfaz de voz
- [ ] Soporte de eventos: audio.delta, text.delta, response.done

### Mejora 8: Grok Video con Referencia de Imagen/Video
- [ ] Mejorar grokVideo() para aceptar referencia de imagen/video
- [ ] Pipeline: LLM → "Para Generar Video quiero: ..." → Grok Video API
- [ ] Soporte de extensión de video (siguiente mensaje continúa el video)
- [ ] Voces Grok: Ani, Valentín, Eve, Ara, Rex, Sal, Leo

### Mejora 9: Panel Centralizado de Configuración v2
- [ ] Crear página `/terminator/settings` con tabs completos
- [ ] Tab 1: Claves API (Grok, OpenAI, Twilio, WhatsApp, Telegram, Coqui, Silero)
- [ ] Tab 2: Selección de Modelos (LLM, TTS, STT, Video, Avatar)
- [ ] Tab 3: Modelos Personalizados (CRUD de custom_models)
- [ ] Tab 4: Caché Local (localStorage status, tamaño, limpiar)
- [ ] Tab 5: Webhooks (WhatsApp, Telegram, SMS, Voice, Video)
- [ ] Persistencia en BD + localStorage para caché
- [ ] Indicadores de estado (conectado/desconectado) por backend

### Mejora 10: Integración SMS Nativo + LM Studio
- [ ] SMS nativo via Twilio Programmable SMS (ya implementado, verificar)
- [ ] LM Studio local en puerto 1234 (ya implementado, verificar)
- [ ] Tests de SMS y LM Studio

### Mejora 11: Video Locales (Minimax, CogVideoX, etc.)
- [ ] Investigar generadores de video locales: Minimax, CogVideoX, Mochi, Hunyuan
- [ ] Implementar soporte genérico en `video.ts` (URL + modelo)
- [ ] Selector de motor video: Grok / Minimax / CogVideoX / Custom

### Mejora 12: Tests y Compilación Final
- [ ] Tests de Coqui TTS, Silero TTS, Kokoro Docker
- [ ] Tests de custom_models CRUD
- [ ] Tests de OpenAI Realtime
- [ ] Tests de Grok Video con referencia
- [ ] Compilación TypeScript limpia
- [ ] 30+ tests pasando

### Mejora 13: Documentación y ZIPs Finales
- [ ] Actualizar MANUAL_DESARROLLO_TERMINATOR_II.md con todas las nuevas funciones
- [ ] Actualizar AUDITORIA_TERMINATOR_II.md con v3 hallazgos
- [ ] Crear ZIP web completo (código + docs + Docker Compose)
- [ ] Crear ZIP PyPI TerminatorII v3.0.0
- [ ] Crear ZIP de ejemplos: Docker Compose, .env, notebooks
