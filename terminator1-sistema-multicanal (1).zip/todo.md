# TenMiNaTor Web - Lista de Tareas

## Funcionalidades de la Landing Page
- [x] Diseño de landing page con estilo moderno y atractivo
- [x] Panel lateral para visualizar código y datos cargados
- [x] Sistema de subida de archivos (CSV, JSON, TXT)
- [x] Botones de iniciar/pausar entrenamiento
- [x] Visualización en tiempo real del progreso de entrenamiento
- [x] Área de resultados y métricas
- [x] Configuración básica de hiperparámetros

## Backend y API
- [x] Endpoint para subir archivos
- [x] Endpoint para iniciar entrenamiento
- [x] Endpoint para pausar/reanudar entrenamiento
- [x] Endpoint para obtener estado del entrenamiento
- [x] Integración con TenMiNaTor framework
- [x] Manejo de sesiones de entrenamiento

## Preparación para PyPI
- [x] Copiar framework TenMiNaTor al proyecto
- [x] Crear estructura correcta para paquete PyPI
- [x] Configurar setup.py con dependencias
- [x] Crear README_PYPI.md con instrucciones de instalación pip
- [x] Crear MANIFEST.in para incluir archivos necesarios
- [x] Documentar comandos de instalación y uso

## Testing y Validación
- [x] Probar subida de archivos
- [x] Probar inicio/pausa de entrenamiento
- [x] Validar visualización de datos
- [x] Verificar funcionamiento del panel lateral

## Entrega Final
- [ ] Crear checkpoint del proyecto web
- [ ] Generar paquete para PyPI
- [ ] Documentación completa

## Revisión Completa de Código v2 (Corrección de Fallos + Idiomas)
- [x] Corregir todos los `<Link><a>` anidados en Home.tsx
- [x] Añadir sistema i18n completo con 20 idiomas
- [x] Añadir selector de idioma en la barra de navegación
- [x] Añadir persistencia de idioma en localStorage
- [x] Mejorar Training.tsx con gráfico de pérdida en tiempo real
- [x] Añadir manejo de errores robusto en routers.ts
- [x] Corregir trainingManager: manejo de errores, shutdown graceful
- [x] Añadir validación de archivo en upload
- [x] Mejorar UX: estados de carga, mensajes vacíos, feedback visual

## TerminaTodo v2 + Endpoint de Entrenamiento Completo
- [x] Auditoría completa de TerminaTodo
- [x] Completar TerminaTodo v2: auth JWT real, SQLite persistencia, 33 tests pasando
- [x] Módulos completos: cloud_manager, remote_manager, sync_manager, training_bridge, CLI
- [x] ZIP para GitHub (yoqer/TerminaTodo) listo
- [x] Paquete PyPI construido
- [x] Endpoint training avanzado: presets, hardware info, cuantización, métricas
- [x] Training.tsx mejorado: presets selector, config avanzada, barra de progreso
- [x] routers.ts: modelConfigSchema completo

## tenIII v3.0.0 - Página de Descargas y Documentación
- [x] Crear página Downloads.tsx
- [x] Subir ZIP de tenIII a CDN
- [x] Subir 8 informes PDF de documentación técnica
- [x] Añadir sección de instalación con múltiples opciones
- [x] Registrar ruta /downloads en App.tsx
- [x] Añadir botón de descarga en Home.tsx

## Sidebar Lateral con Recursos (PENDIENTE)
- [ ] Crear página Resources.tsx con sidebar lateral replegable
- [ ] Sección Notebooks: Unsloth, Colab, Jupyter, Conda, NVIDIA, AMD ROCm, IBM
- [ ] Sección Datasets: HuggingFace, Kaggle, Google, Académicos, Local
- [ ] Sección Probar Modelo: LM Studio, Ollama, llama.cpp, vLLM, Chat Directo
- [ ] Registrar ruta /resources en App.tsx

## Terminator 1 — Sistema Multicanal Multimodal

### Infraestructura base
- [x] Esquema de base de datos (conversations, messages, terminator_config)
- [x] Migración de base de datos (pnpm db:push) — 3 tablas nuevas
- [x] Módulo LLM unificado (Ollama, LM Studio, Grok, OpenAI, Kimi, DeepSeek)
- [x] Módulo TTS/STT (Grok Aurora, OpenAI TTS, Piper local)
- [x] Módulo de video (Grok Video, Wan2.1, LTX-Video)
- [x] Orquestador multimodal (LLM + TTS + Video en paralelo)

### Canales
- [x] Canal WhatsApp Business API (webhook POST/GET con verificación)
- [x] Canal Telegram Bot (webhook POST, texto + voz + video)
- [x] Canal SMS/MMS Twilio (webhook POST, respuesta texto/enlace)
- [x] Canal voz Twilio ConversationRelay (TwiML + WebSocket /ws/voice)
- [x] Canal videollamada Twilio Video (token REST /webhook/video/token)

### Router y UI
- [x] Router tRPC (chat, getHistory, getConfig, saveConfig, checkBackends, testWebhook)
- [x] Página de chat responsive TerminatorChat.tsx (sidebar modelos, burbujas multimedia)
- [x] Página de configuración TerminatorConfig.tsx (todas las claves API + guía webhooks)
- [x] Rutas en App.tsx (/terminator, /terminator/config)
- [x] Botón Terminator 1 en Home.tsx

### Tests
- [x] Tests Vitest: parsers de canales, orquestador, backends — 10/10 pasados (15 total en suite)

### Pendiente (configuración externa)
- [ ] Configurar secrets en producción: TWILIO_*, WHATSAPP_*, TELEGRAM_BOT_TOKEN, XAI_API_KEY, etc.
- [ ] Configurar webhooks en Meta Developers (WhatsApp), BotFather (Telegram), Twilio Console
- [ ] Integrar Kokoro TTS local (11 idiomas) desde repositorios yoqer
- [ ] Integrar modelos de video locales (Wan2.1, LTX-Video) cuando GPU disponible
- [ ] Fine-tuning de voz con tenIII (KokoroVoiceTrainer)
