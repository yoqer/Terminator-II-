import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, ArrowLeft, Save, CheckCircle, AlertCircle, RefreshCw } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";

interface ConfigForm {
  ollamaUrl: string;
  lmstudioUrl: string;
  xaiApiKey: string;
  openaiApiKey: string;
  moonshotApiKey: string;
  deepseekApiKey: string;
  twilioAccountSid: string;
  twilioAuthToken: string;
  twilioPhoneNumber: string;
  whatsappToken: string;
  whatsappPhoneNumberId: string;
  whatsappVerifyToken: string;
  telegramBotToken: string;
  defaultPersona: string;
  defaultLlm: string;
  defaultTts: string;
  defaultVideo: string;
  defaultLanguage: string;
}

const DEFAULT_FORM: ConfigForm = {
  ollamaUrl: "http://localhost:11434",
  lmstudioUrl: "http://localhost:1234",
  xaiApiKey: "",
  openaiApiKey: "",
  moonshotApiKey: "",
  deepseekApiKey: "",
  twilioAccountSid: "",
  twilioAuthToken: "",
  twilioPhoneNumber: "",
  whatsappToken: "",
  whatsappPhoneNumberId: "",
  whatsappVerifyToken: "",
  telegramBotToken: "",
  defaultPersona: "default",
  defaultLlm: "auto",
  defaultTts: "auto",
  defaultVideo: "none",
  defaultLanguage: "es",
};

export default function TerminatorConfig() {
  const { user } = useAuth();
  const [form, setForm] = useState<ConfigForm>(DEFAULT_FORM);
  const [saved, setSaved] = useState(false);

  const configQuery = trpc.terminator.getConfig.useQuery(undefined, {
    enabled: !!user,
  });

  useEffect(() => {
    const data = configQuery.data;
    if (data) {
      setForm((prev) => ({
        ...prev,
        ollamaUrl: data.ollamaUrl ?? prev.ollamaUrl,
        lmstudioUrl: data.lmstudioUrl ?? prev.lmstudioUrl,
        xaiApiKey: data.xaiApiKey ?? "",
        openaiApiKey: data.openaiApiKey ?? "",
        moonshotApiKey: data.moonshotApiKey ?? "",
        deepseekApiKey: data.deepseekApiKey ?? "",
        twilioAccountSid: data.twilioAccountSid ?? "",
        twilioAuthToken: data.twilioAuthToken ?? "",
        twilioPhoneNumber: data.twilioPhoneNumber ?? "",
        whatsappToken: data.whatsappToken ?? "",
        whatsappPhoneNumberId: data.whatsappPhoneNumberId ?? "",
        whatsappVerifyToken: data.whatsappVerifyToken ?? "",
        telegramBotToken: data.telegramBotToken ?? "",
        defaultPersona: data.defaultPersona ?? "default",
        defaultLlm: data.defaultLlm ?? "auto",
        defaultTts: data.defaultTts ?? "auto",
        defaultVideo: data.defaultVideo ?? "none",
        defaultLanguage: data.defaultLanguage ?? "es",
      }));
    }
  }, [configQuery.data]);

  const saveMutation = trpc.terminator.saveConfig.useMutation({
    onSuccess: () => {
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    },
  });

  const backendsQuery = trpc.terminator.checkBackends.useQuery({
    ollamaUrl: form.ollamaUrl,
    lmstudioUrl: form.lmstudioUrl,
  });

  const set = (key: keyof ConfigForm) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((prev) => ({ ...prev, [key]: e.target.value }));

  const handleSave = () => {
    const payload: Partial<ConfigForm> = {};
    for (const [k, v] of Object.entries(form)) {
      if (v && v !== "") payload[k as keyof ConfigForm] = v;
    }
    saveMutation.mutate(payload);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center text-gray-400">
        <div className="text-center">
          <p className="mb-4">Debes iniciar sesión para acceder a la configuración</p>
          <Link href="/"><Button variant="outline">Volver al inicio</Button></Link>
        </div>
      </div>
    );
  }

  const backends = backendsQuery.data;

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-900 px-4 py-3 flex items-center gap-3">
        <Link href="/terminator">
          <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <div>
          <h1 className="font-semibold text-white">Configuración del Terminator 1</h1>
          <p className="text-xs text-gray-400">Claves API, canales y valores predeterminados</p>
        </div>
        <div className="ml-auto flex gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => backendsQuery.refetch()}
            className="text-gray-400"
          >
            <RefreshCw className="w-3 h-3 mr-1" />
            Verificar
          </Button>
          <Button
            onClick={handleSave}
            disabled={saveMutation.isPending}
            className="bg-red-600 hover:bg-red-700"
            size="sm"
          >
            {saveMutation.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin mr-1" />
            ) : saved ? (
              <CheckCircle className="w-4 h-4 mr-1" />
            ) : (
              <Save className="w-4 h-4 mr-1" />
            )}
            {saved ? "Guardado" : "Guardar"}
          </Button>
        </div>
      </header>

      <div className="max-w-3xl mx-auto p-6 space-y-8">
        {/* Backend status */}
        {backends && (
          <div className="bg-gray-900 rounded-xl p-4 border border-gray-800">
            <h2 className="text-sm font-semibold text-gray-300 mb-3">Estado de backends</h2>
            <div className="flex flex-wrap gap-2">
              {[
                { key: "ollama", label: "Ollama" },
                { key: "lmstudio", label: "LM Studio" },
                { key: "grok", label: "Grok xAI" },
                { key: "openai", label: "OpenAI" },
                { key: "kimi", label: "Kimi" },
                { key: "deepseek", label: "DeepSeek" },
              ].map(({ key, label }) => {
                const ok = backends[key as keyof typeof backends];
                return (
                  <div key={key} className="flex items-center gap-1.5">
                    {ok ? (
                      <CheckCircle className="w-3.5 h-3.5 text-green-400" />
                    ) : (
                      <AlertCircle className="w-3.5 h-3.5 text-gray-600" />
                    )}
                    <span className={`text-xs ${ok ? "text-green-400" : "text-gray-600"}`}>{label}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Local backends */}
        <section className="space-y-4">
          <h2 className="text-sm font-semibold text-gray-300 border-b border-gray-800 pb-2">Backends locales</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label className="text-xs text-gray-400">URL de Ollama</Label>
              <Input value={form.ollamaUrl} onChange={set("ollamaUrl")} className="bg-gray-800 border-gray-700 text-sm h-9" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-gray-400">URL de LM Studio</Label>
              <Input value={form.lmstudioUrl} onChange={set("lmstudioUrl")} className="bg-gray-800 border-gray-700 text-sm h-9" />
            </div>
          </div>
        </section>

        {/* Cloud APIs */}
        <section className="space-y-4">
          <h2 className="text-sm font-semibold text-gray-300 border-b border-gray-800 pb-2">APIs en la nube</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { key: "xaiApiKey", label: "Grok xAI API Key", placeholder: "xai-..." },
              { key: "openaiApiKey", label: "OpenAI API Key", placeholder: "sk-..." },
              { key: "moonshotApiKey", label: "Kimi (Moonshot) API Key", placeholder: "sk-..." },
              { key: "deepseekApiKey", label: "DeepSeek API Key", placeholder: "sk-..." },
            ].map(({ key, label, placeholder }) => (
              <div key={key} className="space-y-1.5">
                <Label className="text-xs text-gray-400">{label}</Label>
                <Input
                  type="password"
                  value={form[key as keyof ConfigForm]}
                  onChange={set(key as keyof ConfigForm)}
                  placeholder={placeholder}
                  className="bg-gray-800 border-gray-700 text-sm h-9"
                />
              </div>
            ))}
          </div>
        </section>

        {/* Twilio */}
        <section className="space-y-4">
          <h2 className="text-sm font-semibold text-gray-300 border-b border-gray-800 pb-2">
            Twilio — SMS, MMS y llamadas de voz
          </h2>
          <p className="text-xs text-gray-500">
            Configura un número Twilio para recibir SMS/MMS y llamadas de voz. El webhook de voz es{" "}
            <code className="bg-gray-800 px-1 rounded text-red-400">/twiml</code>.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { key: "twilioAccountSid", label: "Account SID", placeholder: "AC..." },
              { key: "twilioAuthToken", label: "Auth Token", placeholder: "..." },
              { key: "twilioPhoneNumber", label: "Número Twilio", placeholder: "+34..." },
            ].map(({ key, label, placeholder }) => (
              <div key={key} className="space-y-1.5">
                <Label className="text-xs text-gray-400">{label}</Label>
                <Input
                  type={key === "twilioAuthToken" ? "password" : "text"}
                  value={form[key as keyof ConfigForm]}
                  onChange={set(key as keyof ConfigForm)}
                  placeholder={placeholder}
                  className="bg-gray-800 border-gray-700 text-sm h-9"
                />
              </div>
            ))}
          </div>
        </section>

        {/* WhatsApp */}
        <section className="space-y-4">
          <h2 className="text-sm font-semibold text-gray-300 border-b border-gray-800 pb-2">
            WhatsApp Business API
          </h2>
          <p className="text-xs text-gray-500">
            Webhook URL: <code className="bg-gray-800 px-1 rounded text-red-400">/webhook/whatsapp</code>
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { key: "whatsappToken", label: "Access Token", placeholder: "EAABs..." },
              { key: "whatsappPhoneNumberId", label: "Phone Number ID", placeholder: "123456..." },
              { key: "whatsappVerifyToken", label: "Verify Token", placeholder: "mi_token_secreto" },
            ].map(({ key, label, placeholder }) => (
              <div key={key} className="space-y-1.5">
                <Label className="text-xs text-gray-400">{label}</Label>
                <Input
                  type={key === "whatsappToken" ? "password" : "text"}
                  value={form[key as keyof ConfigForm]}
                  onChange={set(key as keyof ConfigForm)}
                  placeholder={placeholder}
                  className="bg-gray-800 border-gray-700 text-sm h-9"
                />
              </div>
            ))}
          </div>
        </section>

        {/* Telegram */}
        <section className="space-y-4">
          <h2 className="text-sm font-semibold text-gray-300 border-b border-gray-800 pb-2">
            Telegram Bot
          </h2>
          <p className="text-xs text-gray-500">
            Webhook URL: <code className="bg-gray-800 px-1 rounded text-red-400">/webhook/telegram</code>
          </p>
          <div className="space-y-1.5 max-w-sm">
            <Label className="text-xs text-gray-400">Bot Token</Label>
            <Input
              type="password"
              value={form.telegramBotToken}
              onChange={set("telegramBotToken")}
              placeholder="123456:ABC..."
              className="bg-gray-800 border-gray-700 text-sm h-9"
            />
          </div>
        </section>

        {/* Defaults */}
        <section className="space-y-4">
          <h2 className="text-sm font-semibold text-gray-300 border-b border-gray-800 pb-2">Valores predeterminados</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <Label className="text-xs text-gray-400">Personaje</Label>
              <Select value={form.defaultPersona} onValueChange={(v) => setForm((p) => ({ ...p, defaultPersona: v }))}>
                <SelectTrigger className="h-9 text-sm bg-gray-800 border-gray-700"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="default">Terminator</SelectItem>
                  <SelectItem value="ani">Ani</SelectItem>
                  <SelectItem value="valentin">Valentín</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-gray-400">LLM</Label>
              <Select value={form.defaultLlm} onValueChange={(v) => setForm((p) => ({ ...p, defaultLlm: v }))}>
                <SelectTrigger className="h-9 text-sm bg-gray-800 border-gray-700"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="auto">Auto</SelectItem>
                  <SelectItem value="ollama">Ollama</SelectItem>
                  <SelectItem value="lmstudio">LM Studio</SelectItem>
                  <SelectItem value="grok">Grok</SelectItem>
                  <SelectItem value="openai">OpenAI</SelectItem>
                  <SelectItem value="kimi">Kimi</SelectItem>
                  <SelectItem value="deepseek">DeepSeek</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-gray-400">TTS</Label>
              <Select value={form.defaultTts} onValueChange={(v) => setForm((p) => ({ ...p, defaultTts: v }))}>
                <SelectTrigger className="h-9 text-sm bg-gray-800 border-gray-700"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="auto">Auto</SelectItem>
                  <SelectItem value="grok">Grok Aurora</SelectItem>
                  <SelectItem value="openai">OpenAI TTS</SelectItem>
                  <SelectItem value="piper">Piper (local)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-gray-400">Video</Label>
              <Select value={form.defaultVideo} onValueChange={(v) => setForm((p) => ({ ...p, defaultVideo: v }))}>
                <SelectTrigger className="h-9 text-sm bg-gray-800 border-gray-700"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Sin video</SelectItem>
                  <SelectItem value="grok">Grok Video</SelectItem>
                  <SelectItem value="wan2">Wan2.1 (local)</SelectItem>
                  <SelectItem value="ltx">LTX-Video (local)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-gray-400">Idioma</Label>
              <Select value={form.defaultLanguage} onValueChange={(v) => setForm((p) => ({ ...p, defaultLanguage: v }))}>
                <SelectTrigger className="h-9 text-sm bg-gray-800 border-gray-700"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="es">Español</SelectItem>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="de">Deutsch</SelectItem>
                  <SelectItem value="fr">Français</SelectItem>
                  <SelectItem value="it">Italiano</SelectItem>
                  <SelectItem value="pt">Português</SelectItem>
                  <SelectItem value="zh">中文</SelectItem>
                  <SelectItem value="ja">日本語</SelectItem>
                  <SelectItem value="ko">한국어</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </section>

        {/* Webhook guide */}
        <section className="bg-gray-900 rounded-xl p-4 border border-gray-800 space-y-3">
          <h2 className="text-sm font-semibold text-gray-300">Guía de webhooks</h2>
          <div className="space-y-2 text-xs text-gray-400">
            <div className="flex items-start gap-2">
              <Badge className="bg-green-900 text-green-300 text-[10px]">WhatsApp</Badge>
              <span>Configura en Meta Developers → tu app → Webhooks → URL: <code className="text-red-400">https://tudominio/webhook/whatsapp</code></span>
            </div>
            <div className="flex items-start gap-2">
              <Badge className="bg-blue-900 text-blue-300 text-[10px]">Telegram</Badge>
              <span>Ejecuta: <code className="text-red-400">curl -X POST https://api.telegram.org/bot&lt;TOKEN&gt;/setWebhook?url=https://tudominio/webhook/telegram</code></span>
            </div>
            <div className="flex items-start gap-2">
              <Badge className="bg-red-900 text-red-300 text-[10px]">SMS/Voz</Badge>
              <span>En Twilio Console → tu número → Messaging: <code className="text-red-400">/webhook/sms</code> | Voice: <code className="text-red-400">/twiml</code></span>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
