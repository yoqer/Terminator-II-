import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { Brain, Zap, Database, Code2, Gauge, Shield, ArrowRight, Github, Download } from "lucide-react";
import { Link } from "wouter";
import { useI18n } from "@/lib/i18n";
import { LanguageSelector } from "@/components/LanguageSelector";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const { t } = useI18n();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <nav className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
            TenMiNaTor
          </div>
          <div className="flex items-center gap-2">
            <LanguageSelector />
            {isAuthenticated ? (
              <>
                <span className="text-slate-400 hidden sm:inline">
                  {t("nav.hello")}, {user?.name}
                </span>
                <Button asChild className="bg-blue-600 hover:bg-blue-700">
                  <Link href="/training">{t("nav.training")}</Link>
                </Button>
              </>
            ) : (
              <Button asChild className="bg-blue-600 hover:bg-blue-700">
                <a href={getLoginUrl()}>{t("nav.login")}</a>
              </Button>
            )}
          </div>
        </div>
      </nav>

      <section className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600/20 border border-blue-500/30 rounded-full text-blue-400 text-sm">
            <Zap className="w-4 h-4" />
            {t("hero.badge")}
          </div>

          <h1 className="text-6xl font-bold text-white leading-tight">
            {t("hero.title1")}
            <br />
            <span className="bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
              {t("hero.title2")}
            </span>
          </h1>

          <p className="text-xl text-slate-400 max-w-2xl mx-auto">
            {t("hero.description")}
          </p>

          <div className="flex gap-4 justify-center flex-wrap">
            {isAuthenticated ? (
              <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8">
                <Link href="/training" className="flex items-center gap-2">
                  {t("hero.start")}
                  <ArrowRight className="w-5 h-5" />
                </Link>
              </Button>
            ) : (
              <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8">
                <a href={getLoginUrl()} className="flex items-center gap-2">
                  {t("hero.login")}
                  <ArrowRight className="w-5 h-5" />
                </a>
              </Button>
            )}
            <Button
              asChild
              size="lg"
              variant="outline"
              className="bg-transparent border-slate-700 text-white hover:bg-slate-800 text-lg px-8"
            >
              <a href="#features">{t("hero.features")}</a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="bg-transparent border-slate-700 text-white hover:bg-slate-800 text-lg px-8"
            >
              <Link href="/downloads" className="flex items-center gap-2">
                <Download className="w-5 h-5" />
                tenIII v3.1.3
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              className="bg-gradient-to-r from-red-600 to-orange-500 hover:from-red-700 hover:to-orange-600 text-white text-lg px-8"
            >
              <Link href="/terminator" className="flex items-center gap-2">
                🤖 Terminator 1
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <section id="features" className="container mx-auto px-4 py-20">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">{t("features.title")}</h2>
          <p className="text-slate-400 text-lg">{t("features.subtitle")}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="bg-slate-900/50 border-slate-800 hover:border-blue-500/50 transition-colors">
            <CardHeader>
              <Brain className="w-12 h-12 text-blue-500 mb-4" />
              <CardTitle className="text-white">{t("features.autograd.title")}</CardTitle>
              <CardDescription>{t("features.autograd.desc")}</CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 hover:border-purple-500/50 transition-colors">
            <CardHeader>
              <Zap className="w-12 h-12 text-purple-500 mb-4" />
              <CardTitle className="text-white">{t("features.multibackend.title")}</CardTitle>
              <CardDescription>{t("features.multibackend.desc")}</CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 hover:border-pink-500/50 transition-colors">
            <CardHeader>
              <Database className="w-12 h-12 text-pink-500 mb-4" />
              <CardTitle className="text-white">{t("features.data.title")}</CardTitle>
              <CardDescription>{t("features.data.desc")}</CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 hover:border-green-500/50 transition-colors">
            <CardHeader>
              <Code2 className="w-12 h-12 text-green-500 mb-4" />
              <CardTitle className="text-white">{t("features.api.title")}</CardTitle>
              <CardDescription>{t("features.api.desc")}</CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 hover:border-yellow-500/50 transition-colors">
            <CardHeader>
              <Gauge className="w-12 h-12 text-yellow-500 mb-4" />
              <CardTitle className="text-white">{t("features.system.title")}</CardTitle>
              <CardDescription>{t("features.system.desc")}</CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 hover:border-red-500/50 transition-colors">
            <CardHeader>
              <Shield className="w-12 h-12 text-red-500 mb-4" />
              <CardTitle className="text-white">{t("features.production.title")}</CardTitle>
              <CardDescription>{t("features.production.desc")}</CardDescription>
            </CardHeader>
          </Card>
        </div>
      </section>

      <section className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto">
          <Card className="bg-gradient-to-br from-blue-600/20 to-purple-600/20 border-blue-500/30">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl text-white mb-4">{t("install.title")}</CardTitle>
              <CardDescription className="text-slate-300 text-lg">
                {t("install.subtitle")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-slate-950 p-6 rounded-lg border border-slate-800">
                <code className="text-green-400 text-lg">pip install tenIII</code>
              </div>
              <p className="text-slate-400 text-center mt-4">{t("install.or")}</p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="container mx-auto px-4 py-20">
        <div className="max-w-3xl mx-auto text-center space-y-8">
          <h2 className="text-4xl font-bold text-white">{t("cta.title")}</h2>
          <p className="text-xl text-slate-400">{t("cta.subtitle")}</p>
          {isAuthenticated ? (
            <Button
              asChild
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-lg px-12"
            >
              <Link href="/training" className="flex items-center gap-2">
                {t("cta.button")}
                <ArrowRight className="w-5 h-5" />
              </Link>
            </Button>
          ) : (
            <Button
              asChild
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-lg px-12"
            >
              <a href={getLoginUrl()} className="flex items-center gap-2">
                {t("cta.register")}
                <ArrowRight className="w-5 h-5" />
              </a>
            </Button>
          )}
        </div>
      </section>

      <footer className="border-t border-slate-800 bg-slate-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-slate-400">{t("footer.copyright")}</div>
            <div className="flex gap-6 items-center">
              <LanguageSelector />
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                {t("nav.docs")}
              </a>
              <a
                href="#"
                className="text-slate-400 hover:text-white transition-colors flex items-center gap-2"
              >
                <Github className="w-4 h-4" />
                {t("nav.github")}
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
