import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json, float } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Training sessions table to track model training
 */
export const trainingSessions = mysqlTable("training_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["pending", "running", "paused", "completed", "failed"]).default("pending").notNull(),
  dataFileUrl: text("dataFileUrl"),
  modelConfig: json("modelConfig"),
  currentEpoch: int("currentEpoch").default(0),
  totalEpochs: int("totalEpochs").default(10),
  currentLoss: float("currentLoss"),
  metrics: json("metrics"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  completedAt: timestamp("completedAt"),
});

export type TrainingSession = typeof trainingSessions.$inferSelect;
export type InsertTrainingSession = typeof trainingSessions.$inferInsert;

/**
 * Uploaded files table
 */
export const uploadedFiles = mysqlTable("uploaded_files", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  filename: varchar("filename", { length: 255 }).notNull(),
  fileUrl: text("fileUrl").notNull(),
  fileKey: varchar("fileKey", { length: 500 }).notNull(),
  fileType: varchar("fileType", { length: 50 }),
  fileSize: int("fileSize"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UploadedFile = typeof uploadedFiles.$inferSelect;
export type InsertUploadedFile = typeof uploadedFiles.$inferInsert;

// ─── Terminator 1 Tables ─────────────────────────────────────────────────────

/**
 * Conversations: one row per channel session (web, whatsapp, telegram, sms, voice, video)
 */
export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  channelId: varchar("channelId", { length: 128 }).notNull(), // e.g. whatsapp:+34600..., sms:+34600..., call:CA..., web:sessionId
  channel: mysqlEnum("channel", ["web", "whatsapp", "telegram", "sms", "voice", "video"]).notNull(),
  personaId: varchar("personaId", { length: 64 }).default("default").notNull(), // default | ani | valentin
  llmBackend: varchar("llmBackend", { length: 64 }).default("auto").notNull(),
  ttsBackend: varchar("ttsBackend", { length: 64 }).default("auto").notNull(),
  videoBackend: varchar("videoBackend", { length: 64 }).default("none").notNull(),
  language: varchar("language", { length: 16 }).default("es").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = typeof conversations.$inferInsert;

/**
 * Messages: each turn in a conversation
 */
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull(),
  role: mysqlEnum("role", ["user", "assistant", "system"]).notNull(),
  text: text("text"),
  audioUrl: text("audioUrl"),
  videoUrl: text("videoUrl"),
  imageUrl: text("imageUrl"),
  videoPrompt: text("videoPrompt"),
  audioPrompt: text("audioPrompt"),
  metadata: json("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

/**
 * Terminator config: API keys and backend settings per owner
 */
export const terminatorConfig = mysqlTable("terminator_config", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  // LLM backends
  ollamaUrl: varchar("ollamaUrl", { length: 255 }).default("http://localhost:11434"),
  lmstudioUrl: varchar("lmstudioUrl", { length: 255 }).default("http://localhost:1234"),
  xaiApiKey: text("xaiApiKey"),
  openaiApiKey: text("openaiApiKey"),
  moonshotApiKey: text("moonshotApiKey"),
  deepseekApiKey: text("deepseekApiKey"),
  // Channels
  twilioAccountSid: text("twilioAccountSid"),
  twilioAuthToken: text("twilioAuthToken"),
  twilioPhoneNumber: varchar("twilioPhoneNumber", { length: 32 }),
  whatsappToken: text("whatsappToken"),
  whatsappPhoneNumberId: varchar("whatsappPhoneNumberId", { length: 64 }),
  whatsappVerifyToken: varchar("whatsappVerifyToken", { length: 128 }),
  telegramBotToken: text("telegramBotToken"),
  // Defaults
  defaultPersona: varchar("defaultPersona", { length: 64 }).default("default"),
  defaultLlm: varchar("defaultLlm", { length: 64 }).default("auto"),
  defaultTts: varchar("defaultTts", { length: 64 }).default("auto"),
  defaultVideo: varchar("defaultVideo", { length: 64 }).default("none"),
  defaultLanguage: varchar("defaultLanguage", { length: 16 }).default("es"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TerminatorConfig = typeof terminatorConfig.$inferSelect;
export type InsertTerminatorConfig = typeof terminatorConfig.$inferInsert;
