/**
 * Terminator 1 — LLM Router
 *
 * Tries backends in order: Ollama → LM Studio → Grok (xAI) → OpenAI → Kimi → DeepSeek
 * All expose an OpenAI-compatible /v1/chat/completions endpoint.
 */

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface LLMConfig {
  ollamaUrl?: string;
  lmstudioUrl?: string;
  xaiApiKey?: string;
  openaiApiKey?: string;
  moonshotApiKey?: string;
  deepseekApiKey?: string;
  preferredBackend?: string;
}

export interface LLMResponse {
  text: string;
  videoPrompt: string | null;
  audioPrompt: string | null;
  backend: string;
}

// ─── Personas ─────────────────────────────────────────────────────────────────

const PERSONAS: Record<string, string> = {
  default:
    "Eres el Terminator, un asistente de IA avanzado. Responde de forma util, directa y concisa.",
  ani: "Eres Ani, una asistente de IA con personalidad calida y empatica. Hablas de forma natural y cercana.",
  valentin:
    "Eres Valentin, un asistente de IA sofisticado y culto. Tu tono es elegante y reflexivo.",
};

// ─── Multimodal prompt parser ─────────────────────────────────────────────────

const VIDEO_RE = /"Para Generar Video quiero:\s*([^"]+)"/i;
const AUDIO_RE = /"Para Generar Audio quiero:\s*([^"]+)"/i;

function parseMultimodalResponse(raw: string): {
  text: string;
  videoPrompt: string | null;
  audioPrompt: string | null;
} {
  const videoMatch = raw.match(VIDEO_RE);
  const audioMatch = raw.match(AUDIO_RE);
  const videoPrompt = videoMatch ? videoMatch[1].trim() : null;
  const audioPrompt = audioMatch ? audioMatch[1].trim() : null;

  const text = raw
    .replace(VIDEO_RE, "")
    .replace(AUDIO_RE, "")
    .trim();

  return { text, videoPrompt, audioPrompt };
}

// ─── OpenAI-compatible fetch ──────────────────────────────────────────────────

async function callOpenAICompat(
  baseUrl: string,
  model: string,
  msgs: ChatMessage[],
  apiKey?: string,
  timeoutMs = 30000
): Promise<string> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  const headers: Record<string, string> = {
    "Content-Type": "application/json",
  };
  if (apiKey) headers["Authorization"] = `Bearer ${apiKey}`;

  try {
    const res = await fetch(`${baseUrl}/v1/chat/completions`, {
      method: "POST",
      headers,
      body: JSON.stringify({ model, messages: msgs, max_tokens: 1024 }),
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = (await res.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    return json.choices?.[0]?.message?.content ?? "";
  } finally {
    clearTimeout(timer);
  }
}

// ─── Backend availability check ───────────────────────────────────────────────

async function isLocalBackendAvailable(url: string): Promise<boolean> {
  try {
    const res = await fetch(`${url}/v1/models`, {
      signal: AbortSignal.timeout(2000),
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function getDefaultOllamaModel(url: string): Promise<string> {
  try {
    const res = await fetch(`${url}/api/tags`, {
      signal: AbortSignal.timeout(2000),
    });
    if (!res.ok) return "llama3.2";
    const json = (await res.json()) as { models?: Array<{ name: string }> };
    const models = json.models ?? [];
    const preferred = ["salamandra", "alia", "qwen", "llama3", "gemma", "phi"];
    for (const p of preferred) {
      const found = models.find((m) => m.name.toLowerCase().includes(p));
      if (found) return found.name;
    }
    return models[0]?.name ?? "llama3.2";
  } catch {
    return "llama3.2";
  }
}

// ─── Main LLM call ────────────────────────────────────────────────────────────

export async function callLLM(
  userMessages: ChatMessage[],
  config: LLMConfig,
  personaId = "default",
  withMultimodal = false
): Promise<LLMResponse> {
  const systemPrompt = PERSONAS[personaId] ?? PERSONAS.default;
  const multimodalInstruction = withMultimodal
    ? '\n\nCuando quieras generar contenido multimedia, incluye al final de tu respuesta:\n"Para Generar Video quiero: [descripcion visual detallada]"\n"Para Generar Audio quiero: [descripcion del audio/voz/musica]"'
    : "";

  const fullMessages: ChatMessage[] = [
    { role: "system", content: systemPrompt + multimodalInstruction },
    ...userMessages,
  ];

  const ollamaUrl = config.ollamaUrl ?? "http://localhost:11434";
  const lmstudioUrl = config.lmstudioUrl ?? "http://localhost:1234";
  const preferred = config.preferredBackend ?? "auto";

  type BackendFn = () => Promise<{ text: string; backend: string }>;
  const backends: BackendFn[] = [];

  if (preferred === "auto" || preferred === "ollama") {
    backends.push(async () => {
      if (!(await isLocalBackendAvailable(ollamaUrl))) throw new Error("Ollama not available");
      const model = await getDefaultOllamaModel(ollamaUrl);
      const text = await callOpenAICompat(ollamaUrl, model, fullMessages, undefined, 60000);
      return { text, backend: `ollama:${model}` };
    });
  }

  if (preferred === "auto" || preferred === "lmstudio") {
    backends.push(async () => {
      if (!(await isLocalBackendAvailable(lmstudioUrl))) throw new Error("LM Studio not available");
      const text = await callOpenAICompat(lmstudioUrl, "local-model", fullMessages, undefined, 60000);
      return { text, backend: "lmstudio" };
    });
  }

  if ((preferred === "auto" || preferred === "grok") && config.xaiApiKey) {
    backends.push(async () => {
      const text = await callOpenAICompat(
        "https://api.x.ai",
        "grok-3-mini",
        fullMessages,
        config.xaiApiKey
      );
      return { text, backend: "grok:grok-3-mini" };
    });
  }

  if ((preferred === "auto" || preferred === "openai") && config.openaiApiKey) {
    backends.push(async () => {
      const text = await callOpenAICompat(
        "https://api.openai.com",
        "gpt-4o-mini",
        fullMessages,
        config.openaiApiKey
      );
      return { text, backend: "openai:gpt-4o-mini" };
    });
  }

  if ((preferred === "auto" || preferred === "kimi") && config.moonshotApiKey) {
    backends.push(async () => {
      const text = await callOpenAICompat(
        "https://api.moonshot.cn",
        "moonshot-v1-8k",
        fullMessages,
        config.moonshotApiKey
      );
      return { text, backend: "kimi:moonshot-v1-8k" };
    });
  }

  if ((preferred === "auto" || preferred === "deepseek") && config.deepseekApiKey) {
    backends.push(async () => {
      const text = await callOpenAICompat(
        "https://api.deepseek.com",
        "deepseek-chat",
        fullMessages,
        config.deepseekApiKey
      );
      return { text, backend: "deepseek:deepseek-chat" };
    });
  }

  for (const tryBackend of backends) {
    try {
      const { text, backend } = await tryBackend();
      const parsed = parseMultimodalResponse(text);
      return { ...parsed, backend };
    } catch (err) {
      console.warn("[LLM] Backend failed:", (err as Error).message);
    }
  }

  return {
    text: "Lo siento, no hay ningun modelo de lenguaje disponible. Por favor configura al menos un backend LLM.",
    videoPrompt: null,
    audioPrompt: null,
    backend: "none",
  };
}

// ─── Backend status check ─────────────────────────────────────────────────────

export async function checkLLMBackends(config: LLMConfig): Promise<{
  ollama: boolean;
  lmstudio: boolean;
  grok: boolean;
  openai: boolean;
  kimi: boolean;
  deepseek: boolean;
}> {
  const [ollama, lmstudio] = await Promise.all([
    isLocalBackendAvailable(config.ollamaUrl ?? "http://localhost:11434"),
    isLocalBackendAvailable(config.lmstudioUrl ?? "http://localhost:1234"),
  ]);
  return {
    ollama,
    lmstudio,
    grok: !!config.xaiApiKey,
    openai: !!config.openaiApiKey,
    kimi: !!config.moonshotApiKey,
    deepseek: !!config.deepseekApiKey,
  };
}
