/**
 * Terminator 1 — tRPC Router
 *
 * Procedures:
 *   terminator.chat          — web chat (text/audio/image)
 *   terminator.getHistory    — conversation history
 *   terminator.getConfig     — current config (masked keys)
 *   terminator.saveConfig    — save API keys and defaults
 *   terminator.checkBackends — check which LLM backends are available
 *   terminator.getConversations — list all conversations
 */

import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import { processMessage } from "./orchestrator";
import { checkLLMBackends } from "./llm";
import {
  getTerminatorConfig,
  upsertTerminatorConfig,
  getConversationHistory,
  getOrCreateConversation,
} from "./db";
import { nanoid } from "nanoid";
import { transcribeAudio } from "./tts";

export const terminatorRouter = router({
  // ── Web chat ────────────────────────────────────────────────────────────────
  chat: publicProcedure
    .input(
      z.object({
        sessionId: z.string().optional(),
        text: z.string().optional(),
        audioUrl: z.string().url().optional(),
        imageUrl: z.string().url().optional(),
        personaId: z.string().default("default"),
        language: z.string().default("es"),
        withVideo: z.boolean().default(false),
        withAudio: z.boolean().default(true),
        llmBackend: z.string().default("auto"),
        ttsBackend: z.string().default("auto"),
        videoBackend: z.string().default("none"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (!input.text && !input.audioUrl) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Se requiere texto o audio" });
      }

      const userId = ctx.user?.id ?? 0;
      const cfg = userId ? await getTerminatorConfig(userId) : null;

      // Override config with per-request backends
      const effectiveCfg = cfg
        ? {
            ...cfg,
            defaultLlm: input.llmBackend,
            defaultTts: input.ttsBackend,
            defaultVideo: input.videoBackend,
          }
        : null;

      const sessionId = input.sessionId ?? `web:${nanoid()}`;
      let text = input.text;

      // If audio provided, transcribe first
      if (!text && input.audioUrl && cfg) {
        const stt = await transcribeAudio(
          input.audioUrl,
          { xaiApiKey: cfg.xaiApiKey ?? undefined, openaiApiKey: cfg.openaiApiKey ?? undefined },
          input.language
        );
        text = stt?.text;
      }

      const result = await processMessage(
        {
          channelId: sessionId,
          channel: "web",
          text,
          audioUrl: input.audioUrl,
          imageUrl: input.imageUrl,
          language: input.language,
        },
        effectiveCfg,
        {
          withVideo: input.withVideo,
          withAudio: input.withAudio,
          personaId: input.personaId,
          language: input.language,
        }
      );

      return result;
    }),

  // ── Conversation history ─────────────────────────────────────────────────────
  getHistory: publicProcedure
    .input(
      z.object({
        sessionId: z.string(),
        limit: z.number().int().min(1).max(100).default(20),
      })
    )
    .query(async ({ input }) => {
      const conv = await getOrCreateConversation(input.sessionId, "web");
      if (!conv) return [];
      return getConversationHistory(conv.id, input.limit);
    }),

  // ── Config ──────────────────────────────────────────────────────────────────
  getConfig: protectedProcedure.query(async ({ ctx }) => {
    const cfg = await getTerminatorConfig(ctx.user.id);
    if (!cfg) return null;
    // Mask API keys
    const mask = (key: string | null | undefined) =>
      key ? `${key.slice(0, 4)}${"*".repeat(Math.max(0, key.length - 8))}${key.slice(-4)}` : null;
    return {
      ...cfg,
      xaiApiKey: mask(cfg.xaiApiKey),
      openaiApiKey: mask(cfg.openaiApiKey),
      moonshotApiKey: mask(cfg.moonshotApiKey),
      deepseekApiKey: mask(cfg.deepseekApiKey),
      twilioAuthToken: mask(cfg.twilioAuthToken),
      whatsappToken: mask(cfg.whatsappToken),
      telegramBotToken: mask(cfg.telegramBotToken),
    };
  }),

  saveConfig: protectedProcedure
    .input(
      z.object({
        ollamaUrl: z.string().optional(),
        lmstudioUrl: z.string().optional(),
        xaiApiKey: z.string().optional(),
        openaiApiKey: z.string().optional(),
        moonshotApiKey: z.string().optional(),
        deepseekApiKey: z.string().optional(),
        twilioAccountSid: z.string().optional(),
        twilioAuthToken: z.string().optional(),
        twilioPhoneNumber: z.string().optional(),
        whatsappToken: z.string().optional(),
        whatsappPhoneNumberId: z.string().optional(),
        whatsappVerifyToken: z.string().optional(),
        telegramBotToken: z.string().optional(),
        defaultPersona: z.string().optional(),
        defaultLlm: z.string().optional(),
        defaultTts: z.string().optional(),
        defaultVideo: z.string().optional(),
        defaultLanguage: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await upsertTerminatorConfig(ctx.user.id, input);
      return { success: true };
    }),

  // ── Check backends ───────────────────────────────────────────────────────────
  checkBackends: publicProcedure
    .input(
      z.object({
        ollamaUrl: z.string().default("http://localhost:11434"),
        lmstudioUrl: z.string().default("http://localhost:1234"),
      })
    )
    .query(async ({ ctx, input }) => {
      const userId = ctx.user?.id ?? 0;
      const cfg = userId ? await getTerminatorConfig(userId) : null;
      return checkLLMBackends({
        ollamaUrl: input.ollamaUrl,
        lmstudioUrl: input.lmstudioUrl,
        xaiApiKey: cfg?.xaiApiKey ?? undefined,
        openaiApiKey: cfg?.openaiApiKey ?? undefined,
        moonshotApiKey: cfg?.moonshotApiKey ?? undefined,
        deepseekApiKey: cfg?.deepseekApiKey ?? undefined,
      });
    }),

  // ── Webhook: WhatsApp ────────────────────────────────────────────────────────
  // Note: WhatsApp webhooks are handled as raw Express routes (see server/index.ts extension)
  // This procedure is for testing/manual trigger only
  testWebhook: protectedProcedure
    .input(z.object({ channel: z.enum(["whatsapp", "telegram", "sms"]), payload: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const cfg = await getTerminatorConfig(ctx.user.id);
      const parsed = JSON.parse(input.payload) as Record<string, unknown>;
      console.log(`[Webhook Test] channel=${input.channel}`, parsed);
      return { received: true, cfg: !!cfg };
    }),
});
