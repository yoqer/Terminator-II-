/**
 * Terminator 1 — Express Webhook Routes
 *
 * Registers raw Express routes for:
 *   POST /webhook/whatsapp   — WhatsApp Business API
 *   GET  /webhook/whatsapp   — WhatsApp verification challenge
 *   POST /webhook/telegram   — Telegram Bot
 *   POST /webhook/sms        — Twilio SMS/MMS
 *   POST /twiml              — Twilio Voice (ConversationRelay TwiML)
 *   WS   /ws/voice           — Twilio ConversationRelay WebSocket
 *   POST /webhook/video/token — Twilio Video room token
 */

import type { Express, Request, Response } from "express";
import { WebSocketServer, WebSocket } from "ws";
import type { Server } from "http";
import { getTerminatorConfig } from "./db";
import { processMessage } from "./orchestrator";
import {
  parseWhatsAppWebhook,
  sendWhatsAppMessage,
  parseTelegramWebhook,
  sendTelegramMessage,
  parseTwilioSMS,
  sendTwilioSMS,
  type WhatsAppWebhookBody,
  type TelegramWebhookBody,
  type TwilioSMSBody,
} from "./channels";
import { callLLM } from "./llm";
import { synthesizeSpeech } from "./tts";

// Owner user ID = 1 (first user, the owner of the Terminator instance)
const OWNER_USER_ID = 1;

// ─── WhatsApp ─────────────────────────────────────────────────────────────────

function registerWhatsApp(app: Express) {
  // Verification challenge
  app.get("/webhook/whatsapp", (req: Request, res: Response) => {
    const mode = req.query["hub.mode"];
    const token = req.query["hub.verify_token"];
    const challenge = req.query["hub.challenge"];

    // We'll accept any verify token and echo the challenge
    if (mode === "subscribe" && challenge) {
      console.log("[WhatsApp] Webhook verified");
      res.status(200).send(challenge);
    } else {
      res.sendStatus(403);
    }
  });

  app.post("/webhook/whatsapp", async (req: Request, res: Response) => {
    res.sendStatus(200); // Acknowledge immediately

    try {
      const body = req.body as WhatsAppWebhookBody;
      const msg = parseWhatsAppWebhook(body);
      if (!msg) return;

      const cfg = await getTerminatorConfig(OWNER_USER_ID);
      const result = await processMessage(msg, cfg, { withAudio: true });

      const from = msg.channelId.replace("whatsapp:", "");
      if (cfg?.whatsappToken && cfg?.whatsappPhoneNumberId) {
        await sendWhatsAppMessage(from, cfg.whatsappPhoneNumberId, cfg.whatsappToken, {
          text: result.text,
          audioUrl: result.audioUrl ?? undefined,
          videoUrl: result.videoUrl ?? undefined,
        });
      }
    } catch (err) {
      console.error("[WhatsApp] Webhook error:", err);
    }
  });
}

// ─── Telegram ─────────────────────────────────────────────────────────────────

function registerTelegram(app: Express) {
  app.post("/webhook/telegram", async (req: Request, res: Response) => {
    res.sendStatus(200);

    try {
      const body = req.body as TelegramWebhookBody;
      const msg = parseTelegramWebhook(body);
      if (!msg) return;

      const cfg = await getTerminatorConfig(OWNER_USER_ID);
      const result = await processMessage(msg, cfg, { withAudio: true });

      const chatId = msg.channelId.replace("telegram:", "");
      if (cfg?.telegramBotToken) {
        await sendTelegramMessage(chatId, cfg.telegramBotToken, {
          text: result.text,
          audioUrl: result.audioUrl ?? undefined,
          videoUrl: result.videoUrl ?? undefined,
        });
      }
    } catch (err) {
      console.error("[Telegram] Webhook error:", err);
    }
  });
}

// ─── SMS/MMS (Twilio) ─────────────────────────────────────────────────────────

function registerSMS(app: Express) {
  app.post("/webhook/sms", async (req: Request, res: Response) => {
    res.set("Content-Type", "text/xml");
    res.send("<Response></Response>"); // Acknowledge immediately

    try {
      const body = req.body as TwilioSMSBody;
      const msg = parseTwilioSMS(body);
      if (!msg) return;

      const cfg = await getTerminatorConfig(OWNER_USER_ID);
      const result = await processMessage(msg, cfg, { withAudio: false });

      const to = msg.channelId.replace("sms:", "");
      if (cfg?.twilioAccountSid && cfg?.twilioAuthToken && cfg?.twilioPhoneNumber) {
        await sendTwilioSMS(to, cfg.twilioPhoneNumber, cfg.twilioAccountSid, cfg.twilioAuthToken, {
          text: result.text,
          imageUrl: undefined, // MMS image only in US/CA
          videoUrl: result.videoUrl ?? undefined,
        });
      }
    } catch (err) {
      console.error("[SMS] Webhook error:", err);
    }
  });
}

// ─── Twilio Voice (ConversationRelay) ─────────────────────────────────────────

function registerVoice(app: Express) {
  // TwiML endpoint: tells Twilio to connect to our WebSocket
  app.post("/twiml", (req: Request, res: Response) => {
    const host = req.headers.host ?? "localhost";
    const wsUrl = `wss://${host}/ws/voice`;
    res.set("Content-Type", "text/xml");
    res.send(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Connect>
    <ConversationRelay url="${wsUrl}" welcomeGreeting="Hola, soy el Terminator. ¿En qué puedo ayudarte?" ttsProvider="Google" voice="es-ES-Standard-A" language="es-ES" />
  </Connect>
</Response>`);
  });
}

// ─── Twilio Video token ───────────────────────────────────────────────────────

function registerVideo(app: Express) {
  app.post("/webhook/video/token", async (req: Request, res: Response) => {
    try {
      const cfg = await getTerminatorConfig(OWNER_USER_ID);
      if (!cfg?.twilioAccountSid || !cfg?.twilioAuthToken) {
        res.status(503).json({ error: "Twilio not configured" });
        return;
      }

      const roomName = (req.body as { roomName?: string }).roomName ?? `terminator-${Date.now()}`;
      const identity = (req.body as { identity?: string }).identity ?? "user";

      // Generate Twilio Video Access Token
      // Using Twilio's REST API to create a room token
      const { AccessToken } = await import("twilio").then((m) => m.jwt);
      const { VideoGrant } = AccessToken;

      const apiKey = cfg.twilioAccountSid;
      const apiSecret = cfg.twilioAuthToken;

      const token = new AccessToken(cfg.twilioAccountSid, apiKey, apiSecret, {
        identity,
        ttl: 3600,
      });
      const grant = new VideoGrant({ room: roomName });
      token.addGrant(grant);

      res.json({ token: token.toJwt(), roomName, identity });
    } catch (err) {
      console.error("[Video] Token error:", err);
      res.status(500).json({ error: "Failed to generate token" });
    }
  });
}

// ─── WebSocket: Twilio ConversationRelay ──────────────────────────────────────

interface VoiceSession {
  callSid: string;
  history: Array<{ role: "user" | "assistant"; content: string }>;
}

function registerVoiceWebSocket(server: Server) {
  const wss = new WebSocketServer({ server, path: "/ws/voice" });

  wss.on("connection", (ws: WebSocket) => {
    let session: VoiceSession | null = null;

    ws.on("message", async (data: Buffer) => {
      try {
        const msg = JSON.parse(data.toString()) as {
          type: string;
          callSid?: string;
          voicePrompt?: string;
        };

        if (msg.type === "setup") {
          session = { callSid: msg.callSid ?? "unknown", history: [] };
          console.log(`[Voice WS] Call started: ${session.callSid}`);
        } else if (msg.type === "prompt" && session && msg.voicePrompt) {
          const cfg = await getTerminatorConfig(OWNER_USER_ID);
          session.history.push({ role: "user", content: msg.voicePrompt });

          const llmResult = await callLLM(
            session.history,
            {
              ollamaUrl: cfg?.ollamaUrl ?? "http://localhost:11434",
              lmstudioUrl: cfg?.lmstudioUrl ?? "http://localhost:1234",
              xaiApiKey: cfg?.xaiApiKey ?? undefined,
              openaiApiKey: cfg?.openaiApiKey ?? undefined,
              moonshotApiKey: cfg?.moonshotApiKey ?? undefined,
              deepseekApiKey: cfg?.deepseekApiKey ?? undefined,
              preferredBackend: cfg?.defaultLlm ?? "auto",
            },
            cfg?.defaultPersona ?? "default",
            false // no multimodal in voice calls
          );

          session.history.push({ role: "assistant", content: llmResult.text });

          ws.send(
            JSON.stringify({
              type: "text",
              token: llmResult.text,
              last: true,
            })
          );
        } else if (msg.type === "interrupt") {
          console.log(`[Voice WS] Interrupted: ${session?.callSid}`);
        }
      } catch (err) {
        console.error("[Voice WS] Error:", err);
      }
    });

    ws.on("close", () => {
      console.log(`[Voice WS] Call ended: ${session?.callSid}`);
    });
  });

  console.log("[Voice WS] ConversationRelay WebSocket registered at /ws/voice");
}

// ─── Main registration ────────────────────────────────────────────────────────

export function registerTerminatorWebhooks(app: Express, server: Server) {
  registerWhatsApp(app);
  registerTelegram(app);
  registerSMS(app);
  registerVoice(app);
  registerVideo(app);
  registerVoiceWebSocket(server);
  console.log("[Terminator] Webhooks registered");
}
