/**
 * Terminator 1 — TTS / STT Router
 *
 * TTS chain: Grok Aurora → OpenAI TTS → Piper (local, CPU)
 * STT chain: Grok STT → OpenAI Whisper API
 *
 * Returns audio as a public S3 URL.
 */

import { storagePut } from "../storage";
import { nanoid } from "nanoid";

export interface TTSConfig {
  xaiApiKey?: string;
  openaiApiKey?: string;
  preferredTts?: string; // "auto" | "grok" | "openai" | "piper"
}

export interface STTConfig {
  xaiApiKey?: string;
  openaiApiKey?: string;
}

// ─── Persona → voice mapping ──────────────────────────────────────────────────

// Grok voices: eve (female, warm), ara (female, bright), rex (male, deep), sal (male, calm), leo (male, energetic)
const GROK_VOICE_MAP: Record<string, string> = {
  default: "rex",
  ani: "ara",
  valentin: "sal",
};

// OpenAI voices: alloy, echo, fable, onyx, nova, shimmer
const OPENAI_VOICE_MAP: Record<string, string> = {
  default: "onyx",
  ani: "nova",
  valentin: "echo",
};

// ─── Grok TTS ─────────────────────────────────────────────────────────────────

async function grokTTS(
  text: string,
  personaId: string,
  apiKey: string
): Promise<Buffer> {
  const voice = GROK_VOICE_MAP[personaId] ?? "rex";
  const res = await fetch("https://api.x.ai/v1/audio/speech", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "grok-tts-aurora",
      input: text,
      voice,
      response_format: "mp3",
    }),
    signal: AbortSignal.timeout(30000),
  });
  if (!res.ok) throw new Error(`Grok TTS HTTP ${res.status}`);
  const ab = await res.arrayBuffer();
  return Buffer.from(ab);
}

// ─── OpenAI TTS ───────────────────────────────────────────────────────────────

async function openaiTTS(
  text: string,
  personaId: string,
  apiKey: string
): Promise<Buffer> {
  const voice = OPENAI_VOICE_MAP[personaId] ?? "onyx";
  const res = await fetch("https://api.openai.com/v1/audio/speech", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "tts-1",
      input: text,
      voice,
      response_format: "mp3",
    }),
    signal: AbortSignal.timeout(30000),
  });
  if (!res.ok) throw new Error(`OpenAI TTS HTTP ${res.status}`);
  const ab = await res.arrayBuffer();
  return Buffer.from(ab);
}

// ─── Piper TTS (local, CPU) ───────────────────────────────────────────────────
// Piper is called via child_process if installed locally.
// Falls back gracefully if not available.

async function piperTTS(text: string, language = "es"): Promise<Buffer | null> {
  try {
    const { execSync } = await import("child_process");
    const { writeFileSync, readFileSync, unlinkSync } = await import("fs");
    const { tmpdir } = await import("os");
    const { join } = await import("path");

    const langModelMap: Record<string, string> = {
      es: "es_ES-davefx-medium",
      en: "en_US-lessac-medium",
      de: "de_DE-thorsten-medium",
      fr: "fr_FR-siwis-medium",
      it: "it_IT-riccardo-x_low",
      pt: "pt_BR-faber-medium",
    };
    const model = langModelMap[language] ?? langModelMap.es;
    const outFile = join(tmpdir(), `piper_${nanoid()}.wav`);
    const inFile = join(tmpdir(), `piper_in_${nanoid()}.txt`);

    writeFileSync(inFile, text, "utf-8");
    execSync(
      `piper --model ${model} --output_file ${outFile} < ${inFile}`,
      { timeout: 20000 }
    );
    const buf = readFileSync(outFile);
    unlinkSync(outFile);
    unlinkSync(inFile);
    return buf;
  } catch {
    return null;
  }
}

// ─── Main TTS call ────────────────────────────────────────────────────────────

export async function synthesizeSpeech(
  text: string,
  config: TTSConfig,
  personaId = "default",
  language = "es"
): Promise<{ url: string; backend: string } | null> {
  if (!text.trim()) return null;

  const preferred = config.preferredTts ?? "auto";
  let audioBuffer: Buffer | null = null;
  let backend = "none";
  let ext = "mp3";

  if ((preferred === "auto" || preferred === "grok") && config.xaiApiKey) {
    try {
      audioBuffer = await grokTTS(text, personaId, config.xaiApiKey);
      backend = "grok-tts";
      ext = "mp3";
    } catch (err) {
      console.warn("[TTS] Grok failed:", (err as Error).message);
    }
  }

  if (!audioBuffer && (preferred === "auto" || preferred === "openai") && config.openaiApiKey) {
    try {
      audioBuffer = await openaiTTS(text, personaId, config.openaiApiKey);
      backend = "openai-tts";
      ext = "mp3";
    } catch (err) {
      console.warn("[TTS] OpenAI failed:", (err as Error).message);
    }
  }

  if (!audioBuffer && (preferred === "auto" || preferred === "piper")) {
    try {
      const piperBuf = await piperTTS(text, language);
      if (piperBuf) {
        audioBuffer = piperBuf;
        backend = "piper";
        ext = "wav";
      }
    } catch (err) {
      console.warn("[TTS] Piper failed:", (err as Error).message);
    }
  }

  if (!audioBuffer) return null;

  const key = `terminator/audio/${nanoid()}.${ext}`;
  const { url } = await storagePut(key, audioBuffer, `audio/${ext === "wav" ? "wav" : "mpeg"}`);
  return { url, backend };
}

// ─── STT ──────────────────────────────────────────────────────────────────────

export async function transcribeAudio(
  audioUrl: string,
  config: STTConfig,
  language?: string
): Promise<{ text: string; backend: string } | null> {
  // Download audio first
  let audioBuffer: Uint8Array;
  try {
    const res = await fetch(audioUrl, { signal: AbortSignal.timeout(30000) });
    if (!res.ok) throw new Error(`Download failed: HTTP ${res.status}`);
    const ab = await res.arrayBuffer();
    audioBuffer = new Uint8Array(ab.slice(0));
  } catch (err) {
    console.error("[STT] Failed to download audio:", (err as Error).message);
    return null;
  }

  // Try Grok STT first
  if (config.xaiApiKey) {
    try {
      const formData = new FormData();
      const ab1 = audioBuffer.buffer.slice(audioBuffer.byteOffset, audioBuffer.byteOffset + audioBuffer.byteLength) as ArrayBuffer;
      formData.append("file", new Blob([ab1], { type: "audio/mpeg" }), "audio.mp3");
      formData.append("model", "whisper-large-v3");
      if (language) formData.append("language", language);

      const res = await fetch("https://api.x.ai/v1/audio/transcriptions", {
        method: "POST",
        headers: { Authorization: `Bearer ${config.xaiApiKey}` },
        body: formData,
        signal: AbortSignal.timeout(30000),
      });
      if (!res.ok) throw new Error(`Grok STT HTTP ${res.status}`);
      const json = (await res.json()) as { text?: string };
      if (json.text) return { text: json.text, backend: "grok-stt" };
    } catch (err) {
      console.warn("[STT] Grok failed:", (err as Error).message);
    }
  }

  // Fallback: OpenAI Whisper
  if (config.openaiApiKey) {
    try {
      const formData = new FormData();
      const ab2 = audioBuffer.buffer.slice(audioBuffer.byteOffset, audioBuffer.byteOffset + audioBuffer.byteLength) as ArrayBuffer;
      formData.append("file", new Blob([ab2], { type: "audio/mpeg" }), "audio.mp3");
      formData.append("model", "whisper-1");
      if (language) formData.append("language", language);

      const res = await fetch("https://api.openai.com/v1/audio/transcriptions", {
        method: "POST",
        headers: { Authorization: `Bearer ${config.openaiApiKey}` },
        body: formData,
        signal: AbortSignal.timeout(30000),
      });
      if (!res.ok) throw new Error(`OpenAI STT HTTP ${res.status}`);
      const json = (await res.json()) as { text?: string };
      if (json.text) return { text: json.text, backend: "openai-whisper" };
    } catch (err) {
      console.warn("[STT] OpenAI Whisper failed:", (err as Error).message);
    }
  }

  return null;
}
