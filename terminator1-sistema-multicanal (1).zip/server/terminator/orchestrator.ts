/**
 * Terminator 1 — Orchestrator
 *
 * Receives a TerminatorMessage, runs the full pipeline:
 * 1. Load conversation history from DB
 * 2. Call LLM → get text + videoPrompt + audioPrompt
 * 3. In parallel: synthesize speech (TTS) + generate video
 * 4. Save messages to DB
 * 5. Return TerminatorResponse
 */

import { callLLM, type ChatMessage, type LLMConfig } from "./llm";
import { synthesizeSpeech, type TTSConfig } from "./tts";
import { generateVideo, type VideoConfig } from "./video";
import {
  getOrCreateConversation,
  addMessage,
  getConversationHistory,
} from "./db";
import type { TerminatorMessage, ChannelType } from "./channels";
import type { TerminatorConfig } from "../../drizzle/schema";

export interface TerminatorResponse {
  text: string;
  audioUrl: string | null;
  videoUrl: string | null;
  videoPrompt: string | null;
  audioPrompt: string | null;
  backend: {
    llm: string;
    tts: string | null;
    video: string | null;
  };
  conversationId: number | null;
}

function buildLLMConfig(cfg: TerminatorConfig | null): LLMConfig {
  return {
    ollamaUrl: cfg?.ollamaUrl ?? "http://localhost:11434",
    lmstudioUrl: cfg?.lmstudioUrl ?? "http://localhost:1234",
    xaiApiKey: cfg?.xaiApiKey ?? undefined,
    openaiApiKey: cfg?.openaiApiKey ?? undefined,
    moonshotApiKey: cfg?.moonshotApiKey ?? undefined,
    deepseekApiKey: cfg?.deepseekApiKey ?? undefined,
    preferredBackend: cfg?.defaultLlm ?? "auto",
  };
}

function buildTTSConfig(cfg: TerminatorConfig | null): TTSConfig {
  return {
    xaiApiKey: cfg?.xaiApiKey ?? undefined,
    openaiApiKey: cfg?.openaiApiKey ?? undefined,
    preferredTts: cfg?.defaultTts ?? "auto",
  };
}

function buildVideoConfig(cfg: TerminatorConfig | null): VideoConfig {
  return {
    xaiApiKey: cfg?.xaiApiKey ?? undefined,
    preferredVideo: cfg?.defaultVideo ?? "none",
  };
}

export async function processMessage(
  msg: TerminatorMessage,
  cfg: TerminatorConfig | null,
  options?: {
    withVideo?: boolean;
    withAudio?: boolean;
    personaId?: string;
    language?: string;
  }
): Promise<TerminatorResponse> {
  const personaId = options?.personaId ?? cfg?.defaultPersona ?? "default";
  const language = options?.language ?? msg.language ?? cfg?.defaultLanguage ?? "es";
  const withVideo = options?.withVideo ?? (cfg?.defaultVideo !== "none");
  const withAudio = options?.withAudio ?? true;

  // 1. Get or create conversation
  const conversation = await getOrCreateConversation(
    msg.channelId,
    msg.channel as ChannelType,
    { personaId, language }
  );
  const conversationId = conversation?.id ?? null;

  // 2. Build history for LLM
  let history: ChatMessage[] = [];
  if (conversationId) {
    const dbHistory = await getConversationHistory(conversationId, 10);
    history = dbHistory.map((m) => ({
      role: m.role as "user" | "assistant" | "system",
      content: m.text ?? "",
    }));
  }

  // Add current user message
  const userText = msg.text ?? (msg.audioUrl ? "[audio message]" : "[media message]");
  history.push({ role: "user", content: userText });

  // Save user message to DB
  if (conversationId) {
    await addMessage({
      conversationId,
      role: "user",
      text: userText,
      audioUrl: msg.audioUrl ?? null,
      imageUrl: msg.imageUrl ?? null,
      videoUrl: msg.videoUrl ?? null,
    });
  }

  // 3. Call LLM
  const llmConfig = buildLLMConfig(cfg);
  const llmResult = await callLLM(history, llmConfig, personaId, withVideo);

  // 4. In parallel: TTS + Video (independent, both optional)
  const ttsConfig = buildTTSConfig(cfg);
  const videoConfig = buildVideoConfig(cfg);

  const [ttsResult, videoResult] = await Promise.allSettled([
    withAudio && llmResult.text
      ? synthesizeSpeech(
          llmResult.audioPrompt ?? llmResult.text,
          ttsConfig,
          personaId,
          language
        )
      : Promise.resolve(null),
    withVideo && llmResult.videoPrompt
      ? generateVideo({ prompt: llmResult.videoPrompt }, videoConfig)
      : Promise.resolve(null),
  ]);

  const audioResult =
    ttsResult.status === "fulfilled" ? ttsResult.value : null;
  const videoFinal =
    videoResult.status === "fulfilled" ? videoResult.value : null;

  if (ttsResult.status === "rejected") {
    console.warn("[Orchestrator] TTS failed:", ttsResult.reason);
  }
  if (videoResult.status === "rejected") {
    console.warn("[Orchestrator] Video failed:", videoResult.reason);
  }

  // 5. Save assistant message to DB
  if (conversationId) {
    await addMessage({
      conversationId,
      role: "assistant",
      text: llmResult.text,
      audioUrl: audioResult?.url ?? null,
      videoUrl: videoFinal?.url ?? null,
      videoPrompt: llmResult.videoPrompt ?? null,
      audioPrompt: llmResult.audioPrompt ?? null,
    });
  }

  return {
    text: llmResult.text,
    audioUrl: audioResult?.url ?? null,
    videoUrl: videoFinal?.url ?? null,
    videoPrompt: llmResult.videoPrompt,
    audioPrompt: llmResult.audioPrompt,
    backend: {
      llm: llmResult.backend,
      tts: audioResult?.backend ?? null,
      video: videoFinal?.backend ?? null,
    },
    conversationId,
  };
}
