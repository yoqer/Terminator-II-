import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { terminatorRouter } from "./terminator/router";
import {
  createTrainingSession,
  getTrainingSession,
  getUserTrainingSessions,
  updateTrainingSession,
  createUploadedFile,
  getUserUploadedFiles,
} from "./db";
import { trainingManager } from "./trainingManager";
import { storagePut } from "./storage";
import { nanoid } from "nanoid";

// ─── Helpers ────────────────────────────────────────────────────────────────

/** Fetch session and verify it belongs to the requesting user. */
async function requireOwnSession(sessionId: number, userId: number) {
  const session = await getTrainingSession(sessionId);
  if (!session) {
    throw new TRPCError({ code: "NOT_FOUND", message: "Sesión no encontrada" });
  }
  if (session.userId !== userId) {
    throw new TRPCError({ code: "FORBIDDEN", message: "No tienes acceso a esta sesión" });
  }
  return session;
}

// ─── Schemas ─────────────────────────────────────────────────────────────────

const modelConfigSchema = z.object({
  // Arquitectura
  architecture: z.enum(["mlp", "cnn", "rnn", "lstm", "transformer", "custom"]).default("mlp"),
  hiddenSize: z.number().int().min(1).max(4096).default(64),
  numLayers: z.number().int().min(1).max(32).default(2),
  dropout: z.number().min(0).max(0.9).default(0.1),
  activation: z.enum(["relu", "gelu", "tanh", "sigmoid", "silu"]).default("relu"),

  // Entrenamiento
  epochs: z.number().int().min(1).max(10000).default(10),
  learningRate: z.number().positive().max(10).default(0.01),
  batchSize: z.number().int().min(1).max(8192).default(32),
  maxIterations: z.number().int().min(1).default(1000),
  earlyStopPatience: z.number().int().min(1).default(12),
  warmupSteps: z.number().int().min(0).default(0),
  weightDecay: z.number().min(0).max(1).default(0.0),
  gradientClip: z.number().min(0).default(1.0),

  // Optimizador
  optimizer: z.enum(["adam", "adamw", "sgd", "rmsprop", "adagrad"]).default("adam"),
  scheduler: z.enum(["none", "cosine", "linear", "step", "plateau"]).default("none"),

  // Hardware
  device: z.enum(["auto", "cpu", "cuda", "rocm", "mps"]).default("auto"),
  precision: z.enum(["fp32", "fp16", "bf16", "int8"]).default("fp32"),
  numWorkers: z.number().int().min(0).max(32).default(4),

  // Cuantización (post-entrenamiento)
  quantize: z.boolean().default(false),
  quantizeFormat: z.enum(["gguf_q4", "gguf_q5", "gguf_q8", "gptq", "awq", "none"]).default("none"),

  // Guardado
  saveCheckpoints: z.boolean().default(true),
  checkpointEvery: z.number().int().min(1).default(5),
  outputFormat: z.enum(["safetensors", "pytorch", "onnx", "gguf"]).default("safetensors"),
});

// ─── Router ─────────────────────────────────────────────────────────────────

export const appRouter = router({
  system: systemRouter,
  terminator: terminatorRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  files: router({
    upload: protectedProcedure
      .input(
        z.object({
          filename: z.string().min(1).max(255),
          content: z.string(), // base64 encoded
          fileType: z.string().min(1),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const userId = ctx.user.id;

        let buffer: Buffer;
        try {
          buffer = Buffer.from(input.content, "base64");
        } catch {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Contenido base64 inválido" });
        }

        // Enforce 10 MB server-side limit
        if (buffer.length > 10 * 1024 * 1024) {
          throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "El archivo supera el límite de 10 MB" });
        }

        // Validate file type
        const allowedTypes = ["text/csv", "text/plain", "application/json", "application/octet-stream"];
        const ext = input.filename.split(".").pop()?.toLowerCase();
        const validExt = ["csv", "txt", "json", "parquet", "jsonl"].includes(ext ?? "");
        if (!allowedTypes.includes(input.fileType) && !validExt) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Tipo de archivo no permitido. Use CSV, TXT, JSON, JSONL o Parquet." });
        }

        const fileKey = `${userId}-files/${nanoid()}-${input.filename}`;

        let url: string;
        try {
          ({ url } = await storagePut(fileKey, buffer, input.fileType));
        } catch (err) {
          console.error("[files.upload] storagePut failed:", err);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Error al subir el archivo al almacenamiento" });
        }

        const fileId = await createUploadedFile({
          userId,
          filename: input.filename,
          fileUrl: url,
          fileKey,
          fileType: input.fileType,
          fileSize: buffer.length,
        });

        return { fileId, url, fileKey };
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return getUserUploadedFiles(ctx.user.id);
    }),
  }),

  training: router({
    // ── Create session ──────────────────────────────────────────────────────
    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1).max(255),
          dataFileUrl: z.string().url(),
          config: modelConfigSchema,
        })
      )
      .mutation(async ({ ctx, input }) => {
        const sessionId = await createTrainingSession({
          userId: ctx.user.id,
          name: input.name,
          dataFileUrl: input.dataFileUrl,
          modelConfig: input.config,
          totalEpochs: input.config.epochs,
          status: "pending",
        });
        return { sessionId };
      }),

    // ── Start ───────────────────────────────────────────────────────────────
    start: protectedProcedure
      .input(z.object({ sessionId: z.number().int() }))
      .mutation(async ({ ctx, input }) => {
        const session = await requireOwnSession(input.sessionId, ctx.user.id);

        if (session.status === "running") {
          throw new TRPCError({ code: "BAD_REQUEST", message: "La sesión ya está en ejecución" });
        }
        if (session.status === "completed") {
          throw new TRPCError({ code: "BAD_REQUEST", message: "La sesión ya ha completado. Crea una nueva sesión." });
        }

        await updateTrainingSession(input.sessionId, { status: "running" });

        try {
          await trainingManager.startTraining(
            input.sessionId,
            session.dataFileUrl ?? "",
            session.modelConfig
          );
        } catch (err) {
          await updateTrainingSession(input.sessionId, { status: "failed" });
          console.error("[training.start] trainingManager error:", err);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: `Error al iniciar el proceso de entrenamiento: ${(err as Error).message}`,
          });
        }

        return { success: true };
      }),

    // ── Pause ───────────────────────────────────────────────────────────────
    pause: protectedProcedure
      .input(z.object({ sessionId: z.number().int() }))
      .mutation(async ({ ctx, input }) => {
        const session = await requireOwnSession(input.sessionId, ctx.user.id);

        if (session.status !== "running") {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Solo se puede pausar una sesión en ejecución" });
        }

        trainingManager.pauseTraining(input.sessionId);
        await updateTrainingSession(input.sessionId, { status: "paused" });
        return { success: true };
      }),

    // ── Resume ──────────────────────────────────────────────────────────────
    resume: protectedProcedure
      .input(z.object({ sessionId: z.number().int() }))
      .mutation(async ({ ctx, input }) => {
        const session = await requireOwnSession(input.sessionId, ctx.user.id);

        if (session.status !== "paused") {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Solo se puede reanudar una sesión pausada" });
        }

        trainingManager.resumeTraining(input.sessionId);
        await updateTrainingSession(input.sessionId, { status: "running" });
        return { success: true };
      }),

    // ── Stop ────────────────────────────────────────────────────────────────
    stop: protectedProcedure
      .input(z.object({ sessionId: z.number().int() }))
      .mutation(async ({ ctx, input }) => {
        await requireOwnSession(input.sessionId, ctx.user.id);

        trainingManager.stopTraining(input.sessionId);
        await updateTrainingSession(input.sessionId, {
          status: "completed",
          completedAt: new Date(),
        });
        return { success: true };
      }),

    // ── Update metrics (called by training process via internal webhook) ────
    updateMetrics: protectedProcedure
      .input(
        z.object({
          sessionId: z.number().int(),
          currentEpoch: z.number().int().optional(),
          currentLoss: z.number().optional(),
          metrics: z.record(z.string(), z.unknown()).optional(),
          status: z.enum(["pending", "running", "paused", "completed", "failed"]).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await requireOwnSession(input.sessionId, ctx.user.id);

        const updates: Record<string, unknown> = {};
        if (input.currentEpoch !== undefined) updates.currentEpoch = input.currentEpoch;
        if (input.currentLoss !== undefined) updates.currentLoss = input.currentLoss;
        if (input.metrics !== undefined) updates.metrics = input.metrics;
        if (input.status !== undefined) {
          updates.status = input.status;
          if (input.status === "completed" || input.status === "failed") {
            updates.completedAt = new Date();
          }
        }

        await updateTrainingSession(input.sessionId, updates as Partial<import('../drizzle/schema').InsertTrainingSession>);
        return { success: true };
      }),

    // ── Get single session ──────────────────────────────────────────────────
    get: protectedProcedure
      .input(z.object({ sessionId: z.number().int() }))
      .query(async ({ ctx, input }) => {
        return requireOwnSession(input.sessionId, ctx.user.id);
      }),

    // ── List all sessions ───────────────────────────────────────────────────
    list: protectedProcedure.query(async ({ ctx }) => {
      return getUserTrainingSessions(ctx.user.id);
    }),

    // ── Get training config presets ─────────────────────────────────────────
    presets: publicProcedure.query(() => {
      return {
        presets: [
          {
            id: "quick",
            name: "Rápido (demo)",
            description: "Entrenamiento rápido para pruebas",
            config: {
              architecture: "mlp",
              hiddenSize: 32,
              numLayers: 2,
              epochs: 5,
              learningRate: 0.01,
              batchSize: 32,
              optimizer: "adam",
              device: "auto",
              precision: "fp32",
            },
          },
          {
            id: "standard",
            name: "Estándar",
            description: "Configuración equilibrada para la mayoría de tareas",
            config: {
              architecture: "mlp",
              hiddenSize: 128,
              numLayers: 3,
              epochs: 50,
              learningRate: 0.001,
              batchSize: 64,
              optimizer: "adamw",
              weightDecay: 0.01,
              scheduler: "cosine",
              device: "auto",
              precision: "fp32",
              earlyStopPatience: 10,
            },
          },
          {
            id: "lora_finetune",
            name: "LoRA Fine-Tuning",
            description: "Fine-tuning eficiente con LoRA para LLMs",
            config: {
              architecture: "transformer",
              hiddenSize: 512,
              numLayers: 12,
              epochs: 3,
              learningRate: 0.0002,
              batchSize: 8,
              optimizer: "adamw",
              weightDecay: 0.01,
              scheduler: "cosine",
              warmupSteps: 100,
              gradientClip: 1.0,
              device: "auto",
              precision: "bf16",
              earlyStopPatience: 5,
            },
          },
          {
            id: "grpo",
            name: "GRPO (Reinforcement)",
            description: "Group Relative Policy Optimization para RLHF",
            config: {
              architecture: "transformer",
              hiddenSize: 512,
              numLayers: 12,
              epochs: 1,
              learningRate: 0.00005,
              batchSize: 4,
              optimizer: "adamw",
              weightDecay: 0.0,
              scheduler: "linear",
              warmupSteps: 50,
              gradientClip: 0.5,
              device: "auto",
              precision: "bf16",
            },
          },
          {
            id: "quantize_q4",
            name: "Cuantización Q4_K_M",
            description: "Entrenar y cuantizar a Q4 para inferencia eficiente",
            config: {
              architecture: "mlp",
              hiddenSize: 128,
              numLayers: 3,
              epochs: 20,
              learningRate: 0.001,
              batchSize: 32,
              optimizer: "adam",
              device: "auto",
              precision: "fp16",
              quantize: true,
              quantizeFormat: "gguf_q4",
              outputFormat: "gguf",
            },
          },
        ],
      };
    }),

    // ── Get hardware info ───────────────────────────────────────────────────
    hardwareInfo: protectedProcedure.query(async () => {
      try {
        const { execSync } = await import("child_process");
        let gpuInfo = "No detectada";
        let cudaVersion = "N/A";

        try {
          gpuInfo = execSync("nvidia-smi --query-gpu=name,memory.total --format=csv,noheader 2>/dev/null", {
            timeout: 3000,
          }).toString().trim();
          cudaVersion = execSync("nvcc --version 2>/dev/null | grep release | awk '{print $5}'", {
            timeout: 3000,
          }).toString().trim();
        } catch {
          try {
            gpuInfo = execSync("rocminfo 2>/dev/null | grep 'Marketing Name' | head -1", {
              timeout: 3000,
            }).toString().trim().replace("Marketing Name:", "").trim() || "AMD ROCm detectado";
          } catch {
            // No GPU available
          }
        }

        const cpuInfo = execSync("nproc 2>/dev/null || echo 1", { timeout: 2000 }).toString().trim();
        const memInfo = execSync("free -g 2>/dev/null | awk '/^Mem:/{print $2}' || echo 0", { timeout: 2000 }).toString().trim();

        return {
          gpu: gpuInfo || "No detectada",
          cudaVersion,
          cpuCores: parseInt(cpuInfo) || 1,
          ramGb: parseInt(memInfo) || 0,
          recommendedDevice: gpuInfo !== "No detectada" ? "cuda" : "cpu",
          recommendedPrecision: gpuInfo.includes("A100") || gpuInfo.includes("H100") ? "bf16" : "fp32",
        };
      } catch {
        return {
          gpu: "No detectada",
          cudaVersion: "N/A",
          cpuCores: 1,
          ramGb: 0,
          recommendedDevice: "cpu",
          recommendedPrecision: "fp32",
        };
      }
    }),
  }),
});

export type AppRouter = typeof appRouter;
