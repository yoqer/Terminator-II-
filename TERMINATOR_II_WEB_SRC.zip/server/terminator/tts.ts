/**
 * Terminator II — TTS / STT Router
 *
 * TTS chain: Kokoro (local Docker) → Grok Aurora → OpenAI TTS → Piper (local CPU)
 * STT chain: Grok STT → OpenAI Whisper API
 *
 * Returns audio as a public S3 URL.
 *
 * Kokoro Docker: docker run -p 8880:8880 ghcr.io/remsky/kokoro-fastapi-cpu:v0.2.2
 * Compatible with all 11 language repos from github.com/yoqer/TerminatorTTS-Kokoro-*
 */

import { storagePut } from "../storage";
import { nanoid } from "nanoid";

export interface TTSConfig {
  xaiApiKey?: string;
  openaiApiKey?: string;
  kokoroUrl?: string;   // e.g. "http://localhost:8880" — Kokoro Docker
  piperUrl?: string;    // e.g. "http://localhost:5000" — Piper TTS REST server
  preferredTts?: string; // "auto" | "kokoro" | "grok" | "openai" | "piper"
}

export interface STTConfig {
  xaiApiKey?: string;
  openaiApiKey?: string;
}

// ─── Language → Kokoro voice prefix ──────────────────────────────────────────
// Kokoro language codes from the yoqer repos:
// a=en-US, b=en-GB, d=de, e=es, f=fr, h=hi, i=it, j=ja, k=ko, p=pt-BR, z=zh
const KOKORO_LANG_PREFIX: Record<string, string> = {
  en: "a",
  "en-gb": "b",
  de: "d",
  es: "e",
  fr: "f",
  hi: "h",
  it: "i",
  ja: "j",
  ko: "k",
  pt: "p",
  zh: "z",
};

// Kokoro voices per persona and gender (prefix + voice suffix)
// af_ = American female, am_ = American male, etc.
const KOKORO_PERSONA_VOICE: Record<string, Record<string, string>> = {
  // [langPrefix][personaId] → voice name
  a: { default: "am_adam", ani: "af_heart", valentin: "am_michael" },
  b: { default: "bm_george", ani: "bf_emma", valentin: "bm_lewis" },
  d: { default: "dm_thorsten", ani: "df_hedda", valentin: "dm_thorsten" },
  e: { default: "em_alex", ani: "ef_dora", valentin: "em_alex" },
  f: { default: "fm_pierre", ani: "ff_siwis", valentin: "fm_pierre" },
  h: { default: "hm_varoon", ani: "hf_alpha", valentin: "hm_varoon" },
  i: { default: "im_riccardo", ani: "if_sara", valentin: "im_riccardo" },
  j: { default: "jm_kumo", ani: "jf_alpha", valentin: "jm_kumo" },
  k: { default: "km_yunho", ani: "kf_alpha", valentin: "km_yunho" },
  p: { default: "pm_alex", ani: "pf_dora", valentin: "pm_alex" },
  z: { default: "zm_yunxi", ani: "zf_xiaobei", valentin: "zm_yunxi" },
};

// ─── Grok voices ──────────────────────────────────────────────────────────────
const GROK_VOICE_MAP: Record<string, string> = {
  default: "rex",
  ani: "ara",
  valentin: "sal",
};

// ─── OpenAI voices ────────────────────────────────────────────────────────────
const OPENAI_VOICE_MAP: Record<string, string> = {
  default: "onyx",
  ani: "nova",
  valentin: "echo",
};

// ─── Piper language → model ───────────────────────────────────────────────────
const PIPER_MODEL_MAP: Record<string, string> = {
  es: "es_ES-davefx-medium",
  en: "en_US-lessac-medium",
  de: "de_DE-thorsten-medium",
  fr: "fr_FR-siwis-medium",
  it: "it_IT-riccardo-x_low",
  pt: "pt_BR-faber-medium",
};

// ─── Kokoro TTS (local Docker, OpenAI-compatible API) ────────────────────────

async function kokoroTTS(
  text: string,
  personaId: string,
  language: string,
  kokoroUrl: string
): Promise<Buffer | null> {
  try {
    const langKey = language.toLowerCase().split("-")[0];
    const prefix = KOKORO_LANG_PREFIX[language.toLowerCase()] ?? KOKORO_LANG_PREFIX[langKey] ?? "e";
    const voiceMap = KOKORO_PERSONA_VOICE[prefix] ?? KOKORO_PERSONA_VOICE["e"];
    const voice = voiceMap[personaId] ?? voiceMap["default"];

    const res = await fetch(`${kokoroUrl}/v1/audio/speech`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "kokoro",
        input: text,
        voice,
        response_format: "mp3",
        speed: 1.0,
      }),
      signal: AbortSignal.timeout(30000),
    });

    if (!res.ok) {
      console.warn(`[TTS] Kokoro HTTP ${res.status}: ${await res.text()}`);
      return null;
    }

    const ab = await res.arrayBuffer();
    return Buffer.from(ab);
  } catch (err) {
    console.warn("[TTS] Kokoro unavailable:", (err as Error).message);
    return null;
  }
}

// ─── Check Kokoro availability ────────────────────────────────────────────────

export async function checkKokoro(kokoroUrl: string): Promise<boolean> {
  try {
    const res = await fetch(`${kokoroUrl}/v1/models`, {
      signal: AbortSignal.timeout(3000),
    });
    return res.ok;
  } catch {
    return false;
  }
}

// ─── Grok TTS ─────────────────────────────────────────────────────────────────

async function grokTTS(
  text: string,
  personaId: string,
  apiKey: string
): Promise<Buffer> {
  const voice = GROK_VOICE_MAP[personaId] ?? "rex";
  const res = await fetch("https://api.x.ai/v1/audio/speech", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "grok-tts-aurora",
      input: text,
      voice,
      response_format: "mp3",
    }),
    signal: AbortSignal.timeout(30000),
  });
  if (!res.ok) throw new Error(`Grok TTS HTTP ${res.status}`);
  const ab = await res.arrayBuffer();
  return Buffer.from(ab);
}

// ─── OpenAI TTS ───────────────────────────────────────────────────────────────

async function openaiTTS(
  text: string,
  personaId: string,
  apiKey: string
): Promise<Buffer> {
  const voice = OPENAI_VOICE_MAP[personaId] ?? "onyx";
  const res = await fetch("https://api.openai.com/v1/audio/speech", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "tts-1",
      input: text,
      voice,
      response_format: "mp3",
    }),
    signal: AbortSignal.timeout(30000),
  });
  if (!res.ok) throw new Error(`OpenAI TTS HTTP ${res.status}`);
  const ab = await res.arrayBuffer();
  return Buffer.from(ab);
}

// ─── Piper TTS (local, CPU) ───────────────────────────────────────────────────

async function piperTTS(text: string, language = "es"): Promise<Buffer | null> {
  try {
    const { execSync } = await import("child_process");
    const { writeFileSync, readFileSync, unlinkSync } = await import("fs");
    const { tmpdir } = await import("os");
    const { join } = await import("path");

    const model = PIPER_MODEL_MAP[language] ?? PIPER_MODEL_MAP.es;
    const outFile = join(tmpdir(), `piper_${nanoid()}.wav`);
    const inFile = join(tmpdir(), `piper_in_${nanoid()}.txt`);

    writeFileSync(inFile, text, "utf-8");
    execSync(`piper --model ${model} --output_file ${outFile} < ${inFile}`, {
      timeout: 20000,
    });
    const buf = readFileSync(outFile);
    unlinkSync(outFile);
    unlinkSync(inFile);
    return buf;
  } catch {
    return null;
  }
}

// ─── Main TTS call ────────────────────────────────────────────────────────────

export async function synthesizeSpeech(
  text: string,
  config: TTSConfig,
  personaId = "default",
  language = "es"
): Promise<{ url: string; backend: string } | null> {
  if (!text.trim()) return null;

  const preferred = config.preferredTts ?? "auto";
  let audioBuffer: Buffer | null = null;
  let backend = "none";
  let ext = "mp3";

  // 1. Kokoro local (highest priority — free, local, 11 languages)
  const kokoroUrl = config.kokoroUrl ?? "http://localhost:8880";
  if (preferred === "auto" || preferred === "kokoro") {
    const buf = await kokoroTTS(text, personaId, language, kokoroUrl);
    if (buf) {
      audioBuffer = buf;
      backend = "kokoro";
      ext = "mp3";
    }
  }

  // 2. Grok Aurora TTS
  if (!audioBuffer && (preferred === "auto" || preferred === "grok") && config.xaiApiKey) {
    try {
      audioBuffer = await grokTTS(text, personaId, config.xaiApiKey);
      backend = "grok-tts";
      ext = "mp3";
    } catch (err) {
      console.warn("[TTS] Grok failed:", (err as Error).message);
    }
  }

  // 3. OpenAI TTS
  if (!audioBuffer && (preferred === "auto" || preferred === "openai") && config.openaiApiKey) {
    try {
      audioBuffer = await openaiTTS(text, personaId, config.openaiApiKey);
      backend = "openai-tts";
      ext = "mp3";
    } catch (err) {
      console.warn("[TTS] OpenAI failed:", (err as Error).message);
    }
  }

  // 4. Piper (CPU fallback, no external API needed)
  if (!audioBuffer && (preferred === "auto" || preferred === "piper")) {
    try {
      const piperBuf = await piperTTS(text, language);
      if (piperBuf) {
        audioBuffer = piperBuf;
        backend = "piper";
        ext = "wav";
      }
    } catch (err) {
      console.warn("[TTS] Piper failed:", (err as Error).message);
    }
  }

  if (!audioBuffer) return null;

  const key = `terminator/audio/${nanoid()}.${ext}`;
  const { url } = await storagePut(
    key,
    audioBuffer,
    `audio/${ext === "wav" ? "wav" : "mpeg"}`
  );
  return { url, backend };
}

// ─── STT ──────────────────────────────────────────────────────────────────────

export async function transcribeAudio(
  audioUrl: string,
  config: STTConfig,
  language?: string
): Promise<{ text: string; backend: string } | null> {
  // Download audio first
  let audioBuffer: Uint8Array;
  try {
    const res = await fetch(audioUrl, { signal: AbortSignal.timeout(30000) });
    if (!res.ok) throw new Error(`Download failed: HTTP ${res.status}`);
    const ab = await res.arrayBuffer();
    audioBuffer = new Uint8Array(ab.slice(0));
  } catch (err) {
    console.error("[STT] Failed to download audio:", (err as Error).message);
    return null;
  }

  // Try Grok STT first
  if (config.xaiApiKey) {
    try {
      const formData = new FormData();
      const ab1 = audioBuffer.buffer.slice(
        audioBuffer.byteOffset,
        audioBuffer.byteOffset + audioBuffer.byteLength
      ) as ArrayBuffer;
      formData.append("file", new Blob([ab1], { type: "audio/mpeg" }), "audio.mp3");
      formData.append("model", "whisper-large-v3");
      if (language) formData.append("language", language);

      const res = await fetch("https://api.x.ai/v1/audio/transcriptions", {
        method: "POST",
        headers: { Authorization: `Bearer ${config.xaiApiKey}` },
        body: formData,
        signal: AbortSignal.timeout(30000),
      });
      if (!res.ok) throw new Error(`Grok STT HTTP ${res.status}`);
      const json = (await res.json()) as { text?: string };
      if (json.text) return { text: json.text, backend: "grok-stt" };
    } catch (err) {
      console.warn("[STT] Grok failed:", (err as Error).message);
    }
  }

  // Fallback: OpenAI Whisper
  if (config.openaiApiKey) {
    try {
      const formData = new FormData();
      const ab2 = audioBuffer.buffer.slice(
        audioBuffer.byteOffset,
        audioBuffer.byteOffset + audioBuffer.byteLength
      ) as ArrayBuffer;
      formData.append("file", new Blob([ab2], { type: "audio/mpeg" }), "audio.mp3");
      formData.append("model", "whisper-1");
      if (language) formData.append("language", language);

      const res = await fetch("https://api.openai.com/v1/audio/transcriptions", {
        method: "POST",
        headers: { Authorization: `Bearer ${config.openaiApiKey}` },
        body: formData,
        signal: AbortSignal.timeout(30000),
      });
      if (!res.ok) throw new Error(`OpenAI STT HTTP ${res.status}`);
      const json = (await res.json()) as { text?: string };
      if (json.text) return { text: json.text, backend: "openai-whisper" };
    } catch (err) {
      console.warn("[STT] OpenAI Whisper failed:", (err as Error).message);
    }
  }

  return null;
}

// ─── Kokoro language list (for UI) ────────────────────────────────────────────

export const KOKORO_LANGUAGES = [
  { code: "es", label: "Español", prefix: "e" },
  { code: "en", label: "English (US)", prefix: "a" },
  { code: "en-gb", label: "English (UK)", prefix: "b" },
  { code: "de", label: "Deutsch", prefix: "d" },
  { code: "fr", label: "Français", prefix: "f" },
  { code: "hi", label: "हिन्दी", prefix: "h" },
  { code: "it", label: "Italiano", prefix: "i" },
  { code: "ja", label: "日本語", prefix: "j" },
  { code: "ko", label: "한국어", prefix: "k" },
  { code: "pt", label: "Português (BR)", prefix: "p" },
  { code: "zh", label: "中文", prefix: "z" },
] as const;
