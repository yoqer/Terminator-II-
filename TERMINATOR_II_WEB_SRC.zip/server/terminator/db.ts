/**
 * Terminator II — Database helpers
 * Query helpers for conversations, messages, and config tables.
 */
import { eq, desc } from "drizzle-orm";
import { getDb } from "../db";
import { conversations, messages, terminatorConfig } from "../../drizzle/schema";
import type {
  InsertConversation,
  InsertMessage,
  InsertTerminatorConfig,
  Conversation,
  Message,
  TerminatorConfig,
} from "../../drizzle/schema";

// ─── Conversations ────────────────────────────────────────────────────────────

export async function getOrCreateConversation(
  channelId: string,
  channel: InsertConversation["channel"],
  defaults?: Partial<InsertConversation>
): Promise<Conversation | null> {
  const db = await getDb();
  if (!db) return null;

  const existing = await db
    .select()
    .from(conversations)
    .where(eq(conversations.channelId, channelId))
    .limit(1);

  if (existing.length > 0) return existing[0];

  await db.insert(conversations).values({
    channelId,
    channel,
    personaId: defaults?.personaId ?? "default",
    llmBackend: defaults?.llmBackend ?? "auto",
    ttsBackend: defaults?.ttsBackend ?? "auto",
    videoBackend: defaults?.videoBackend ?? "none",
    language: defaults?.language ?? "es",
  });

  const created = await db
    .select()
    .from(conversations)
    .where(eq(conversations.channelId, channelId))
    .limit(1);
  return created[0] ?? null;
}

export async function updateConversation(
  id: number,
  updates: Partial<InsertConversation>
): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.update(conversations).set(updates).where(eq(conversations.id, id));
}

// ─── Messages ─────────────────────────────────────────────────────────────────

export async function addMessage(data: InsertMessage): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.insert(messages).values(data);
}

export async function getConversationHistory(
  conversationId: number,
  limit = 20
): Promise<Message[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(desc(messages.createdAt))
    .limit(limit);
  return rows.reverse();
}

// ─── Config ───────────────────────────────────────────────────────────────────

export async function getTerminatorConfig(
  userId: number
): Promise<TerminatorConfig | null> {
  const db = await getDb();
  if (!db) return null;
  const rows = await db
    .select()
    .from(terminatorConfig)
    .where(eq(terminatorConfig.userId, userId))
    .limit(1);
  return rows[0] ?? null;
}

export async function upsertTerminatorConfig(
  userId: number,
  data: Partial<InsertTerminatorConfig>
): Promise<void> {
  const db = await getDb();
  if (!db) return;
  const existing = await getTerminatorConfig(userId);
  if (existing) {
    await db
      .update(terminatorConfig)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(terminatorConfig.userId, userId));
  } else {
    await db.insert(terminatorConfig).values({ userId, ...data });
  }
}
