/**
 * Terminator II — Channel Handlers
 *
 * Normalizes incoming messages from all channels into a unified TerminatorMessage
 * and provides send functions for each channel.
 */

export type ChannelType = "web" | "whatsapp" | "telegram" | "sms" | "voice" | "video";

export interface TerminatorMessage {
  channelId: string;
  channel: ChannelType;
  text?: string;
  audioUrl?: string;
  imageUrl?: string;
  videoUrl?: string;
  language?: string;
  metadata?: Record<string, unknown>;
}

// ─── WhatsApp Business API ────────────────────────────────────────────────────

export interface WhatsAppWebhookBody {
  object?: string;
  entry?: Array<{
    changes?: Array<{
      value?: {
        messages?: Array<{
          from?: string;
          type?: string;
          text?: { body?: string };
          audio?: { id?: string };
          image?: { id?: string };
          video?: { id?: string };
        }>;
        metadata?: { phone_number_id?: string };
      };
    }>;
  }>;
}

export function parseWhatsAppWebhook(body: WhatsAppWebhookBody): TerminatorMessage | null {
  const entry = body.entry?.[0];
  const change = entry?.changes?.[0]?.value;
  const msg = change?.messages?.[0];
  if (!msg?.from) return null;

  const channelId = `whatsapp:${msg.from}`;
  const base: TerminatorMessage = { channelId, channel: "whatsapp" };

  if (msg.type === "text") {
    return { ...base, text: msg.text?.body };
  }
  if (msg.type === "audio") {
    // Audio ID needs to be resolved via WhatsApp Media API
    return { ...base, metadata: { whatsappMediaId: msg.audio?.id, mediaType: "audio" } };
  }
  if (msg.type === "image") {
    return { ...base, metadata: { whatsappMediaId: msg.image?.id, mediaType: "image" } };
  }
  return { ...base, text: `[${msg.type} message]` };
}

export async function sendWhatsAppMessage(
  to: string,
  phoneNumberId: string,
  token: string,
  payload: {
    text?: string;
    audioUrl?: string;
    imageUrl?: string;
    videoUrl?: string;
  }
): Promise<void> {
  const base = `https://graph.facebook.com/v20.0/${phoneNumberId}/messages`;
  const headers = {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`,
  };

  if (payload.text) {
    await fetch(base, {
      method: "POST",
      headers,
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to,
        type: "text",
        text: { body: payload.text },
      }),
    });
  }

  if (payload.audioUrl) {
    await fetch(base, {
      method: "POST",
      headers,
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to,
        type: "audio",
        audio: { link: payload.audioUrl },
      }),
    });
  }

  if (payload.imageUrl) {
    await fetch(base, {
      method: "POST",
      headers,
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to,
        type: "image",
        image: { link: payload.imageUrl },
      }),
    });
  }

  // WhatsApp doesn't support direct video links > 16MB; send as document or text link
  if (payload.videoUrl && !payload.audioUrl) {
    await fetch(base, {
      method: "POST",
      headers,
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to,
        type: "text",
        text: { body: `Video generado: ${payload.videoUrl}` },
      }),
    });
  }
}

// ─── Telegram Bot API ─────────────────────────────────────────────────────────

export interface TelegramWebhookBody {
  message?: {
    chat?: { id?: number };
    from?: { id?: number; language_code?: string };
    text?: string;
    voice?: { file_id?: string };
    photo?: Array<{ file_id?: string }>;
    video?: { file_id?: string };
  };
}

export function parseTelegramWebhook(body: TelegramWebhookBody): TerminatorMessage | null {
  const msg = body.message;
  const chatId = msg?.chat?.id;
  if (!chatId) return null;

  const channelId = `telegram:${chatId}`;
  const language = msg?.from?.language_code;
  const base: TerminatorMessage = { channelId, channel: "telegram", language };

  if (msg?.text) return { ...base, text: msg.text };
  if (msg?.voice?.file_id) {
    return { ...base, metadata: { telegramFileId: msg.voice.file_id, mediaType: "audio" } };
  }
  if (msg?.photo) {
    const largest = msg.photo[msg.photo.length - 1];
    return { ...base, metadata: { telegramFileId: largest?.file_id, mediaType: "image" } };
  }
  return { ...base, text: "[media message]" };
}

export async function sendTelegramMessage(
  chatId: number | string,
  botToken: string,
  payload: {
    text?: string;
    audioUrl?: string;
    videoUrl?: string;
    imageUrl?: string;
  }
): Promise<void> {
  const base = `https://api.telegram.org/bot${botToken}`;

  if (payload.text) {
    await fetch(`${base}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text: payload.text }),
    });
  }

  if (payload.audioUrl) {
    await fetch(`${base}/sendAudio`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, audio: payload.audioUrl }),
    });
  }

  if (payload.videoUrl) {
    await fetch(`${base}/sendVideo`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, video: payload.videoUrl }),
    });
  }

  if (payload.imageUrl) {
    await fetch(`${base}/sendPhoto`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, photo: payload.imageUrl }),
    });
  }
}

// ─── Twilio SMS/MMS ───────────────────────────────────────────────────────────

export interface TwilioSMSBody {
  From?: string;
  Body?: string;
  NumMedia?: string;
  MediaUrl0?: string;
  MediaContentType0?: string;
}

export function parseTwilioSMS(body: TwilioSMSBody): TerminatorMessage | null {
  if (!body.From) return null;

  const channelId = `sms:${body.From}`;
  const numMedia = parseInt(body.NumMedia ?? "0", 10);
  const base: TerminatorMessage = { channelId, channel: "sms" };

  if (numMedia > 0 && body.MediaUrl0) {
    const contentType = body.MediaContentType0 ?? "";
    if (contentType.startsWith("audio/")) {
      return { ...base, text: body.Body, audioUrl: body.MediaUrl0 };
    }
    if (contentType.startsWith("image/")) {
      return { ...base, text: body.Body, imageUrl: body.MediaUrl0 };
    }
  }

  return { ...base, text: body.Body };
}

export async function sendTwilioSMS(
  to: string,
  from: string,
  accountSid: string,
  authToken: string,
  payload: {
    text?: string;
    imageUrl?: string;
    videoUrl?: string;
  }
): Promise<void> {
  const url = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`;
  const auth = Buffer.from(`${accountSid}:${authToken}`).toString("base64");

  const body = new URLSearchParams({ To: to, From: from });

  // Build message body
  let msgBody = payload.text ?? "";
  if (payload.videoUrl) {
    msgBody += (msgBody ? "\n" : "") + `Video: ${payload.videoUrl}`;
  }
  if (msgBody) body.set("Body", msgBody);

  // MMS: attach image if provided (US/CA only)
  if (payload.imageUrl) {
    body.set("MediaUrl", payload.imageUrl);
  }

  await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Authorization: `Basic ${auth}`,
    },
    body: body.toString(),
  });
}
