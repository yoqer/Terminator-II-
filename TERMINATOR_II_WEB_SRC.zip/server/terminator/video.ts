/**
 * Terminator II — Video Router
 *
 * Backends: Grok Video API (grok-imagine-video) → local Wan2.1/LTX-Video (when available)
 * Returns a public S3 URL for the generated video.
 */

import { storagePut } from "../storage";
import { nanoid } from "nanoid";

export interface VideoConfig {
  xaiApiKey?: string;
  preferredVideo?: string; // "auto" | "grok" | "wan2" | "ltx" | "none"
}

export interface VideoGenerationOptions {
  prompt: string;
  referenceImageUrl?: string;
  previousVideoUrl?: string; // for chained extension
  duration?: number; // seconds, default 5
  aspectRatio?: "16:9" | "9:16" | "1:1";
}

export interface VideoResult {
  url: string;
  backend: string;
}

// ─── Grok Video API ───────────────────────────────────────────────────────────

async function grokGenerateVideo(
  opts: VideoGenerationOptions,
  apiKey: string
): Promise<VideoResult> {
  // Step 1: Submit generation job
  const body: Record<string, unknown> = {
    model: "grok-imagine-video",
    prompt: opts.prompt,
    n: 1,
    duration: opts.duration ?? 5,
    aspect_ratio: opts.aspectRatio ?? "16:9",
  };

  if (opts.referenceImageUrl) {
    body.reference_images = [{ url: opts.referenceImageUrl }];
  }
  if (opts.previousVideoUrl) {
    body.extend_video = { url: opts.previousVideoUrl };
  }

  const submitRes = await fetch("https://api.x.ai/v1/video/generations", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(15000),
  });

  if (!submitRes.ok) {
    const errText = await submitRes.text().catch(() => "");
    throw new Error(`Grok Video submit HTTP ${submitRes.status}: ${errText}`);
  }

  const job = (await submitRes.json()) as { id?: string; status?: string };
  const jobId = job.id;
  if (!jobId) throw new Error("Grok Video: no job ID returned");

  // Step 2: Poll for completion (max 3 minutes)
  const maxWait = 180000;
  const pollInterval = 5000;
  const deadline = Date.now() + maxWait;

  while (Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, pollInterval));

    const pollRes = await fetch(`https://api.x.ai/v1/video/generations/${jobId}`, {
      headers: { Authorization: `Bearer ${apiKey}` },
      signal: AbortSignal.timeout(10000),
    });

    if (!pollRes.ok) continue;

    const status = (await pollRes.json()) as {
      status?: string;
      video?: { url?: string };
      generations?: Array<{ video?: { url?: string } }>;
    };

    if (status.status === "completed" || status.status === "succeeded") {
      const videoUrl =
        status.video?.url ??
        status.generations?.[0]?.video?.url;
      if (!videoUrl) throw new Error("Grok Video: completed but no URL");

      // Download and re-upload to our S3 for stable URL
      const dlRes = await fetch(videoUrl, { signal: AbortSignal.timeout(60000) });
      if (!dlRes.ok) throw new Error(`Grok Video download HTTP ${dlRes.status}`);
      const buf = new Uint8Array(await dlRes.arrayBuffer());
      const key = `terminator/video/${nanoid()}.mp4`;
      const { url } = await storagePut(key, buf, "video/mp4");
      return { url, backend: "grok-video" };
    }

    if (status.status === "failed") {
      throw new Error("Grok Video generation failed");
    }
  }

  throw new Error("Grok Video: timeout waiting for generation");
}

// ─── Local video check (Wan2.1 / LTX-Video via local API) ────────────────────

async function isLocalVideoAvailable(): Promise<boolean> {
  // Check if a local video generation server is running on port 7860 (Gradio) or 8000
  for (const port of [7860, 8000, 8080]) {
    try {
      const res = await fetch(`http://localhost:${port}/health`, {
        signal: AbortSignal.timeout(1000),
      });
      if (res.ok) return true;
    } catch {
      // not available
    }
  }
  return false;
}

// ─── Main video generation ────────────────────────────────────────────────────

export async function generateVideo(
  opts: VideoGenerationOptions,
  config: VideoConfig
): Promise<VideoResult | null> {
  const preferred = config.preferredVideo ?? "auto";

  if (preferred === "none") return null;

  if ((preferred === "auto" || preferred === "grok") && config.xaiApiKey) {
    try {
      return await grokGenerateVideo(opts, config.xaiApiKey);
    } catch (err) {
      console.warn("[Video] Grok failed:", (err as Error).message);
    }
  }

  if (preferred === "auto" || preferred === "wan2" || preferred === "ltx") {
    if (await isLocalVideoAvailable()) {
      console.log("[Video] Local video backend detected but not yet integrated");
    }
  }

  return null;
}
