/**
 * Terminator II — Unit tests
 * Tests for LLM router, orchestrator and channel parsers.
 */

import { describe, it, expect, vi, beforeEach } from "vitest";

// ─── Mock DB ──────────────────────────────────────────────────────────────────
vi.mock("./terminator/db", () => ({
  getTerminatorConfig: vi.fn().mockResolvedValue(null),
  upsertTerminatorConfig: vi.fn().mockResolvedValue(undefined),
  getOrCreateConversation: vi.fn().mockResolvedValue({ id: 1, channelId: "web:test", channel: "web" }),
  getConversationHistory: vi.fn().mockResolvedValue([]),
  addMessage: vi.fn().mockResolvedValue(undefined),
  updateConversation: vi.fn().mockResolvedValue(undefined),
}));

// ─── Mock LLM ─────────────────────────────────────────────────────────────────
vi.mock("./terminator/llm", () => ({
  callLLM: vi.fn().mockResolvedValue({
    text: "Hola, soy el Terminator.",
    videoPrompt: null,
    audioPrompt: null,
    backend: "mock",
  }),
  checkLLMBackends: vi.fn().mockResolvedValue({
    ollama: false,
    lmstudio: false,
    grok: false,
    openai: false,
    kimi: false,
    deepseek: false,
  }),
}));

// ─── Mock TTS ─────────────────────────────────────────────────────────────────
vi.mock("./terminator/tts", () => ({
  synthesizeSpeech: vi.fn().mockResolvedValue(null),
  transcribeAudio: vi.fn().mockResolvedValue({ text: "hola mundo" }),
}));

// ─── Mock Video ───────────────────────────────────────────────────────────────
vi.mock("./terminator/video", () => ({
  generateVideo: vi.fn().mockResolvedValue(null),
}));

// ─── Tests ────────────────────────────────────────────────────────────────────

describe("Terminator II — Channel parsers", () => {
  it("parseWhatsAppWebhook returns null for empty body", async () => {
    const { parseWhatsAppWebhook } = await import("./terminator/channels");
    const result = parseWhatsAppWebhook({} as never);
    expect(result).toBeNull();
  });

  it("parseTelegramWebhook returns null for empty body", async () => {
    const { parseTelegramWebhook } = await import("./terminator/channels");
    const result = parseTelegramWebhook({} as never);
    expect(result).toBeNull();
  });

  it("parseTwilioSMS returns null for empty body", async () => {
    const { parseTwilioSMS } = await import("./terminator/channels");
    const result = parseTwilioSMS({} as never);
    expect(result).toBeNull();
  });

  it("parseWhatsAppWebhook parses a valid text message", async () => {
    const { parseWhatsAppWebhook } = await import("./terminator/channels");
    const body = {
      entry: [
        {
          changes: [
            {
              value: {
                messages: [
                  {
                    from: "+34600000000",
                    type: "text",
                    text: { body: "Hola Terminator" },
                  },
                ],
              },
            },
          ],
        },
      ],
    };
    const result = parseWhatsAppWebhook(body as never);
    expect(result).not.toBeNull();
    expect(result?.channel).toBe("whatsapp");
    expect(result?.text).toBe("Hola Terminator");
    expect(result?.channelId).toBe("whatsapp:+34600000000");
  });

  it("parseTelegramWebhook parses a valid text message", async () => {
    const { parseTelegramWebhook } = await import("./terminator/channels");
    const body = {
      message: {
        chat: { id: 123456 },
        text: "Hola desde Telegram",
      },
    };
    const result = parseTelegramWebhook(body as never);
    expect(result).not.toBeNull();
    expect(result?.channel).toBe("telegram");
    expect(result?.text).toBe("Hola desde Telegram");
    expect(result?.channelId).toBe("telegram:123456");
  });

  it("parseTwilioSMS parses a valid SMS body", async () => {
    const { parseTwilioSMS } = await import("./terminator/channels");
    const body = {
      From: "+34600000001",
      Body: "Hola por SMS",
    };
    const result = parseTwilioSMS(body as never);
    expect(result).not.toBeNull();
    expect(result?.channel).toBe("sms");
    expect(result?.text).toBe("Hola por SMS");
    expect(result?.channelId).toBe("sms:+34600000001");
  });
});

describe("Terminator II — Orchestrator", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("processMessage returns text response without audio/video when disabled", async () => {
    const { processMessage } = await import("./terminator/orchestrator");
    const result = await processMessage(
      { channelId: "web:test", channel: "web", text: "Hola" },
      null,
      { withAudio: false, withVideo: false }
    );
    expect(result.text).toBe("Hola, soy el Terminator.");
    expect(result.audioUrl).toBeNull();
    expect(result.videoUrl).toBeNull();
  });

  it("processMessage calls TTS when withAudio is true", async () => {
    const { synthesizeSpeech } = await import("./terminator/tts");
    const { processMessage } = await import("./terminator/orchestrator");
    await processMessage(
      { channelId: "web:test2", channel: "web", text: "Hola" },
      null,
      { withAudio: true, withVideo: false }
    );
    expect(synthesizeSpeech).toHaveBeenCalled();
  });

  it("processMessage calls video generator when withVideo is true", async () => {
    const { generateVideo } = await import("./terminator/video");
    const { callLLM } = await import("./terminator/llm");
    // LLM returns a videoPrompt
    vi.mocked(callLLM).mockResolvedValueOnce({
      text: "Aquí va la respuesta.",
      videoPrompt: "Un robot caminando por la ciudad",
      audioPrompt: null,
      backend: "mock",
    });
    const { processMessage } = await import("./terminator/orchestrator");
    await processMessage(
      { channelId: "web:test3", channel: "web", text: "Dame un video" },
      null,
      { withAudio: false, withVideo: true }
    );
    expect(generateVideo).toHaveBeenCalled();
  });
});

describe("Terminator II — LLM backends check", () => {
  it("checkLLMBackends returns all false when no services available", async () => {
    const { checkLLMBackends } = await import("./terminator/llm");
    const result = await checkLLMBackends({
      ollamaUrl: "http://localhost:11434",
      lmstudioUrl: "http://localhost:1234",
    });
    expect(result).toHaveProperty("ollama");
    expect(result).toHaveProperty("lmstudio");
    expect(result).toHaveProperty("grok");
    expect(result).toHaveProperty("openai");
  });
});
