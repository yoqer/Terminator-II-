CREATE TABLE `conversations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`channelId` varchar(128) NOT NULL,
	`channel` enum('web','whatsapp','telegram','sms','voice','video') NOT NULL,
	`personaId` varchar(64) NOT NULL DEFAULT 'default',
	`llmBackend` varchar(64) NOT NULL DEFAULT 'auto',
	`ttsBackend` varchar(64) NOT NULL DEFAULT 'auto',
	`videoBackend` varchar(64) NOT NULL DEFAULT 'none',
	`language` varchar(16) NOT NULL DEFAULT 'es',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `conversations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`conversationId` int NOT NULL,
	`role` enum('user','assistant','system') NOT NULL,
	`text` text,
	`audioUrl` text,
	`videoUrl` text,
	`imageUrl` text,
	`videoPrompt` text,
	`audioPrompt` text,
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `terminator_config` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`ollamaUrl` varchar(255) DEFAULT 'http://localhost:11434',
	`lmstudioUrl` varchar(255) DEFAULT 'http://localhost:1234',
	`xaiApiKey` text,
	`openaiApiKey` text,
	`moonshotApiKey` text,
	`deepseekApiKey` text,
	`twilioAccountSid` text,
	`twilioAuthToken` text,
	`twilioPhoneNumber` varchar(32),
	`whatsappToken` text,
	`whatsappPhoneNumberId` varchar(64),
	`whatsappVerifyToken` varchar(128),
	`telegramBotToken` text,
	`defaultPersona` varchar(64) DEFAULT 'default',
	`defaultLlm` varchar(64) DEFAULT 'auto',
	`defaultTts` varchar(64) DEFAULT 'auto',
	`defaultVideo` varchar(64) DEFAULT 'none',
	`defaultLanguage` varchar(16) DEFAULT 'es',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `terminator_config_id` PRIMARY KEY(`id`),
	CONSTRAINT `terminator_config_userId_unique` UNIQUE(`userId`)
);
