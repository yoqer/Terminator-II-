import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { useState, useRef, useEffect, useMemo } from "react";
import { toast } from "sonner";
import {
  Loader2, Play, Pause, Square, Upload, FileText, Code2,
  TrendingDown, Cpu, Zap, Settings2, ChevronDown, ChevronUp,
  BarChart3, CheckCircle2, XCircle, Clock, RefreshCw
} from "lucide-react";
import { Link } from "wouter";
import { useI18n } from "@/lib/i18n";
import { LanguageSelector } from "@/components/LanguageSelector";

// ─── Loss sparkline chart ────────────────────────────────────────────────────
function LossChart({ losses }: { losses: number[] }) {
  if (!losses || losses.length < 2) return null;
  const max = Math.max(...losses);
  const min = Math.min(...losses);
  const range = max - min || 1;
  const w = 300;
  const h = 64;
  const pts = losses
    .map((v, i) => {
      const x = (i / (losses.length - 1)) * w;
      const y = h - ((v - min) / range) * (h - 4) - 2;
      return `${x},${y}`;
    })
    .join(" ");
  const area = `0,${h} ${pts} ${w},${h}`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-16 mt-1" preserveAspectRatio="none">
      <defs>
        <linearGradient id="lossGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={area} fill="url(#lossGrad)" />
      <polyline points={pts} fill="none" stroke="#3b82f6" strokeWidth="2" strokeLinejoin="round" />
    </svg>
  );
}

// ─── Status badge ─────────────────────────────────────────────────────────────
function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { color: string; icon: React.ReactNode }> = {
    running: { color: "bg-green-600", icon: <RefreshCw className="w-3 h-3 animate-spin" /> },
    paused: { color: "bg-yellow-600", icon: <Clock className="w-3 h-3" /> },
    completed: { color: "bg-blue-600", icon: <CheckCircle2 className="w-3 h-3" /> },
    failed: { color: "bg-red-600", icon: <XCircle className="w-3 h-3" /> },
    pending: { color: "bg-slate-600", icon: <Clock className="w-3 h-3" /> },
  };
  const s = map[status] ?? map.pending;
  return (
    <span className={`inline-flex items-center gap-1 text-xs px-2 py-1 rounded text-white ${s.color}`}>
      {s.icon}
      {status}
    </span>
  );
}

// ─── File validation ──────────────────────────────────────────────────────────
const MAX_FILE_SIZE = 10 * 1024 * 1024;
const ALLOWED_TYPES = ["text/csv", "text/plain", "application/json", "application/octet-stream"];

// ─── Default config ───────────────────────────────────────────────────────────
const DEFAULT_CONFIG = {
  architecture: "mlp" as const,
  hiddenSize: 64,
  numLayers: 2,
  dropout: 0.1,
  activation: "relu" as const,
  epochs: 10,
  learningRate: 0.01,
  batchSize: 32,
  maxIterations: 1000,
  earlyStopPatience: 12,
  warmupSteps: 0,
  weightDecay: 0.0,
  gradientClip: 1.0,
  optimizer: "adam" as const,
  scheduler: "none" as const,
  device: "auto" as const,
  precision: "fp32" as const,
  numWorkers: 4,
  quantize: false,
  quantizeFormat: "none" as const,
  saveCheckpoints: true,
  checkpointEvery: 5,
  outputFormat: "safetensors" as const,
};

export default function Training() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const { t } = useI18n();

  // File state
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileContent, setFileContent] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Session state
  const [currentSessionId, setCurrentSessionId] = useState<number | null>(null);
  const [lossHistory, setLossHistory] = useState<number[]>([]);

  // Config state
  const [config, setConfig] = useState(DEFAULT_CONFIG);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [selectedPreset, setSelectedPreset] = useState<string>("");

  // Stable empty array for disabled query
  const emptySessionIds = useMemo(() => [], []);
  void emptySessionIds;

  // ── Queries ──────────────────────────────────────────────────────────────────
  const { data: sessions, refetch: refetchSessions } = trpc.training.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: currentSession } = trpc.training.get.useQuery(
    { sessionId: currentSessionId! },
    { enabled: !!currentSessionId, refetchInterval: 2000 }
  );

  const { data: presetsData } = trpc.training.presets.useQuery();

  const { data: hwInfo } = trpc.training.hardwareInfo.useQuery(undefined, {
    enabled: isAuthenticated,
    staleTime: 60_000,
  });

  // ── Track loss history ───────────────────────────────────────────────────────
  useEffect(() => {
    if (currentSession?.currentLoss != null) {
      setLossHistory((prev) => {
        const next = [...prev, currentSession.currentLoss as number];
        return next.slice(-80);
      });
    }
  }, [currentSession?.currentLoss, currentSession?.currentEpoch]);

  // ── Mutations ────────────────────────────────────────────────────────────────
  const uploadMutation = trpc.files.upload.useMutation({
    onSuccess: () => toast.success("Archivo subido correctamente"),
    onError: (e) => toast.error(`Error al subir: ${e.message}`),
  });

  const createSessionMutation = trpc.training.create.useMutation({
    onSuccess: (data) => {
      setCurrentSessionId(data.sessionId);
      setLossHistory([]);
      refetchSessions();
      toast.success("Sesión de entrenamiento creada");
    },
    onError: (e) => toast.error(`Error al crear sesión: ${e.message}`),
  });

  const startMutation = trpc.training.start.useMutation({
    onSuccess: () => { toast.success("Entrenamiento iniciado"); refetchSessions(); },
    onError: (e) => toast.error(`Error: ${e.message}`),
  });

  const pauseMutation = trpc.training.pause.useMutation({
    onSuccess: () => { toast.success("Entrenamiento pausado"); refetchSessions(); },
    onError: (e) => toast.error(`Error: ${e.message}`),
  });

  const resumeMutation = trpc.training.resume.useMutation({
    onSuccess: () => { toast.success("Entrenamiento reanudado"); refetchSessions(); },
    onError: (e) => toast.error(`Error: ${e.message}`),
  });

  const stopMutation = trpc.training.stop.useMutation({
    onSuccess: () => { toast.success("Entrenamiento detenido"); refetchSessions(); },
    onError: (e) => toast.error(`Error: ${e.message}`),
  });

  // ── Handlers ─────────────────────────────────────────────────────────────────
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > MAX_FILE_SIZE) {
      toast.error("El archivo supera el límite de 10 MB");
      if (fileInputRef.current) fileInputRef.current.value = "";
      return;
    }
    const ext = file.name.split(".").pop()?.toLowerCase();
    const validExt = ["csv", "txt", "json", "jsonl"].includes(ext ?? "");
    if (!ALLOWED_TYPES.includes(file.type) && !validExt) {
      toast.error("Formato no válido. Use CSV, TXT, JSON o JSONL.");
      if (fileInputRef.current) fileInputRef.current.value = "";
      return;
    }
    setSelectedFile(file);
    const reader = new FileReader();
    reader.onload = (ev) => setFileContent(ev.target?.result as string ?? "");
    reader.readAsText(file);
  };

  const applyPreset = (presetId: string) => {
    const preset = presetsData?.presets.find((p) => p.id === presetId);
    if (!preset) return;
    setConfig({ ...DEFAULT_CONFIG, ...(preset.config as Partial<typeof DEFAULT_CONFIG>) });
    setSelectedPreset(presetId);
    toast.success(`Preset "${preset.name}" aplicado`);
  };

  const handleUploadAndTrain = async () => {
    if (!selectedFile || !fileContent) {
      toast.error("Selecciona un archivo primero");
      return;
    }
    try {
      const base64Content = btoa(unescape(encodeURIComponent(fileContent)));
      const uploadResult = await uploadMutation.mutateAsync({
        filename: selectedFile.name,
        content: base64Content,
        fileType: selectedFile.type || "text/csv",
      });
      await createSessionMutation.mutateAsync({
        name: `Training — ${selectedFile.name}`,
        dataFileUrl: uploadResult.url,
        config,
      });
    } catch {
      // errors handled by mutation callbacks
    }
  };

  const isBusy =
    uploadMutation.isPending ||
    createSessionMutation.isPending ||
    startMutation.isPending ||
    pauseMutation.isPending ||
    resumeMutation.isPending ||
    stopMutation.isPending;

  const progressPct = currentSession
    ? Math.round(((currentSession.currentEpoch ?? 0) / (currentSession.totalEpochs ?? 1)) * 100)
    : 0;

  // ── Auth guard ────────────────────────────────────────────────────────────────
  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
        <Card className="w-96 bg-slate-900/50 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white">{t("training.auth.title")}</CardTitle>
            <CardDescription>{t("training.auth.desc")}</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
              <a href={getLoginUrl()}>{t("training.auth.button")}</a>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* ── Nav ─────────────────────────────────────────────────────────────── */}
      <nav className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
            TenMiNaTor
          </Link>
          <div className="flex items-center gap-3">
            <LanguageSelector />
            <span className="text-slate-400 hidden sm:inline text-sm">
              {t("nav.hello")}, {user?.name}
            </span>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold text-white">{t("training.title")}</h1>
          {/* Hardware info pill */}
          {hwInfo && (
            <div className="hidden md:flex items-center gap-2 text-xs text-slate-400 bg-slate-800/60 rounded-full px-3 py-1.5 border border-slate-700">
              <Cpu className="w-3 h-3" />
              <span>{hwInfo.gpu !== "No detectada" ? hwInfo.gpu : `CPU ${hwInfo.cpuCores} cores`}</span>
              {hwInfo.cudaVersion !== "N/A" && <Badge variant="outline" className="text-xs py-0 border-green-700 text-green-400">CUDA {hwInfo.cudaVersion}</Badge>}
              <span>{hwInfo.ramGb} GB RAM</span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* ── Left column ─────────────────────────────────────────────────── */}
          <div className="lg:col-span-2 space-y-6">

            {/* ── Presets ─────────────────────────────────────────────────── */}
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader className="pb-3">
                <CardTitle className="text-white flex items-center gap-2 text-base">
                  <Zap className="w-4 h-4 text-yellow-400" />
                  Presets de entrenamiento
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {presetsData?.presets.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => applyPreset(p.id)}
                      className={`text-left p-3 rounded-lg border text-xs transition-all ${
                        selectedPreset === p.id
                          ? "border-blue-500 bg-blue-900/30 text-white"
                          : "border-slate-700 bg-slate-800/40 text-slate-300 hover:border-slate-500 hover:bg-slate-800"
                      }`}
                    >
                      <div className="font-semibold mb-0.5">{p.name}</div>
                      <div className="text-slate-500 leading-tight">{p.description}</div>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* ── Upload ──────────────────────────────────────────────────── */}
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Upload className="w-5 h-5" />
                  {t("training.upload.title")}
                </CardTitle>
                <CardDescription>{t("training.upload.desc")}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="file" className="text-slate-300">
                    {t("training.upload.label")}
                  </Label>
                  <Input
                    id="file"
                    type="file"
                    accept=".csv,.txt,.json,.jsonl"
                    ref={fileInputRef}
                    onChange={handleFileSelect}
                    className="bg-slate-800 border-slate-700 text-white mt-1"
                  />
                  {selectedFile && (
                    <p className="text-xs text-slate-500 mt-1">
                      {selectedFile.name} — {(selectedFile.size / 1024).toFixed(1)} KB
                    </p>
                  )}
                </div>
                <Button
                  onClick={handleUploadAndTrain}
                  disabled={!selectedFile || isBusy}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  {uploadMutation.isPending || createSessionMutation.isPending ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" />{t("training.upload.processing")}</>
                  ) : (
                    <><Upload className="w-4 h-4 mr-2" />{t("training.upload.button")}</>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* ── Config ──────────────────────────────────────────────────── */}
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader className="pb-3">
                <button
                  className="flex items-center justify-between w-full text-left"
                  onClick={() => setShowAdvanced((v) => !v)}
                >
                  <CardTitle className="text-white flex items-center gap-2 text-base">
                    <Settings2 className="w-4 h-4" />
                    Configuración del modelo
                  </CardTitle>
                  {showAdvanced ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                </button>
              </CardHeader>
              {showAdvanced && (
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    {/* Architecture */}
                    <div>
                      <Label className="text-slate-300 text-xs">Arquitectura</Label>
                      <Select value={config.architecture} onValueChange={(v) => setConfig({ ...config, architecture: v as typeof config.architecture })}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {["mlp", "cnn", "rnn", "lstm", "transformer", "custom"].map((a) => (
                            <SelectItem key={a} value={a}>{a.toUpperCase()}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    {/* Optimizer */}
                    <div>
                      <Label className="text-slate-300 text-xs">Optimizador</Label>
                      <Select value={config.optimizer} onValueChange={(v) => setConfig({ ...config, optimizer: v as typeof config.optimizer })}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {["adam", "adamw", "sgd", "rmsprop", "adagrad"].map((o) => (
                            <SelectItem key={o} value={o}>{o.toUpperCase()}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    {/* Epochs */}
                    <div>
                      <Label className="text-slate-300 text-xs">Épocas</Label>
                      <Input type="number" min={1} max={10000} value={config.epochs}
                        onChange={(e) => setConfig({ ...config, epochs: parseInt(e.target.value) || 10 })}
                        className="bg-slate-800 border-slate-700 text-white mt-1" />
                    </div>
                    {/* Learning rate */}
                    <div>
                      <Label className="text-slate-300 text-xs">Learning Rate</Label>
                      <Input type="number" step="0.0001" min={0.00001} max={10} value={config.learningRate}
                        onChange={(e) => setConfig({ ...config, learningRate: parseFloat(e.target.value) || 0.01 })}
                        className="bg-slate-800 border-slate-700 text-white mt-1" />
                    </div>
                    {/* Batch size */}
                    <div>
                      <Label className="text-slate-300 text-xs">Batch Size</Label>
                      <Input type="number" min={1} max={8192} value={config.batchSize}
                        onChange={(e) => setConfig({ ...config, batchSize: parseInt(e.target.value) || 32 })}
                        className="bg-slate-800 border-slate-700 text-white mt-1" />
                    </div>
                    {/* Hidden size */}
                    <div>
                      <Label className="text-slate-300 text-xs">Hidden Size</Label>
                      <Input type="number" min={1} max={4096} value={config.hiddenSize}
                        onChange={(e) => setConfig({ ...config, hiddenSize: parseInt(e.target.value) || 64 })}
                        className="bg-slate-800 border-slate-700 text-white mt-1" />
                    </div>
                    {/* Device */}
                    <div>
                      <Label className="text-slate-300 text-xs">Dispositivo</Label>
                      <Select value={config.device} onValueChange={(v) => setConfig({ ...config, device: v as typeof config.device })}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {["auto", "cpu", "cuda", "rocm", "mps"].map((d) => (
                            <SelectItem key={d} value={d}>{d.toUpperCase()}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    {/* Precision */}
                    <div>
                      <Label className="text-slate-300 text-xs">Precisión</Label>
                      <Select value={config.precision} onValueChange={(v) => setConfig({ ...config, precision: v as typeof config.precision })}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {["fp32", "fp16", "bf16", "int8"].map((p) => (
                            <SelectItem key={p} value={p}>{p.toUpperCase()}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    {/* Scheduler */}
                    <div>
                      <Label className="text-slate-300 text-xs">Scheduler LR</Label>
                      <Select value={config.scheduler} onValueChange={(v) => setConfig({ ...config, scheduler: v as typeof config.scheduler })}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {["none", "cosine", "linear", "step", "plateau"].map((s) => (
                            <SelectItem key={s} value={s}>{s}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    {/* Output format */}
                    <div>
                      <Label className="text-slate-300 text-xs">Formato de salida</Label>
                      <Select value={config.outputFormat} onValueChange={(v) => setConfig({ ...config, outputFormat: v as typeof config.outputFormat })}>
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {["safetensors", "pytorch", "onnx", "gguf"].map((f) => (
                            <SelectItem key={f} value={f}>{f}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Separator className="bg-slate-800" />

                  {/* Quantization */}
                  <div className="space-y-2">
                    <Label className="text-slate-300 text-xs flex items-center gap-2">
                      Cuantización post-entrenamiento
                      <Badge variant="outline" className="text-xs py-0 border-purple-700 text-purple-400">Beta</Badge>
                    </Label>
                    <Select
                      value={config.quantizeFormat}
                      onValueChange={(v) => setConfig({
                        ...config,
                        quantizeFormat: v as typeof config.quantizeFormat,
                        quantize: v !== "none",
                      })}
                    >
                      <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">Sin cuantización</SelectItem>
                        <SelectItem value="gguf_q4">GGUF Q4_K_M ⭐ (recomendado)</SelectItem>
                        <SelectItem value="gguf_q5">GGUF Q5_K_M (alta calidad)</SelectItem>
                        <SelectItem value="gguf_q8">GGUF Q8_0 (máxima calidad)</SelectItem>
                        <SelectItem value="gptq">GPTQ (GPU)</SelectItem>
                        <SelectItem value="awq">AWQ (GPU)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              )}
            </Card>

            {/* ── Training control ─────────────────────────────────────────── */}
            {currentSession && (
              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <BarChart3 className="w-5 h-5" />
                    {t("training.control.title")}
                  </CardTitle>
                  <CardDescription className="flex items-center gap-2">
                    {currentSession.name}
                    <StatusBadge status={currentSession.status} />
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Controls */}
                  <div className="flex flex-wrap gap-2">
                    <Button
                      onClick={() => startMutation.mutate({ sessionId: currentSession.id })}
                      disabled={currentSession.status === "running" || currentSession.status === "completed" || isBusy}
                      className="bg-green-600 hover:bg-green-700"
                      size="sm"
                    >
                      <Play className="w-4 h-4 mr-1" />
                      {t("training.control.start")}
                    </Button>
                    <Button
                      onClick={() => pauseMutation.mutate({ sessionId: currentSession.id })}
                      disabled={currentSession.status !== "running" || isBusy}
                      className="bg-yellow-600 hover:bg-yellow-700"
                      size="sm"
                    >
                      <Pause className="w-4 h-4 mr-1" />
                      {t("training.control.pause")}
                    </Button>
                    <Button
                      onClick={() => resumeMutation.mutate({ sessionId: currentSession.id })}
                      disabled={currentSession.status !== "paused" || isBusy}
                      className="bg-blue-600 hover:bg-blue-700"
                      size="sm"
                    >
                      <Play className="w-4 h-4 mr-1" />
                      {t("training.control.resume")}
                    </Button>
                    <Button
                      onClick={() => stopMutation.mutate({ sessionId: currentSession.id })}
                      disabled={isBusy}
                      variant="destructive"
                      size="sm"
                    >
                      <Square className="w-4 h-4 mr-1" />
                      {t("training.control.stop")}
                    </Button>
                  </div>

                  <Separator className="bg-slate-800" />

                  {/* Progress bar */}
                  <div>
                    <div className="flex justify-between text-xs text-slate-400 mb-1">
                      <span>Progreso</span>
                      <span>{progressPct}%</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-2">
                      <div
                        className="bg-blue-500 h-2 rounded-full transition-all duration-500"
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>
                  </div>

                  {/* Metrics */}
                  <div className="grid grid-cols-3 gap-3">
                    <div className="bg-slate-800/60 rounded-lg p-3 text-center">
                      <div className="text-xs text-slate-400 mb-1">Época</div>
                      <div className="text-white font-mono font-bold">
                        {currentSession.currentEpoch ?? 0} / {currentSession.totalEpochs}
                      </div>
                    </div>
                    <div className="bg-slate-800/60 rounded-lg p-3 text-center">
                      <div className="text-xs text-slate-400 mb-1">Loss</div>
                      <div className="text-white font-mono font-bold">
                        {currentSession.currentLoss?.toFixed(6) ?? "—"}
                      </div>
                    </div>
                    <div className="bg-slate-800/60 rounded-lg p-3 text-center">
                      <div className="text-xs text-slate-400 mb-1">Estado</div>
                      <div className="text-white font-mono font-bold capitalize">
                        {currentSession.status}
                      </div>
                    </div>
                  </div>

                  {/* Loss chart */}
                  {lossHistory.length > 1 && (
                    <div className="border border-slate-800 rounded-lg p-3 bg-slate-950/50">
                      <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
                        <TrendingDown className="w-3 h-3" />
                        Curva de pérdida ({lossHistory.length} puntos)
                      </div>
                      <LossChart losses={lossHistory} />
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* ── Session history ──────────────────────────────────────────── */}
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  {t("training.history.title")}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {sessions && sessions.length > 0 ? (
                    sessions.map((session) => (
                      <div
                        key={session.id}
                        className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                          currentSessionId === session.id
                            ? "bg-blue-900/30 border-blue-500/50"
                            : "bg-slate-800/50 border-slate-700 hover:bg-slate-800"
                        }`}
                        onClick={() => setCurrentSessionId(session.id)}
                      >
                        <div className="flex justify-between items-center">
                          <div>
                            <span className="text-white font-medium text-sm">{session.name}</span>
                            <div className="text-xs text-slate-500 mt-0.5">
                              Época {session.currentEpoch ?? 0}/{session.totalEpochs}
                              {session.currentLoss != null && ` · Loss: ${(session.currentLoss as number).toFixed(4)}`}
                            </div>
                          </div>
                          <StatusBadge status={session.status} />
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-slate-500 text-sm text-center py-4">
                      No hay sesiones aún. Sube un archivo para comenzar.
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* ── Right column ─────────────────────────────────────────────────── */}
          <div className="space-y-6">
            {/* Hardware info */}
            {hwInfo && (
              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-white flex items-center gap-2 text-sm">
                    <Cpu className="w-4 h-4" />
                    Hardware detectado
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-400">GPU</span>
                    <span className="text-white text-right max-w-[60%] truncate">{hwInfo.gpu}</span>
                  </div>
                  {hwInfo.cudaVersion !== "N/A" && (
                    <div className="flex justify-between">
                      <span className="text-slate-400">CUDA</span>
                      <span className="text-green-400">{hwInfo.cudaVersion}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-slate-400">CPU cores</span>
                    <span className="text-white">{hwInfo.cpuCores}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">RAM</span>
                    <span className="text-white">{hwInfo.ramGb} GB</span>
                  </div>
                  <Separator className="bg-slate-800" />
                  <div className="flex justify-between">
                    <span className="text-slate-400">Dispositivo rec.</span>
                    <Badge variant="outline" className="text-xs py-0 border-blue-700 text-blue-400">
                      {hwInfo.recommendedDevice.toUpperCase()}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Precisión rec.</span>
                    <Badge variant="outline" className="text-xs py-0 border-purple-700 text-purple-400">
                      {hwInfo.recommendedPrecision.toUpperCase()}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* File preview */}
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader className="pb-3">
                <CardTitle className="text-white flex items-center gap-2 text-sm">
                  <Code2 className="w-4 h-4" />
                  {t("training.preview.title")}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {fileContent ? (
                  <pre className="bg-slate-950 p-3 rounded-lg text-xs text-slate-300 overflow-auto max-h-64 border border-slate-800">
                    {fileContent.slice(0, 800)}
                    {fileContent.length > 800 && "\n..."}
                  </pre>
                ) : (
                  <p className="text-slate-500 text-xs">{t("training.preview.empty")}</p>
                )}
              </CardContent>
            </Card>

            {/* Code snippet */}
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader className="pb-3">
                <CardTitle className="text-white text-sm">{t("training.code.title")}</CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="bg-slate-950 p-3 rounded-lg text-xs text-slate-300 overflow-auto border border-slate-800">
{`from tenminator import TenMiNaTor

model = TenMiNaTor(
  arch="${config.architecture}",
  hidden=${config.hiddenSize},
  layers=${config.numLayers},
)

model.train(
  data="data.csv",
  epochs=${config.epochs},
  lr=${config.learningRate},
  optimizer="${config.optimizer}",
  device="${config.device}",
  precision="${config.precision}",
)`}
                </pre>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
