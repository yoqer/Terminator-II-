import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, FileText, Package, Cpu, Shield, Mic, Usb, BookOpen, ArrowLeft, ExternalLink, Layers, Brain } from "lucide-react";
import { Link } from "wouter";

const DOWNLOAD_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310419663029047271/VoTpvbfnhhupz4uTh2MfaE/tenIII_v3.1.3_2633a116.zip";
const MANUAL_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310419663029047271/VoTpvbfnhhupz4uTh2MfaE/MANUAL_GENERAL_tenIII_0623f08f.md";
const TERMINATODO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310419663029047271/VoTpvbfnhhupz4uTh2MfaE/TerminaTodo_v1.0.0_8e7d9594.zip";
const TERMINATOR_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310419663029047271/VoTpvbfnhhupz4uTh2MfaE/Terminator_AliAmalia_v1.0.0_36f78664.zip";
const TORETE_WEB_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310419663029047271/VoTpvbfnhhupz4uTh2MfaE/index_f05f9347.html";

const docs = [
  {
    title: "Sistema 10x12",
    description: "Análisis completo del sistema de entrenamiento 10x12: cómo parte textos, cómo entrena y cómo monitorizarlo",
    icon: Layers,
    color: "text-blue-500",
    url: "https://d2xsxph8kpxj0f.cloudfront.net/310419663029047271/VoTpvbfnhhupz4uTh2MfaE/informe_10x12_tenminator_fe9e1493.pdf",
  },
  {
    title: "Block System",
    description: "Carga por bloques para dispositivos limitados: BlockSplitter, BlockLoader, LayerFreezer, BlockMerger",
    icon: Cpu,
    color: "text-purple-500",
    url: "https://d2xsxph8kpxj0f.cloudfront.net/310419663029047271/VoTpvbfnhhupz4uTh2MfaE/informe_tenminator_III_bloques_55b8a5c4.pdf",
  },
  {
    title: "USB Packaging",
    description: "Empaquetado portátil para pendrive: AnythingLLM, Ollama, GGUF, multiplataforma",
    icon: Usb,
    color: "text-green-500",
    url: "https://d2xsxph8kpxj0f.cloudfront.net/310419663029047271/VoTpvbfnhhupz4uTh2MfaE/informe_tenminator_III_usb_821a8143.pdf",
  },
  {
    title: "Multiplataforma (III-II)",
    description: "Soporte x32, ARM, RISC-V, cuántico, TPU, NPU, Unikernels y tecnologías emergentes",
    icon: Package,
    color: "text-yellow-500",
    url: "https://d2xsxph8kpxj0f.cloudfront.net/310419663029047271/VoTpvbfnhhupz4uTh2MfaE/informe_tenminator_III_II_multiplataforma_686101ee.pdf",
  },
  {
    title: "Razonamiento Personalizado",
    description: "Think-Anywhere, personalidades de pensamiento, Constitutional AI con libre albedrío",
    icon: Brain,
    color: "text-pink-500",
    url: "https://d2xsxph8kpxj0f.cloudfront.net/310419663029047271/VoTpvbfnhhupz4uTh2MfaE/informe_tenminator_reasoning_personalizado_bfd26ff9.pdf",
  },
  {
    title: "Auditoría de Sistemas",
    description: "Comparativa con Claude, GPT-4, DeepSeek, Llama, Mistral, Qwen y Grok",
    icon: Shield,
    color: "text-red-500",
    url: "https://d2xsxph8kpxj0f.cloudfront.net/310419663029047271/VoTpvbfnhhupz4uTh2MfaE/auditoria_tenminator_III_sistemas_inteligentes_1ba1e755.pdf",
  },
  {
    title: "Multimodal (KAME)",
    description: "Entrenamiento con voz, generación distribuida de pensamiento, inferencia multimodal",
    icon: Mic,
    color: "text-cyan-500",
    url: "https://d2xsxph8kpxj0f.cloudfront.net/310419663029047271/VoTpvbfnhhupz4uTh2MfaE/informe_tenminator_III_kame_multimodal_490616c3.pdf",
  },
  {
    title: "Hoja de Ruta Integrada",
    description: "Plan maestro completo: arquitectura constitucional, control sin paradas, framework modular",
    icon: BookOpen,
    color: "text-orange-500",
    url: "https://d2xsxph8kpxj0f.cloudfront.net/310419663029047271/VoTpvbfnhhupz4uTh2MfaE/hoja_ruta_tenminator_III_integrada_7d6f8a97.pdf",
  },
];

export default function Downloads() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Nav */}
      <nav className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/" className="text-slate-400 hover:text-white transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              tenIII
            </div>
          </div>
          <div className="text-slate-400 text-sm">
            terminator.com.es
          </div>
        </div>
      </nav>

      {/* Hero Download */}
      <section className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-3xl mx-auto space-y-6">
              <h1 className="text-5xl font-bold text-white">
            Descargar{" "}
            <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              tenIII v3.1.3
            </span>
          </h1>
          <p className="text-xl text-slate-400">
            Framework avanzado de entrenamiento de modelos de Deep Learning.
            Ecosistema Gotham City.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
            <Button
              asChild
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-lg px-8"
            >
              <a href={DOWNLOAD_URL} download className="flex items-center gap-2">
                <Download className="w-5 h-5" />
                Descargar tenIII v3.1.3 (ZIP - 196KB)
              </a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="bg-transparent border-slate-700 text-white hover:bg-slate-800 text-lg px-8"
            >
              <a href={MANUAL_URL} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Manual General (Markdown)
              </a>
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-8">
            <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
              <div className="text-2xl font-bold text-white">v3.1.3</div>
              <div className="text-slate-400 text-sm">Versión actual</div>
            </div>
            <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
              <div className="text-2xl font-bold text-white">10 Formatos</div>
              <div className="text-slate-400 text-sm">Cuantización Q1-Q8 + NVFP4 + ANT4</div>
            </div>
            <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
              <div className="text-2xl font-bold text-white">8 Exportadores</div>
              <div className="text-slate-400 text-sm">GGUF / Chip / Unikernel / ONNX...</div>
            </div>
          </div>
        </div>
      </section>

      {/* Instalación */}
      <section className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto">
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
              <CardTitle className="text-white text-xl">Instalación</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
                <div className="text-slate-500 text-sm mb-1"># Desde PyPI</div>
                <code className="text-green-400">pip install tenIII</code>
              </div>
              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
                <div className="text-slate-500 text-sm mb-1"># Con PyTorch</div>
                <code className="text-green-400">pip install tenIII[torch]</code>
              </div>
              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
                <div className="text-slate-500 text-sm mb-1"># Con todas las funciones</div>
                <code className="text-green-400">pip install tenIII[all]</code>
              </div>
              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
                <div className="text-slate-500 text-sm mb-1"># Desde web (descarga directa)</div>
                <code className="text-green-400">wget https://terminator.com.es/downloads/tenIII-3.0.0.tar.gz</code>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Uso rápido */}
      <section className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto">
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
              <CardTitle className="text-white text-xl">Uso Rápido</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 overflow-x-auto">
                <pre className="text-sm text-slate-300">
{`from tenIII import Trainer, TrainingConfig, EarlyStoppingMode

# Configurar
config = TrainingConfig(
    model_type="transformer",
    hidden_dim=768,
    num_layers=12,
    max_epochs=100,
    early_stopping=EarlyStoppingConfig(
        mode=EarlyStoppingMode.CONTINUOUS,  # Nunca para
        on_trigger="adapt",
    ),
    hot_update=HotUpdateConfig(
        enabled=True,
        update_after_10x12=True,  # Framework externo actualiza
    ),
)

# Entrenar
trainer = Trainer(config)
model = trainer.build_model()
history = trainer.train(train_data, val_data)

# Guardar (estándar, GGUF, o USB)
trainer.save("model.pt")
trainer.save("./usb_output/", format="usb")`}
                </pre>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Documentación */}
      <section className="container mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Documentación Técnica</h2>
          <p className="text-slate-400">Informes completos de diseño e implementación</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-5xl mx-auto">
          {docs.map((doc) => (
            <a
              key={doc.title}
              href={doc.url}
              target="_blank"
              rel="noopener noreferrer"
              className="block"
            >
              <Card className="bg-slate-900/50 border-slate-800 hover:border-slate-600 transition-all hover:scale-[1.02] h-full">
                <CardHeader className="pb-2">
                  <div className="flex items-center gap-3">
                    <doc.icon className={`w-8 h-8 ${doc.color}`} />
                    <div>
                      <CardTitle className="text-white text-base">{doc.title}</CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-slate-400 text-sm">
                    {doc.description}
                  </CardDescription>
                  <div className="flex items-center gap-1 mt-3 text-blue-400 text-xs">
                    <FileText className="w-3 h-3" />
                    <span>Ver PDF</span>
                    <ExternalLink className="w-3 h-3 ml-1" />
                  </div>
                </CardContent>
              </Card>
            </a>
          ))}
        </div>
      </section>

      {/* Módulos */}
      <section className="container mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Módulos Optativos</h2>
          <p className="text-slate-400">Cada módulo es independiente y puede activarse por separado</p>
        </div>

        <div className="max-w-4xl mx-auto overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-700">
                <th className="text-left text-slate-300 py-3 px-4">Módulo</th>
                <th className="text-left text-slate-300 py-3 px-4">Instalación</th>
                <th className="text-left text-slate-300 py-3 px-4">Descripción</th>
              </tr>
            </thead>
            <tbody className="text-slate-400">
              <tr className="border-b border-slate-800">
                <td className="py-3 px-4 text-white font-medium">Core</td>
                <td className="py-3 px-4"><code className="text-green-400 text-xs">pip install tenIII</code></td>
                <td className="py-3 px-4">Entrenamiento, 10x12, control continuo, hot update</td>
              </tr>
              <tr className="border-b border-slate-800">
                <td className="py-3 px-4 text-white font-medium">Blocks</td>
                <td className="py-3 px-4"><code className="text-green-400 text-xs">pip install tenIII[blocks]</code></td>
                <td className="py-3 px-4">Carga por bloques, congelación, fusión, cuantización</td>
              </tr>
              <tr className="border-b border-slate-800">
                <td className="py-3 px-4 text-white font-medium">Constitution</td>
                <td className="py-3 px-4"><code className="text-green-400 text-xs">pip install tenIII[constitution]</code></td>
                <td className="py-3 px-4">Políticas, libre albedrío, auditoría, conflictos</td>
              </tr>
              <tr className="border-b border-slate-800">
                <td className="py-3 px-4 text-white font-medium">Multimodal</td>
                <td className="py-3 px-4"><code className="text-green-400 text-xs">pip install tenIII[multimodal]</code></td>
                <td className="py-3 px-4">Voz, KAME, pensamiento distribuido</td>
              </tr>
              <tr className="border-b border-slate-800">
                <td className="py-3 px-4 text-white font-medium">Packaging</td>
                <td className="py-3 px-4"><code className="text-green-400 text-xs">pip install tenIII[packaging]</code></td>
                <td className="py-3 px-4">USB, GGUF, AnythingLLM, IA-USB</td>
              </tr>
              <tr className="border-b border-slate-800">
                <td className="py-3 px-4 text-white font-medium">Todos</td>
                <td className="py-3 px-4"><code className="text-green-400 text-xs">pip install tenIII[all]</code></td>
                <td className="py-3 px-4">Todas las funcionalidades incluidas</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-900/50 backdrop-blur-sm mt-12">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-slate-400 text-sm">
              tenIII v3.1.3 — Ecosistema Gotham City — terminator.com.es
            </div>
            <div className="flex gap-6">
              <Link href="/" className="text-slate-400 hover:text-white transition-colors text-sm">
                Inicio
              </Link>
              <Link href="/training" className="text-slate-400 hover:text-white transition-colors text-sm">
                Entrenamiento
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
