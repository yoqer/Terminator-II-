/**
 * Terminator II — Videollamada WebRTC
 *
 * Usa Twilio Video JS SDK para conectar al usuario con el Terminator
 * en una sala de videollamada. El Terminator responde con video generado por IA.
 *
 * Flujo:
 * 1. Usuario pulsa "Iniciar videollamada"
 * 2. Se obtiene token de sala desde /api/trpc (terminator.getVideoToken)
 * 3. Se conecta a la sala Twilio Video
 * 4. El usuario habla → STT → LLM → TTS + VideoGen → respuesta multimedia
 * 5. El video generado se reproduce en el panel del Terminator
 */

import { useState, useRef, useEffect, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import {
  Video,
  VideoOff,
  Mic,
  MicOff,
  PhoneOff,
  ArrowLeft,
  Loader2,
  AlertCircle,
  Bot,
  Volume2,
} from "lucide-react";
import type { Room, LocalVideoTrack, LocalAudioTrack, RemoteParticipant, VideoTrack } from "twilio-video";

type CallState = "idle" | "connecting" | "connected" | "error" | "ended";

interface TerminatorMessage {
  role: "user" | "terminator";
  text: string;
  audioUrl?: string | null;
  videoUrl?: string | null;
  timestamp: number;
}

export default function TerminatorVideoCall() {
  const [callState, setCallState] = useState<CallState>("idle");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [messages, setMessages] = useState<TerminatorMessage[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [roomName] = useState(() => `terminator-${Date.now()}`);

  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const roomRef = useRef<Room | null>(null);
  const localTracksRef = useRef<(LocalVideoTrack | LocalAudioTrack)[]>([]);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const getVideoTokenMutation = trpc.terminator.getVideoToken.useMutation();
  const chatMutation = trpc.terminator.chat.useMutation();

  // ── Cleanup on unmount ────────────────────────────────────────────────────
  useEffect(() => {
    return () => {
      endCall();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Start call ────────────────────────────────────────────────────────────
  const startCall = useCallback(async () => {
    setCallState("connecting");
    setErrorMsg(null);

    try {
      // Get Twilio token
      const { token, roomName: room } = await getVideoTokenMutation.mutateAsync({
        roomName,
        identity: `user-${Date.now()}`,
      });

      // Dynamically import Twilio Video SDK
      const TwilioVideo = await import("twilio-video");

      // Get local tracks
      const localTracks = await TwilioVideo.createLocalTracks({
        audio: true,
        video: { width: 640, height: 480, facingMode: "user" },
      });

      localTracksRef.current = localTracks as (LocalVideoTrack | LocalAudioTrack)[];

      // Attach local video
      const localVideoTrack = localTracks.find(
        (t) => t.kind === "video"
      ) as LocalVideoTrack | undefined;
      if (localVideoTrack && localVideoRef.current) {
        localVideoTrack.attach(localVideoRef.current);
      }

      // Connect to room
      const twilioRoom = await TwilioVideo.connect(token, {
        name: room,
        tracks: localTracks,
        audio: true,
        video: { width: 640, height: 480 },
      });

      roomRef.current = twilioRoom;
      setCallState("connected");

      // Handle remote participants (Terminator bot track)
      twilioRoom.participants.forEach(handleRemoteParticipant);
      twilioRoom.on("participantConnected", handleRemoteParticipant);

      twilioRoom.on("disconnected", () => {
        setCallState("ended");
      });

      // Start voice capture loop
      startVoiceCapture();
    } catch (err) {
      const msg = (err as Error).message;
      setErrorMsg(
        msg.includes("Twilio no configurado")
          ? "Configura tus credenciales de Twilio en /terminator/config para usar videollamadas."
          : `Error al conectar: ${msg}`
      );
      setCallState("error");
    }
  }, [roomName, getVideoTokenMutation]);

  // ── Handle remote participant (Terminator bot) ────────────────────────────
  const handleRemoteParticipant = useCallback((participant: RemoteParticipant) => {
    participant.tracks.forEach((publication) => {
      if (publication.isSubscribed && publication.track) {
        if (publication.track.kind === "video" && remoteVideoRef.current) {
          (publication.track as unknown as VideoTrack).attach(remoteVideoRef.current);
        }
      }
    });

    participant.on("trackSubscribed", (track) => {
      if (track.kind === "video" && remoteVideoRef.current) {
        (track as unknown as VideoTrack).attach(remoteVideoRef.current);
      }
    });
  }, []);

  // ── Voice capture: record 5s chunks and send to Terminator ───────────────
  const startVoiceCapture = useCallback(() => {
    navigator.mediaDevices.getUserMedia({ audio: true }).then((stream) => {
      const recorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      recorder.onstop = async () => {
        if (audioChunksRef.current.length === 0) return;
        const blob = new Blob(audioChunksRef.current, { type: "audio/webm" });
        audioChunksRef.current = [];

        // Only process if blob has meaningful content (>1KB)
        if (blob.size < 1024) return;

        await sendAudioToTerminator(blob);

        // Restart recording if still connected
        if (roomRef.current && callState === "connected") {
          recorder.start();
          setTimeout(() => recorder.stop(), 5000);
        }
      };

      recorder.start();
      setTimeout(() => recorder.stop(), 5000);
    });
  }, [callState]);

  // ── Send audio blob to Terminator via chat mutation ───────────────────────
  const sendAudioToTerminator = async (audioBlob: Blob) => {
    if (isProcessing) return;
    setIsProcessing(true);

    try {
      // Upload audio to server to get a real URL (avoids data: URL validation issues)
      const formData = new FormData();
      formData.append("audio", audioBlob, "voice.webm");
      let audioUrl: string | undefined;
      try {
        const uploadRes = await fetch("/api/terminator/upload-audio", {
          method: "POST",
          body: formData,
        });
        if (uploadRes.ok) {
          const json = await uploadRes.json() as { url?: string };
          audioUrl = json.url;
        }
      } catch {
        // If upload fails, proceed with text-only (no STT)
        console.warn("[VideoCall] Audio upload failed, proceeding without STT");
      }

      const result = await chatMutation.mutateAsync({
        audioUrl,
        withAudio: true,
        withVideo: true,
        language: "es",
        personaId: "default",
      });

      if (result.text) {
        const msg: TerminatorMessage = {
          role: "terminator",
          text: result.text,
          audioUrl: result.audioUrl,
          videoUrl: result.videoUrl,
          timestamp: Date.now(),
        };
        setMessages((prev) => [...prev, msg]);

        // Play audio response
        if (result.audioUrl) {
          const audio = new Audio(result.audioUrl);
          audio.play().catch(console.warn);
        }

        // Show video response in remote panel
        if (result.videoUrl && remoteVideoRef.current) {
          const videoEl = remoteVideoRef.current;
          videoEl.src = result.videoUrl;
          videoEl.play().catch(console.warn);
        }
      }
    } catch (err) {
      console.warn("[VideoCall] Error processing audio:", (err as Error).message);
    } finally {
      setIsProcessing(false);
    }
  };

  // ── End call ──────────────────────────────────────────────────────────────
  const endCall = useCallback(() => {
    mediaRecorderRef.current?.stop();
    localTracksRef.current.forEach((track) => track.stop());
    roomRef.current?.disconnect();
    roomRef.current = null;
    setCallState("ended");
  }, []);

  // ── Toggle mute ───────────────────────────────────────────────────────────
  const toggleMute = useCallback(() => {
    const audioTrack = localTracksRef.current.find(
      (t) => t.kind === "audio"
    ) as LocalAudioTrack | undefined;
    if (!audioTrack) return;
    if (isMuted) {
      audioTrack.enable();
    } else {
      audioTrack.disable();
    }
    setIsMuted(!isMuted);
  }, [isMuted]);

  // ── Toggle video ──────────────────────────────────────────────────────────
  const toggleVideo = useCallback(() => {
    const videoTrack = localTracksRef.current.find(
      (t) => t.kind === "video"
    ) as LocalVideoTrack | undefined;
    if (!videoTrack) return;
    if (isVideoOff) {
      videoTrack.enable();
    } else {
      videoTrack.disable();
    }
    setIsVideoOff(!isVideoOff);
  }, [isVideoOff]);

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col">
      {/* Header */}
      <div className="border-b border-slate-800 bg-slate-900/80 backdrop-blur px-4 py-3 flex items-center gap-3">
        <Link href="/terminator">
          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Volver al chat
          </Button>
        </Link>
        <div className="flex items-center gap-2">
          <Bot className="w-5 h-5 text-orange-400" />
          <span className="font-semibold">Videollamada con Terminator II</span>
        </div>
        {callState === "connected" && (
          <Badge className="ml-auto bg-green-600 text-white animate-pulse">
            En llamada
          </Badge>
        )}
        {callState === "connecting" && (
          <Badge className="ml-auto bg-yellow-600 text-white">
            Conectando...
          </Badge>
        )}
      </div>

      {/* Main video area */}
      <div className="flex-1 flex flex-col lg:flex-row gap-4 p-4">
        {/* Video panels */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Remote: Terminator */}
          <div className="relative bg-slate-900 rounded-xl overflow-hidden aspect-video flex items-center justify-center border border-slate-700">
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
            {callState !== "connected" && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-red-600 to-orange-500 flex items-center justify-center text-4xl">
                  🤖
                </div>
                <span className="text-slate-400 text-sm">Terminator II</span>
              </div>
            )}
            {isProcessing && (
              <div className="absolute bottom-3 left-3 flex items-center gap-2 bg-black/60 rounded-full px-3 py-1 text-xs">
                <Loader2 className="w-3 h-3 animate-spin text-orange-400" />
                Procesando respuesta...
              </div>
            )}
            <div className="absolute top-3 left-3 bg-black/60 rounded px-2 py-1 text-xs text-slate-300">
              Terminator II
            </div>
          </div>

          {/* Local: User */}
          <div className="relative bg-slate-900 rounded-xl overflow-hidden aspect-video flex items-center justify-center border border-slate-700">
            <video
              ref={localVideoRef}
              autoPlay
              playsInline
              muted
              className={`w-full h-full object-cover ${isVideoOff ? "opacity-0" : ""}`}
            />
            {isVideoOff && (
              <div className="absolute inset-0 flex items-center justify-center">
                <VideoOff className="w-12 h-12 text-slate-600" />
              </div>
            )}
            <div className="absolute top-3 left-3 bg-black/60 rounded px-2 py-1 text-xs text-slate-300">
              Tú
            </div>
            {isMuted && (
              <div className="absolute top-3 right-3 bg-red-600/80 rounded-full p-1">
                <MicOff className="w-3 h-3" />
              </div>
            )}
          </div>
        </div>

        {/* Transcript panel */}
        <div className="lg:w-80 bg-slate-900 rounded-xl border border-slate-700 flex flex-col">
          <div className="px-4 py-3 border-b border-slate-700 flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-slate-400" />
            <span className="text-sm font-medium text-slate-300">Transcripción</span>
          </div>
          <div className="flex-1 overflow-y-auto p-3 space-y-3 max-h-80 lg:max-h-none">
            {messages.length === 0 ? (
              <p className="text-slate-500 text-sm text-center mt-8">
                {callState === "connected"
                  ? "Habla para que el Terminator te responda..."
                  : "Inicia la videollamada para comenzar"}
              </p>
            ) : (
              messages.map((msg, i) => (
                <div
                  key={i}
                  className={`rounded-lg p-3 text-sm ${
                    msg.role === "user"
                      ? "bg-blue-900/40 text-blue-100 ml-4"
                      : "bg-orange-900/30 text-orange-100 mr-4"
                  }`}
                >
                  <div className="font-medium text-xs mb-1 opacity-70">
                    {msg.role === "user" ? "Tú" : "🤖 Terminator"}
                  </div>
                  <p>{msg.text}</p>
                  {msg.audioUrl && (
                    <audio controls src={msg.audioUrl} className="mt-2 w-full h-8" />
                  )}
                  {msg.videoUrl && (
                    <video
                      controls
                      src={msg.videoUrl}
                      className="mt-2 w-full rounded"
                    />
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Error message */}
      {callState === "error" && errorMsg && (
        <div className="mx-4 mb-4 bg-red-900/40 border border-red-700 rounded-lg p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-red-300 text-sm">{errorMsg}</p>
            {errorMsg.includes("Twilio") && (
              <Link href="/terminator/config">
                <Button size="sm" variant="outline" className="mt-2 text-xs border-red-600 text-red-300">
                  Ir a Configuración
                </Button>
              </Link>
            )}
          </div>
        </div>
      )}

      {/* Call ended */}
      {callState === "ended" && (
        <div className="mx-4 mb-4 bg-slate-800 border border-slate-600 rounded-lg p-4 text-center">
          <p className="text-slate-300 text-sm mb-3">Videollamada finalizada</p>
          <Button
            onClick={() => {
              setCallState("idle");
              setMessages([]);
            }}
            className="bg-orange-600 hover:bg-orange-700"
          >
            Nueva llamada
          </Button>
        </div>
      )}

      {/* Controls bar */}
      <div className="border-t border-slate-800 bg-slate-900/80 backdrop-blur px-4 py-4 flex items-center justify-center gap-4">
        {(callState === "idle" || callState === "error" || callState === "ended") ? (
          <Button
            onClick={startCall}
            disabled={false}
            className="bg-green-600 hover:bg-green-700 px-8 py-3 text-base"
          >
            <Video className="w-5 h-5 mr-2" />
            Iniciar videollamada
          </Button>
        ) : callState === "connecting" ? (
          <Button disabled className="bg-yellow-600 px-8 py-3 text-base">
            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
            Conectando...
          </Button>
        ) : (
          <>
            <Button
              onClick={toggleMute}
              variant="outline"
              size="lg"
              className={`rounded-full w-14 h-14 p-0 border-2 ${
                isMuted
                  ? "border-red-500 bg-red-900/30 text-red-400"
                  : "border-slate-600 text-slate-300 hover:border-slate-400"
              }`}
            >
              {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
            </Button>

            <Button
              onClick={toggleVideo}
              variant="outline"
              size="lg"
              className={`rounded-full w-14 h-14 p-0 border-2 ${
                isVideoOff
                  ? "border-red-500 bg-red-900/30 text-red-400"
                  : "border-slate-600 text-slate-300 hover:border-slate-400"
              }`}
            >
              {isVideoOff ? <VideoOff className="w-6 h-6" /> : <Video className="w-6 h-6" />}
            </Button>

            <Button
              onClick={endCall}
              size="lg"
              className="rounded-full w-16 h-16 p-0 bg-red-600 hover:bg-red-700 border-0"
            >
              <PhoneOff className="w-7 h-7" />
            </Button>
          </>
        )}
      </div>

      {/* Info footer */}
      <div className="px-4 py-2 bg-slate-950 text-center text-xs text-slate-600">
        Powered by Twilio Video + Kokoro TTS + tenIII · El Terminator captura tu voz cada 5 segundos y responde con audio y video generados por IA
      </div>
    </div>
  );
}
