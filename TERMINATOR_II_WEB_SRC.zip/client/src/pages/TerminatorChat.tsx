import { useState, useRef, useEffect, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { nanoid } from "nanoid";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Mic, MicOff, Send, Video, Volume2, Settings, Loader2, Bot, User } from "lucide-react";
import { Link } from "wouter";

// ─── Types ────────────────────────────────────────────────────────────────────

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  audioUrl?: string | null;
  videoUrl?: string | null;
  imageUrl?: string | null;
  videoPrompt?: string | null;
  audioPrompt?: string | null;
  backend?: { llm: string; tts: string | null; video: string | null };
  timestamp: Date;
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function TerminatorChat() {
  const [sessionId] = useState(() => `web:${nanoid()}`);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [persona, setPersona] = useState("default");
  const [language, setLanguage] = useState("es");
  const [llmBackend, setLlmBackend] = useState("auto");
  const [ttsBackend, setTtsBackend] = useState("auto");
  const [videoBackend, setVideoBackend] = useState("none");
  const [withVideo, setWithVideo] = useState(false);
  const [withAudio, setWithAudio] = useState(true);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const chatMutation = trpc.terminator.chat.useMutation();
  const backendsQuery = trpc.terminator.checkBackends.useQuery({
    ollamaUrl: "http://localhost:11434",
    lmstudioUrl: "http://localhost:1234",
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = useCallback(
    async (text?: string, audioUrl?: string) => {
      const msgText = text ?? input.trim();
      if (!msgText && !audioUrl) return;

      const userMsg: ChatMessage = {
        id: nanoid(),
        role: "user",
        text: msgText || "[mensaje de voz]",
        audioUrl,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, userMsg]);
      setInput("");
      setAudioBlob(null);

      try {
        const result = await chatMutation.mutateAsync({
          sessionId,
          text: msgText || undefined,
          audioUrl,
          personaId: persona,
          language,
          withVideo,
          withAudio,
          llmBackend,
          ttsBackend,
          videoBackend,
        });

        const assistantMsg: ChatMessage = {
          id: nanoid(),
          role: "assistant",
          text: result.text,
          audioUrl: result.audioUrl,
          videoUrl: result.videoUrl,
          videoPrompt: result.videoPrompt,
          audioPrompt: result.audioPrompt,
          backend: result.backend,
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, assistantMsg]);
      } catch (err) {
        console.error("Chat error:", err);
        setMessages((prev) => [
          ...prev,
          {
            id: nanoid(),
            role: "assistant",
            text: "Error al procesar el mensaje. Verifica la configuración del servidor.",
            timestamp: new Date(),
          },
        ]);
      }
    },
    [input, sessionId, persona, language, withVideo, withAudio, llmBackend, ttsBackend, videoBackend, chatMutation]
  );

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      mediaRecorderRef.current = mr;
      chunksRef.current = [];
      mr.ondataavailable = (e) => chunksRef.current.push(e.data);
      mr.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        setAudioBlob(blob);
        stream.getTracks().forEach((t) => t.stop());
      };
      mr.start();
      setIsRecording(true);
    } catch {
      alert("No se pudo acceder al micrófono");
    }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setIsRecording(false);
  };

  const sendAudio = async () => {
    if (!audioBlob) return;
    // Upload audio to get URL, then send
    const formData = new FormData();
    formData.append("file", audioBlob, "recording.webm");
    try {
      const res = await fetch("/api/upload-audio", { method: "POST", body: formData });
      const { url } = (await res.json()) as { url: string };
      await sendMessage(undefined, url);
    } catch {
      // Fallback: send as base64 text description
      await sendMessage("[mensaje de voz - sin servidor de subida configurado]");
    }
  };

  const backends = backendsQuery.data;

  return (
    <div className="flex flex-col h-screen bg-gray-950 text-gray-100">
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-3 border-b border-gray-800 bg-gray-900">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-red-600 to-orange-500 flex items-center justify-center text-white font-bold text-sm">
            T1
          </div>
          <div>
            <h1 className="font-semibold text-white text-sm">Terminator II</h1>
            <p className="text-xs text-gray-400">Sistema multimodal de IA</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {backends && (
            <div className="hidden md:flex gap-1">
              {backends.ollama && <Badge variant="outline" className="text-xs border-green-700 text-green-400">Ollama</Badge>}
              {backends.lmstudio && <Badge variant="outline" className="text-xs border-blue-700 text-blue-400">LM Studio</Badge>}
              {backends.grok && <Badge variant="outline" className="text-xs border-purple-700 text-purple-400">Grok</Badge>}
              {backends.openai && <Badge variant="outline" className="text-xs border-yellow-700 text-yellow-400">OpenAI</Badge>}
            </div>
          )}
          <Link href="/terminator/video-call">
            <Button variant="ghost" size="icon" className="text-gray-400 hover:text-orange-400" title="Videollamada WebRTC">
              <Video className="w-4 h-4" />
            </Button>
          </Link>
          <Link href="/terminator/config">
            <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
              <Settings className="w-4 h-4" />
            </Button>
          </Link>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar: Model selection */}
        <aside className="hidden lg:flex flex-col w-56 border-r border-gray-800 bg-gray-900 p-3 gap-3">
          <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Configuración</p>

          <div className="space-y-1">
            <label className="text-xs text-gray-400">Personaje</label>
            <Select value={persona} onValueChange={setPersona}>
              <SelectTrigger className="h-8 text-xs bg-gray-800 border-gray-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="default">Terminator</SelectItem>
                <SelectItem value="ani">Ani</SelectItem>
                <SelectItem value="valentin">Valentín</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1">
            <label className="text-xs text-gray-400">Idioma</label>
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger className="h-8 text-xs bg-gray-800 border-gray-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="es">Español</SelectItem>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="de">Deutsch</SelectItem>
                <SelectItem value="fr">Français</SelectItem>
                <SelectItem value="it">Italiano</SelectItem>
                <SelectItem value="pt">Português</SelectItem>
                <SelectItem value="zh">中文</SelectItem>
                <SelectItem value="ja">日本語</SelectItem>
                <SelectItem value="ko">한국어</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1">
            <label className="text-xs text-gray-400">Modelo LLM</label>
            <Select value={llmBackend} onValueChange={setLlmBackend}>
              <SelectTrigger className="h-8 text-xs bg-gray-800 border-gray-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="auto">Auto (local → nube)</SelectItem>
                <SelectItem value="ollama">Ollama (local)</SelectItem>
                <SelectItem value="lmstudio">LM Studio (local)</SelectItem>
                <SelectItem value="grok">Grok xAI</SelectItem>
                <SelectItem value="openai">OpenAI</SelectItem>
                <SelectItem value="kimi">Kimi (Moonshot)</SelectItem>
                <SelectItem value="deepseek">DeepSeek</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1">
            <label className="text-xs text-gray-400">Voz (TTS)</label>
            <Select value={ttsBackend} onValueChange={setTtsBackend}>
              <SelectTrigger className="h-8 text-xs bg-gray-800 border-gray-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="auto">Auto</SelectItem>
                <SelectItem value="grok">Grok Aurora</SelectItem>
                <SelectItem value="openai">OpenAI TTS</SelectItem>
                <SelectItem value="piper">Piper (local)</SelectItem>
                <SelectItem value="none">Sin voz</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1">
            <label className="text-xs text-gray-400">Video</label>
            <Select value={videoBackend} onValueChange={(v) => { setVideoBackend(v); setWithVideo(v !== "none"); }}>
              <SelectTrigger className="h-8 text-xs bg-gray-800 border-gray-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Sin video</SelectItem>
                <SelectItem value="grok">Grok Video</SelectItem>
                <SelectItem value="wan2">Wan2.1 (local)</SelectItem>
                <SelectItem value="ltx">LTX-Video (local)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between mt-1">
            <label className="text-xs text-gray-400">Respuesta en audio</label>
            <button
              onClick={() => setWithAudio(!withAudio)}
              className={`w-9 h-5 rounded-full transition-colors ${withAudio ? "bg-red-600" : "bg-gray-700"} relative`}
            >
              <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${withAudio ? "translate-x-4" : "translate-x-0.5"}`} />
            </button>
          </div>
        </aside>

        {/* Chat area */}
        <main className="flex flex-col flex-1 overflow-hidden">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-full text-center gap-4 opacity-60">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-red-600 to-orange-500 flex items-center justify-center text-3xl">
                  🤖
                </div>
                <div>
                  <p className="text-lg font-semibold text-gray-300">Terminator II</p>
                  <p className="text-sm text-gray-500 mt-1">Sistema multimodal: texto, voz, imagen y video</p>
                  <p className="text-xs text-gray-600 mt-2">Escribe un mensaje o graba tu voz para comenzar</p>
                </div>
              </div>
            )}

            {messages.map((msg) => (
              <div key={msg.id} className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                {msg.role === "assistant" && (
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-red-600 to-orange-500 flex items-center justify-center flex-shrink-0 mt-1">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                )}
                <div className={`max-w-[75%] space-y-2 ${msg.role === "user" ? "items-end" : "items-start"} flex flex-col`}>
                  <div className={`rounded-2xl px-4 py-2.5 text-sm ${
                    msg.role === "user"
                      ? "bg-red-700 text-white rounded-tr-sm"
                      : "bg-gray-800 text-gray-100 rounded-tl-sm"
                  }`}>
                    {msg.text}
                  </div>

                  {/* Audio player */}
                  {msg.audioUrl && (
                    <div className="flex items-center gap-2 bg-gray-800 rounded-xl px-3 py-2">
                      <Volume2 className="w-4 h-4 text-red-400 flex-shrink-0" />
                      <audio controls className="h-8 max-w-[200px]" src={msg.audioUrl} />
                    </div>
                  )}

                  {/* Video player */}
                  {msg.videoUrl && (
                    <div className="rounded-xl overflow-hidden border border-gray-700 max-w-sm">
                      <video controls className="w-full" src={msg.videoUrl} />
                      {msg.videoPrompt && (
                        <p className="text-xs text-gray-500 px-2 py-1 bg-gray-900 truncate">{msg.videoPrompt}</p>
                      )}
                    </div>
                  )}

                  {/* Backend info */}
                  {msg.backend && (
                    <div className="flex gap-1 flex-wrap">
                      <Badge variant="outline" className="text-[10px] border-gray-700 text-gray-500 py-0">
                        {msg.backend.llm}
                      </Badge>
                      {msg.backend.tts && (
                        <Badge variant="outline" className="text-[10px] border-gray-700 text-gray-500 py-0">
                          {msg.backend.tts}
                        </Badge>
                      )}
                      {msg.backend.video && (
                        <Badge variant="outline" className="text-[10px] border-gray-700 text-gray-500 py-0">
                          {msg.backend.video}
                        </Badge>
                      )}
                    </div>
                  )}

                  <p className="text-[10px] text-gray-600">
                    {msg.timestamp.toLocaleTimeString()}
                  </p>
                </div>

                {msg.role === "user" && (
                  <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center flex-shrink-0 mt-1">
                    <User className="w-4 h-4 text-gray-300" />
                  </div>
                )}
              </div>
            ))}

            {chatMutation.isPending && (
              <div className="flex gap-3 justify-start">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-red-600 to-orange-500 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <div className="bg-gray-800 rounded-2xl rounded-tl-sm px-4 py-3 flex items-center gap-2">
                  <Loader2 className="w-4 h-4 text-red-400 animate-spin" />
                  <span className="text-sm text-gray-400">Procesando...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input area */}
          <div className="border-t border-gray-800 bg-gray-900 p-3">
            {/* Mobile model selectors */}
            <div className="lg:hidden flex gap-2 mb-2 overflow-x-auto pb-1">
              <Select value={persona} onValueChange={setPersona}>
                <SelectTrigger className="h-7 text-xs bg-gray-800 border-gray-700 min-w-[100px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="default">Terminator</SelectItem>
                  <SelectItem value="ani">Ani</SelectItem>
                  <SelectItem value="valentin">Valentín</SelectItem>
                </SelectContent>
              </Select>
              <Select value={llmBackend} onValueChange={setLlmBackend}>
                <SelectTrigger className="h-7 text-xs bg-gray-800 border-gray-700 min-w-[80px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="auto">Auto LLM</SelectItem>
                  <SelectItem value="ollama">Ollama</SelectItem>
                  <SelectItem value="lmstudio">LM Studio</SelectItem>
                  <SelectItem value="grok">Grok</SelectItem>
                  <SelectItem value="openai">OpenAI</SelectItem>
                </SelectContent>
              </Select>
              <Button
                variant="ghost"
                size="sm"
                className={`h-7 text-xs px-2 ${withVideo ? "text-red-400" : "text-gray-500"}`}
                onClick={() => setWithVideo(!withVideo)}
              >
                <Video className="w-3 h-3 mr-1" />
                Video
              </Button>
            </div>

            {/* Audio preview */}
            {audioBlob && (
              <div className="flex items-center gap-2 mb-2 bg-gray-800 rounded-lg px-3 py-2">
                <audio controls className="h-8 flex-1" src={URL.createObjectURL(audioBlob)} />
                <Button size="sm" onClick={sendAudio} className="bg-red-600 hover:bg-red-700 h-8">
                  <Send className="w-3 h-3" />
                </Button>
                <Button size="sm" variant="ghost" onClick={() => setAudioBlob(null)} className="h-8 text-gray-400">
                  ✕
                </Button>
              </div>
            )}

            <div className="flex gap-2 items-end">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Escribe un mensaje... (Enter para enviar)"
                className="flex-1 min-h-[44px] max-h-32 resize-none bg-gray-800 border-gray-700 text-gray-100 placeholder-gray-500 text-sm rounded-xl"
                rows={1}
              />
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className={`h-11 w-11 rounded-xl ${isRecording ? "bg-red-600 text-white animate-pulse" : "bg-gray-800 text-gray-400 hover:text-white"}`}
                      onClick={isRecording ? stopRecording : startRecording}
                    >
                      {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>{isRecording ? "Detener grabación" : "Grabar voz"}</TooltipContent>
                </Tooltip>
              </TooltipProvider>
              <Button
                onClick={() => sendMessage()}
                disabled={!input.trim() || chatMutation.isPending}
                className="h-11 w-11 rounded-xl bg-red-600 hover:bg-red-700 p-0"
              >
                {chatMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
