/**
 * Terminator II — Página de Configuración
 *
 * Gestión de APIs, canales y preferencias del sistema Terminator II.
 * Las claves API se almacenan en localStorage del navegador (sin login)
 * y opcionalmente en la BD del servidor (con login).
 */

import { useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ApiKeyManager } from "@/components/ApiKeyManager";
import { useApiKeys } from "@/hooks/useApiKeys";
import {
  ArrowLeft,
  Bot,
  Settings,
  Webhook,
  Sliders,
  CheckCircle2,
  XCircle,
  Loader2,
  Copy,
  ExternalLink,
  RefreshCw,
} from "lucide-react";
import { getLoginUrl } from "@/const";

// ─── Webhook URL helper ───────────────────────────────────────────────────────

function WebhookUrl({ path, label }: { path: string; label: string }) {
  const [copied, setCopied] = useState(false);
  const url = `${window.location.origin}${path}`;

  const copy = () => {
    navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="space-y-1">
      <label className="text-xs font-medium text-slate-400">{label}</label>
      <div className="flex items-center gap-2 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2">
        <code className="text-xs text-green-400 flex-1 truncate">{url}</code>
        <button
          onClick={copy}
          className="text-slate-500 hover:text-slate-300 flex-shrink-0"
          title="Copiar URL"
        >
          {copied ? (
            <CheckCircle2 className="w-4 h-4 text-green-400" />
          ) : (
            <Copy className="w-4 h-4" />
          )}
        </button>
      </div>
    </div>
  );
}

// ─── Tab: Preferencias ────────────────────────────────────────────────────────

function PreferencesTab() {
  const { user } = useAuth();
  const loginUrl = getLoginUrl();
  const [prefs, setPrefs] = useState({
    defaultPersona: "default",
    defaultLanguage: "es",
    defaultLlm: "auto",
    defaultTts: "auto",
    defaultVideo: "none",
  });
  const saveConfigMutation = trpc.terminator.saveConfig.useMutation();
  const [saved, setSaved] = useState(false);

  const handleSave = async () => {
    await saveConfigMutation.mutateAsync(prefs);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-4">
      <Card className="bg-slate-900/60 border-slate-700">
        <CardHeader>
          <CardTitle className="text-sm text-slate-200 flex items-center gap-2">
            <Bot className="w-4 h-4 text-orange-400" />
            Preferencias del sistema
          </CardTitle>
          <CardDescription className="text-xs text-slate-500">
            Configura el comportamiento por defecto del Terminator II
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-sm text-slate-300">Persona por defecto</label>
              <Select value={prefs.defaultPersona} onValueChange={(v) => setPrefs((p) => ({ ...p, defaultPersona: v }))}>
                <SelectTrigger className="bg-slate-900 border-slate-700 text-slate-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-700">
                  <SelectItem value="default">🤖 Terminator (neutro)</SelectItem>
                  <SelectItem value="ani">🌸 Ani (cálida, empática)</SelectItem>
                  <SelectItem value="valentin">💼 Valentín (profesional)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <label className="text-sm text-slate-300">Idioma por defecto</label>
              <Select value={prefs.defaultLanguage} onValueChange={(v) => setPrefs((p) => ({ ...p, defaultLanguage: v }))}>
                <SelectTrigger className="bg-slate-900 border-slate-700 text-slate-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-700">
                  <SelectItem value="es">🇪🇸 Español</SelectItem>
                  <SelectItem value="en">🇺🇸 English</SelectItem>
                  <SelectItem value="de">🇩🇪 Deutsch</SelectItem>
                  <SelectItem value="fr">🇫🇷 Français</SelectItem>
                  <SelectItem value="it">🇮🇹 Italiano</SelectItem>
                  <SelectItem value="pt">🇧🇷 Português</SelectItem>
                  <SelectItem value="ja">🇯🇵 日本語</SelectItem>
                  <SelectItem value="ko">🇰🇷 한국어</SelectItem>
                  <SelectItem value="zh">🇨🇳 中文</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <label className="text-sm text-slate-300">LLM preferido</label>
              <Select value={prefs.defaultLlm} onValueChange={(v) => setPrefs((p) => ({ ...p, defaultLlm: v }))}>
                <SelectTrigger className="bg-slate-900 border-slate-700 text-slate-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-700">
                  <SelectItem value="auto">🔄 Automático (mejor disponible)</SelectItem>
                  <SelectItem value="ollama">🖥️ Ollama (local)</SelectItem>
                  <SelectItem value="lmstudio">🖥️ LM Studio (local)</SelectItem>
                  <SelectItem value="grok">☁️ Grok xAI</SelectItem>
                  <SelectItem value="openai">☁️ OpenAI GPT-4o</SelectItem>
                  <SelectItem value="kimi">☁️ Kimi (Moonshot)</SelectItem>
                  <SelectItem value="deepseek">☁️ DeepSeek</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <label className="text-sm text-slate-300">TTS preferido</label>
              <Select value={prefs.defaultTts} onValueChange={(v) => setPrefs((p) => ({ ...p, defaultTts: v }))}>
                <SelectTrigger className="bg-slate-900 border-slate-700 text-slate-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-700">
                  <SelectItem value="auto">🔄 Automático (mejor disponible)</SelectItem>
                  <SelectItem value="kokoro">🎙️ Kokoro (local, 11 idiomas)</SelectItem>
                  <SelectItem value="piper">🎙️ Piper (local, 30+ idiomas)</SelectItem>
                  <SelectItem value="grok">☁️ Grok Aurora</SelectItem>
                  <SelectItem value="openai">☁️ OpenAI TTS</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <label className="text-sm text-slate-300">Generación de video</label>
              <Select value={prefs.defaultVideo} onValueChange={(v) => setPrefs((p) => ({ ...p, defaultVideo: v }))}>
                <SelectTrigger className="bg-slate-900 border-slate-700 text-slate-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-700">
                  <SelectItem value="none">❌ Desactivado</SelectItem>
                  <SelectItem value="grok">☁️ Grok Video (xAI)</SelectItem>
                  <SelectItem value="wan2">🖥️ Wan2.1 (local, 8GB VRAM)</SelectItem>
                  <SelectItem value="ltx">🖥️ LTX-Video (local, 4GB VRAM)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {user && (
            <Button
              onClick={handleSave}
              disabled={saveConfigMutation.isPending}
              className="bg-orange-600 hover:bg-orange-700 w-full sm:w-auto"
            >
              {saveConfigMutation.isPending ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Guardando...</>
              ) : saved ? (
                <><CheckCircle2 className="w-4 h-4 mr-2" /> Guardado</>
              ) : (
                <><Settings className="w-4 h-4 mr-2" /> Guardar preferencias</>
              )}
            </Button>
          )}
          {!user && (
            <p className="text-xs text-slate-500">Inicia sesión para guardar las preferencias en tu cuenta.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ─── Tab: Webhooks ────────────────────────────────────────────────────────────

function WebhooksTab() {
  return (
    <div className="space-y-4">
      <Card className="bg-slate-900/60 border-slate-700">
        <CardHeader>
          <CardTitle className="text-sm text-slate-200 flex items-center gap-2">
            <Webhook className="w-4 h-4 text-blue-400" />
            URLs de webhooks
          </CardTitle>
          <CardDescription className="text-xs text-slate-500">
            Configura estas URLs en cada plataforma para recibir mensajes en el Terminator II
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">WhatsApp Business</h3>
            <WebhookUrl path="/api/webhooks/whatsapp" label="Webhook URL (Meta Developers → Webhooks)" />
            <p className="text-xs text-slate-500">
              En Meta Developers → tu app → WhatsApp → Configuración → Webhook:
              pega la URL de arriba y el mismo Verify Token que configuraste en las claves API.
            </p>
          </div>

          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Telegram</h3>
            <WebhookUrl path="/api/webhooks/telegram" label="Webhook URL (setWebhook)" />
            <p className="text-xs text-slate-500">
              Ejecuta en tu navegador (sustituyendo TOKEN):
            </p>
            <code className="block mt-1 bg-slate-950 rounded p-2 text-green-400 text-xs break-all">
              {`https://api.telegram.org/bot<TOKEN>/setWebhook?url=${window.location.origin}/api/webhooks/telegram`}
            </code>
          </div>

          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Twilio SMS / MMS</h3>
            <WebhookUrl path="/api/webhooks/sms" label="Webhook URL (Twilio Console → Phone Numbers)" />
            <p className="text-xs text-slate-500">
              En Twilio Console → Phone Numbers → tu número → Messaging → Webhook:
              pega la URL y selecciona método HTTP POST.
            </p>
          </div>

          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Twilio Voice (ConversationRelay)</h3>
            <WebhookUrl path="/api/webhooks/voice" label="Webhook URL (Twilio Console → Voice)" />
            <p className="text-xs text-slate-500">
              En Twilio Console → Phone Numbers → tu número → Voice → Webhook:
              pega la URL. El sistema responderá con TwiML que conecta al WebSocket del Terminator.
            </p>
          </div>

          <div className="p-3 bg-blue-900/20 border border-blue-800 rounded-lg text-xs text-blue-300 flex items-start gap-2">
            <ExternalLink className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>
              <strong>Nota:</strong> Para que los webhooks funcionen, esta app debe estar publicada.
              Usa el botón <strong>Publish</strong> del panel de gestión.
              En desarrollo local, usa <a href="https://ngrok.com" target="_blank" rel="noreferrer" className="underline">ngrok</a> para exponer el puerto 3000.
            </span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ─── Componente principal ─────────────────────────────────────────────────────

export default function TerminatorConfig() {
  const { user } = useAuth();
  const loginUrl = getLoginUrl();
  const { keys } = useApiKeys();

  const backendsQuery = trpc.terminator.checkBackends.useQuery(
    {
      ollamaUrl: keys.ollamaUrl ?? "http://localhost:11434",
      lmstudioUrl: keys.lmstudioUrl ?? "http://localhost:1234",
      kokoroUrl: keys.kokoroUrl ?? "http://localhost:8880",
    },
    { retry: false, refetchInterval: 30_000 }
  );
  const backends = backendsQuery.data;

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Header */}
      <div className="border-b border-slate-800 bg-slate-900/80 backdrop-blur px-4 py-3 flex items-center gap-3">
        <Link href="/terminator">
          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Volver al chat
          </Button>
        </Link>
        <div className="flex items-center gap-2">
          <Bot className="w-5 h-5 text-orange-400" />
          <span className="font-semibold">Terminator II — Configuración</span>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => backendsQuery.refetch()}
          className="ml-auto text-slate-400 hover:text-white"
        >
          <RefreshCw className="w-3.5 h-3.5 mr-1" />
          Verificar
        </Button>
        {!user && (
          <a href={loginUrl}>
            <Button size="sm" className="bg-orange-600 hover:bg-orange-700 text-xs">
              Iniciar sesión
            </Button>
          </a>
        )}
      </div>

      <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
        {/* Backend status */}
        <Card className="bg-slate-900/60 border-slate-700">
          <CardHeader className="py-3">
            <CardTitle className="text-sm text-slate-200">Estado de backends</CardTitle>
          </CardHeader>
          <CardContent className="pb-4">
            {backendsQuery.isLoading ? (
              <div className="flex items-center gap-2 text-slate-400 text-sm">
                <Loader2 className="w-4 h-4 animate-spin" />
                Verificando backends...
              </div>
            ) : (
              <div className="flex flex-wrap gap-2">
                {[
                  { key: "ollama", label: "Ollama" },
                  { key: "lmstudio", label: "LM Studio" },
                  { key: "kokoro", label: "Kokoro TTS" },
                  { key: "grok", label: "Grok xAI" },
                  { key: "openai", label: "OpenAI" },
                  { key: "kimi", label: "Kimi" },
                  { key: "deepseek", label: "DeepSeek" },
                ].map(({ key, label }) => {
                  const active = backends?.[key as keyof typeof backends];
                  return (
                    <Badge
                      key={key}
                      className={`flex items-center gap-1 text-xs ${
                        active
                          ? "bg-green-900/50 text-green-400 border-green-700"
                          : "bg-slate-800 text-slate-500 border-slate-700"
                      }`}
                    >
                      {active ? (
                        <CheckCircle2 className="w-3 h-3" />
                      ) : (
                        <XCircle className="w-3 h-3" />
                      )}
                      {label}
                    </Badge>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Main tabs */}
        <Tabs defaultValue="apis">
          <TabsList className="bg-slate-900 border border-slate-700 w-full">
            <TabsTrigger
              value="apis"
              className="flex-1 data-[state=active]:bg-orange-600 data-[state=active]:text-white text-slate-400"
            >
              🔑 Claves API
            </TabsTrigger>
            <TabsTrigger
              value="prefs"
              className="flex-1 data-[state=active]:bg-orange-600 data-[state=active]:text-white text-slate-400"
            >
              <Sliders className="w-3.5 h-3.5 mr-1.5" />
              Preferencias
            </TabsTrigger>
            <TabsTrigger
              value="webhooks"
              className="flex-1 data-[state=active]:bg-orange-600 data-[state=active]:text-white text-slate-400"
            >
              <Webhook className="w-3.5 h-3.5 mr-1.5" />
              Webhooks
            </TabsTrigger>
          </TabsList>

          <TabsContent value="apis" className="mt-4">
            {!user && (
              <div className="mb-4 p-3 bg-yellow-900/20 border border-yellow-800 rounded-lg text-xs text-yellow-300 flex items-center gap-2">
                <ExternalLink className="w-4 h-4 flex-shrink-0" />
                Sin iniciar sesión, las claves se guardan solo en este navegador.{" "}
                <a href={loginUrl} className="underline font-medium">
                  Inicia sesión
                </a>{" "}
                para sincronizarlas con tu cuenta.
              </div>
            )}
            <ApiKeyManager onSaved={() => backendsQuery.refetch()} />
          </TabsContent>

          <TabsContent value="prefs" className="mt-4">
            <PreferencesTab />
          </TabsContent>

          <TabsContent value="webhooks" className="mt-4">
            <WebhooksTab />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
